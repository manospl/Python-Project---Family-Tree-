from tkinter import *
from tkinter import ttk
from tkinter import simpledialog
import tkinter as tk
import customtkinter as ctk
import datetime # δεν χρησιμοποιείται προς το παρόν,αλλά θα χρειαστεί για αμυντικό προγραμματισμό στις ημερομηνίες γεννησης,θανατου κτλ
import shortuuid # https://pypi.org/project/shortuuid/
from tkinter import messagebox
from tkinter import filedialog as fd
import json
import customtkinter
customtkinter.set_appearance_mode("dark")  # Μορφή: system (default), light, dark
customtkinter.set_default_color_theme("dark-blue")  # Θέματα: blue (default), dark-blue, green
# Χρωματισμοί γένους
MALE_COLOR_VALUE = "#0073cf" #μπλε άνδρας
FEMALE_COLOR_VALUE = "#f88379" #ανοιχτό κόκκινο γυναίκα
OTHER_COLOR_VALUE = "#00755E" #πράσινο άλλο
# Αναδρομική Συνάρτηση για την επαναλαμβανόμενη διαγραφή απογόνων ενός κόμβου στην περίπτωση ειπλογής διαγραφής του
# Χρησιμοποιείται οταν ο κόμβος αποτελεί τον μοναδικό σύνδεσμο μεταξύ προγόνων και απογόνων
# σε αυτή τη περίπτωση διαγράφουμε τους απογόνους του για να μη μείνουν ξεκρέμαστοι
def recursively_delete_children(node, node_list):
    for child in node.children: # για κάθε παιδί στη λίστα παιδιών του επιλεγμένου ατόμου
        if child.spouse != None: # αν υπάρχει και σύζυγος του παιδιού
            node_list.remove(child.spouse) # διαγραφή και του συζύγου μη μείνει ξεκρέμαστος
        node_list.remove(child) # διαγραφή παιδιού
        recursively_delete_children(child, node_list) # επανάκλησ του εαυτό της για τα παιδιά των παιδιών κτλ
def save_as_png(canvas,fileName): # Αποθήκευση σε PNG (δεν εχει υλοποιηθει ακόμα)
    # https://stackoverflow.com/questions/9886274/how-can-i-convert-canvas-content-to-an-image
    # postscipt image 
    canvas.postscript(file = fileName + '.eps') 
    # PIL to convert to PNG 
    img = Image.open(fileName + '.eps') 
    img.save(fileName + '.png', 'png')
# Κλάση που περιέχει τις ιδιότητες και λεπτομέρειες κάθε ατόμου 
class Person():
    def __init__(self) -> None:
        self.id = str(shortuuid.uuid())[0:12] #το id του κάθε ατόμου (12 πρώτοι χαρακτήρες)
        self.name = "" # Όνομα
        self.surname = ""
        self.gender = "Άρρεν" # Γένος
        self.birth = "" # Γέννηση
        self.death = "" # Θάνατος
        self.children = [] # Αρχικοποίηση λίστας παιδιών του ατόμου
        self.spouse = None # σύζυγος
        self.father = None
        self.mother = None
        self.level = 0 # η Γενιά
        self.position_x = 0 # Αρχικοποίησ συντεταγμένων Χ
        self.position_y = 0 # και Υ
        self.shape = None # Αρχικοποίηση σχήματος
        # Μεγέθη κόμβων και αποστάσεις μεταξύ τους
        self.width = 120
        self.height = 60
        self.spacing_x = 120
        self.spacing_y = 120
# Main window class
class Window(Frame): # Υποκλάση της γονικής Frame
    def __init__(self):
        super().__init__() # Κλήση της γονικής κλάσης frame apo customtkinter
        self.start_x = 310 # Αρχικές συντεταγμένες σχεδιασμού του δέντρου Χ
        self.start_y = 150 # και Υ
        self.shape_index = 0 # Δείκτης για το επιλεγμένο Κόμβο του δέντρου
        self.current_shape = None # Μεταβλητές αποθήκευσης του επιλεγμένου κόμβοτ
        self.previous_shape = None # καθώς και του προηγούμενου
        self.everyone = {} # αρχικοποίση λεξικού αποθήκευσης αντικειμένου τύπου person (key:id,value:person object)
        self.person_list = [] # λίστα αποθήκευσης αντικειμένων τύπου Person έτσι όπως δημιουργήθηκαν
        self.level_dict = {} # αρχικοποίηση λεξικού αποθήκευσης ατόμων σε λίστα ανάλογα με τη γενιά τους (key:γενιά,value:λιστα ατόμων γενιάς)
        self.initUI() # αρχικοποίηση γραφικού περιβάλλοντος GUI
    # Δημιουργία συνάρτησης προσθήκης πλαισίου διαλόγου για την εισαγωωή ονόματος του υπο προσθήκη ατόμου
    def name_enter(self, relation):
        # πλαίσιο διαλόγου απο tkinter https://docs.python.org/3/library/dialog.html
        name = simpledialog.askstring("Εισαγωγή Ονόματος", f"Παρακαλώ εισάγετε το όνομα {relation}:") 
        if ' ' in name:
            # Διαχωρισμός του ονόματος σε όνομα και επίθετο
            first_name, last_name = name.split(' ')
            # Επιστροφή ονόματος και επιθέτου ξεχωριστά
            return first_name, last_name
        else:
            # Αν έχουμε μόνο Όνομα και οχι επίθετο επιστροφή None αντί για επίθετο
            return name, None
    # Δημιουργία μενού όταν ο χρήστης κάνει δεξί κλικ σε εναν κόμβο
    # οι επιλογές είναι οι ίδιες με αυτές των κουμπιών ελέγχου (χωρίς τη προσθήκη κόμβου που δεν έχει νόημα)     
    def show_context_menu(self, event):
        # Δημιουργία νέου μενού (tearoff=0 σταθερό μενού)
        menu = Menu(self.canvas, tearoff=0)
        # Προσθήκη επιλογών στο μενού
        menu.add_command(label="Εμφάνιση πληροφοριών ατόμου", command=self.show_person_info)
        menu.add_separator() # διαχωριστικό
        # Προσθήκη επιλογών των κουμπιών
        menu.add_command(label="Προσθήκη Παιδιού", command=self.add_child)
        menu.add_command(label="Προσθήκη Συζύγου", command=self.add_spouse)
        menu.add_command(label="Προσθήκη Γονέων", command=self.add_parents)
        menu.add_command(label="Προσθήκη Αδελφού", command=self.add_sibling)
        menu.add_command(label="Διαγραφή Κόμβου", command=self.delete_node)
        menu.add_command(label="Προβολή Απογόνων", command=self.view_descendants)
        menu.add_separator() # διαχωριστικό
        menu.add_command(label="Καθαρισμός Όλων", command=self.clear_all)
        # Εμφάνιση του μενού στη θέση του ποντικιού
        menu.post(event.x_root, event.y_root)
    # Συνάρτηση για την εμφάνιση απογόνων
    def view_descendants(self):
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                break
        # Δημιουργία νέου Toplevel παραθύρου ( ο καμβάς τώρα είναι στατικός χωρίς dag and drop)
        descendants_window = tk.Toplevel(self.master) # Πάνω απο τον καμβά
        descendants_window.geometry("1600x1200") # διαστάσεις
        # τίτλος παραθύρου με πρόβλεψη για αρσενικό θηλυκό (χμμμ για άλλο?αφήνουμε αρσενικό προς το παρόν)
        descendants_window.title("Δέντρο απεικόνισης απογόνων της " + selected_individual.name + " " + selected_individual.surname if selected_individual.gender == "female" else "Δέντρο απεικόνισης απογόνων του " + selected_individual.name + " " + selected_individual.surname)
        # Φτιάχνουμε τον καμβά (Ίσως είναι καλύτερα να παραλείψουμε το ύψος και πλάτος)
        descendants_canvas = tk.Canvas(descendants_window, width=1600, height=1200)
        descendants_canvas.pack() # τοποθέτησή του με .pack
        descendants_canvas.delete("all") # καθαρισμός του καμβά
        # Εδώ θα καλέσουμε την αναδρομική συνάρτηση αναζήτησης και απεικόνισης των απογόνων του ατόμου
        self.draw_children_recursive(selected_individual, descendants_canvas)
    # Η αναδρομική συνάρτηση που είπαμε παραπάνω
    def draw_children_recursive(self, person, canvas):
        # πρώτα σχεδιάζουμε τον κόμβο του επιλεγμένου ατόμου,του οποίου τους απογόνους θέλουμε να παρουσιάσουμε
        canvas_width = canvas.winfo_reqwidth() # βρίσκουμε το πλάτος του καμβά για να κεντράρουμε τον κόμβο στο κέντρο του
        # παίρνουμε έτοιμες τις διαστάσεις και συντεταγμένες του ατόμου απο το ήδη σχεδιασμένο δέντρο
        x = person.position_x # Οριζόντια συντεταγμένη
        y = person.position_y-20 # Ανεβάζουμε λίγο τον κόμβο πιο ψηλά (περισσότερο τεστς θα χρειαστεί)
        width = person.width # πλάτος ήδη υπάρχων
        height = person.height # ύψος επίσης
        color = OTHER_COLOR_VALUE # Αρχικοποίηση χρώματος
        # Εδω υπολογίζουμε ενα περιθώριο (offset) για το που θα σχεδιάσουμε τον πρώτο κόμβο ώστε να κεντραριστεί οριζόντια στον νέο καμβά
        # ( το x αφορά την συντεταγμένη του κυρίως καμβά και βάζουμε το περιθώριο σε σχέςση με το πλάτος του νέου καμβά σχεδίασης (αντικείμενο canvas))
        dx=(canvas_width//2)-x+(width//2) 
        dy = y - 5 # Απενεργοποίηση...για περισσότερες δοκιμές
        x += dx # ορισμός νέου x λαμβάνοντας υπόψη το περιθώριο
        # y += dy # Απενεργοποίηση...για περισσότερες δοκιμές
        # Ορισμός χρωμάτων ανάλογα με το γένος
        if person.gender == "Άρρεν": 
            color = MALE_COLOR_VALUE
        if person.gender == "Θήλυ":
            color = FEMALE_COLOR_VALUE
        # Κατασκευή ορθογωνίου σύμφωνα με τα παραπάνω στον νέο καμβά
        # Ίδια με την μέθοδο κατασκευής ορθογωνίου απο την συνάρτηση draw_family_tree
        canvas.create_rectangle(x, y, x + width, y + height,
            outline="#333333", fill=color, width=0, tags="single_shape")
        canvas.create_text(x + (width//2), y + (height//2), fill="white", font="Roboto 10", anchor="center", justify="center",
            text=person.name + "\n" + person.surname)
        # Εδώ θα αλλάξουμε λίγο τρόπο σχεδιασμού ακμών και θα δανειστούμε τον τρόπο σχεδιασμού τους απο την ανενεργή draw_parental_relations
        # Οι ακμές οδηγούνται απευθείας απο τους γονείς στα παιδιά
        # Υπολογισμός πρώτου σημείου γραμμής (μέσον και κάτω στον κόμβο γονέα) 
        x1 = x + (width//2) 
        y1 = y + height
        if not person.children: # Αν το άτομο δεν έχει παιδιά 
            return # επιστροφή και τέλος
        # για κάθε παιδί στη λίστα παιδιών του επολεγμένου ατόμου 
        for child in person.children:
            # με την ίδια λογική που σχεδιάσαμε τον γονικό κόμβο πιό πανω σχεδιάζουμε και του κόμβους παιδιών
            x = child.position_x
            y = child.position_y-20
            width = child.width
            height = child.height
            color = OTHER_COLOR_VALUE
            x += dx # ίδιο περιθώριο που υπολογίστηκε πιο πάνω (τα παιδιά ήδη εχουν πάρει θέση με την reposition_childen και reorganize_nodes)
            #y += dy
            # χρώματισμοί
            if child.gender == "Άρρεν":
                color = MALE_COLOR_VALUE
            if child.gender == "Θήλυ":
                color = FEMALE_COLOR_VALUE
            #σχεδιασμός κόμβου
            canvas.create_rectangle(x, y, x + width, y + height,
                outline="#333333", fill=color, width=0, tags="single_shape")
            canvas.create_text(x + (width//2), y + (height//2), fill="white", font="Roboto 10", anchor="center", justify="center",
                text=child.name + "\n" + child.surname)
            # Υπολογισμός συντεταγμένων δεύτερου σημείου γραμμής ένωσης με τον γονικό κόμβο (στο μέσο του παιδικού κόμβου και πάνω)
            x2 = x + (width//2)
            y2 = y 
            # Σχεδιασμός ακμής σύνδεσης γονέα και παιδιού
            # δανεισμένος απο self.draw_parental_relations(person, child, canvas, x, y)
            canvas.create_line(x1, y1 , x2, y2, width = 2)            
            # και επανάκληση της ίδιας συνάρτησης (ο το παιδί γίνεται γονέας του επόμενου παιδιού κτλ) μέχρις ότου τελειώσουν οι απόγονοι
            self.draw_children_recursive(child, canvas)
    def single_shape_clicked(self, event): # event handler (χειρισμός συμβάντων κατά την επιλογή με κλίκ)
        x, y = event.x, event.y # καθορισμός συντεταγμένων που προκλήθηκαν απο το κλικ
        #shape = self.canvas.find_closest(x,y)
        # εντοπισμός του αντικείμενου του καμβά που βρίσκεται κάτω απο το δείκτη του ποντικιού και αποθήκευση στο index
        # https://www.pythontutorial.net/tkinter/tkinter-canvas/
        # https://stackoverflow.com/questions/70423920/how-do-i-detect-tags-of-clicked-objects-in-tkinter-canvas
        index = (event.widget.find_withtag("current")[0]) 
        #c.delete(shape)
        self.previous_shape = self.current_shape # Αποθήκευση του προηγούμενου επιλεγμένου κόμβου
        self.current_shape = index # Ορισμός του τρέχοντος κόμβου στο index που βρήκαμε παραπάνω
        if self.previous_shape != None: # Αν υπάρχει προηγούμενος επιλεγμένος κόμβος 
            self.canvas.itemconfig(self.previous_shape, width = 0) # σβήνουμε το περίγραμμα απο το προηγούμενο (πάχος 0)
        self.canvas.itemconfig(self.current_shape, width = 3) # και το ορίζουμε το περιγραμμα στο τρέχων μας βοηθάει οπτικα ποιός κόμβος ειναι επιλεγμένος
        #το πάχος του περιγράμματος είναι παραμετροποιήσιμο ανάλογα με τα γούστα μας
        self.clear_information() # καθαρισμός πληροφοριών προηγούμενου ατόμου
        #self.fetch_information()
        self.display_information() # εμφάνιση πληροφοριών επιλεγμένου ατόμου
        ### Βοηθητικές συναρτήσεις μετακίνησης κόμβων και απογόνων για την αποφυγή αλληλοκαλύψεων ### 
    ### Βοηθητικές συναρτήσεις μετακίνησης κόμβων και απογόνων για την αποφθγή αλληλοκαλύψεων
    # Αναδρομική συνάρτηση που μετακινεί κόμβους και τους απογόνους κατά ενα περιθώριο (offset)
    def update_descendants_x_position(self, person, offset):
        for child in person.children: # για κάθε παιδί στη λίστα παιδιών
            child.position_x += offset # Μετακίνηση δεξιά ή αριστερά σύμφωνα με το offset
            if child.spouse:
                child.spouse.position_x += offset # Μετακίνηση και του συζύγου δεξιά ή αριστερά σύμφωνα με το offset
            self.update_descendants_x_position(child, offset) # επανάκληση για να βρεθούν όλοι οι απόγονοι
    # Απώθηση δεξιά και αριστερά σα μαγνήτης στο σημείο Χ και στη γενιά level
    # χρησιμοποιείται για να "ανοίξουμε" το δεντρο δεξιά και αριστερά για να αποφύγουμε αλληλοκαλύψεις
    def repulsion(self, level, X, offset):
        for individual in self.person_list: # για κάθε άτομο στη λίστα ατόμων
            if individual.level == level: # Αν το άτομο ανήκει στη γενιά level
                if individual.position_x < X: # αν η θέση του βρισκεται αριστερα του σημείου ανοίγματος
                    self.shift_left(individual, offset) # κλήση της συνάρτησηση αριστερου "συρσίματος"
                elif individual.position_x > X: # ομοίως αν βρίσκεται δεξιά του Χ
                    self.shift_right(individual, offset) # κλήση της συνάρτησηση δεξιού "συρσίματος"
    # Μετακίνηση αριστερά κόμβου και απογόνων (και συζύγων αυτών)
    def shift_left(self, individual, offset):
        individual.position_x -= offset # μειωση του Χ και σύρουμε τον κόμβο αριστερά κατά το περιθώριο offset
        if individual.spouse:
            individual.spouse.position_x -= offset # μειωση του Χ και του συζύγου και σύρουμε τον κόμβο αριστερά κατά το περιθώριο offset
        for child in individual.children: # το ίδιο κάνουμε και για τα παιδιά του
            self.shift_left(child, offset) # και τα παιδιά των παιδιών αναδρομικά
    # Μετακίνηση δεξιά κόμβου και απογόνων
    def shift_right(self, individual, offset): #ομοίως με την shift_left αλλά προς τα δεξιά
        individual.position_x += offset
        if individual.spouse:
            individual.spouse.position_x += offset
        for child in individual.children:
            self.shift_right(child, offset)
    # Αντιμετάθεση θέσεων 2 κόμβων μεταξύ τους
    def swap_positions(self, node1, node2):
        # Υπολογισμός περιθωρίου
        offset1 = node2.position_x - node1.position_x
        offset2 = node1.position_x - node2.position_x

        # Κλήση κατάλληλης συνάρτησης για μετακίνηση δεξιά ή αριστερά
        if offset1 > 0:
            self.shift_right(node1, offset1)
        else:
            self.shift_left(node1, -offset1)

        if offset2 > 0:
            self.shift_right(node2, offset2)
        else:
            self.shift_left(node2, -offset2)
    # Έλεφχος για την ύπαρξη αδερφού αριστερά απο τον κόμβο (βοηθάει στην τοποθέτηση συζύγου)
    def has_sibling_to_the_left(self, individual):
        for person in self.person_list: #για κάθε άτομο στη λίστα
            if person.level == individual.level and person.position_x < individual.position_x: # αν είναι στο ίδιο επίπεδο και βρίσκεται αριστερά 
                if person.mother == individual.mother or person.father == individual.father: # ελέγχουμε αν έχουν τον ίδιο γονέα
                    return True #αν ναι τότε True
        return False # αλλιώς ψευδές
    # Προσθήκη κόμβου (αρχικού)
    def add_new_node(self):
        name, surname = self.name_enter("του ατόμου") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        start_x = self.start_x # ορισμός των αρχικών συντεταγμένων
        start_y = self.start_y # Χ και Υ όπως τις ορίσαμε παραπάνω
        person = Person() # δημιουργία αντικειμένου τύπου person
        person.position_x = start_x # ορισμός της θέσης του αντικειμένου 
        person.position_y = start_y # στα Χ και Υ
        person.level = 0 # η Γενιά του ατόμου
        if name!=None: person.name = name # ορισμός ονόματος του ατόμου στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
        if surname!=None: person.surname = surname # ορισμός και του επιθέτου στην περίπτωση που έχει καταχωρηθεί
        self.person_list.append(person) # προσθήκη του ατόμου στη λίστα των ατόμων
        self.draw_family_tree() # σχεδιασμός δέντρου
    # Προσθήκη συζύγων
    def add_spouse(self):
        # αμυντικός στην περίπτωση που δεν εχει επιλεγέι κάποιος κόμβος
        if self.current_shape == None: 
            messagebox.showwarning(title="Δεν έχει επιλεγέι κόμβος", message="Παρακαλώ πρώτα επιλέξτε έναν κόμβο για την προσθήκη συζύγου")
            return
        spouse_name, spouse_surname = self.name_enter("συζύγου") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                break
        if selected_individual.spouse != None: # αν το επιλεγμένο ατομο έχει ήδη σύζυγο 
            return # μη κανεις τίποτα
        # εδω ίσως μπορούμε να εχουμε μια πρόβλεψη για πρώην συζύγους κτλ
        #ορισμός συντεταγμένων (το Υ παραμένει ίδιο ειναι ίδια γενιά,το Χ ορίζεται ανάλογα με την ύπαρξη αδερφικού κόμβου)
        sibling_to_the_left = self.has_sibling_to_the_left(selected_individual) # έλεγχος για αδελφό αριστερά
        if sibling_to_the_left: # αν υπάρχει
            start_x = selected_individual.position_x + selected_individual.width + selected_individual.spacing_x # ο σύζυγος μπαινει δεξιά
            direction = 1 # δεξιά κίνηση
        else:
            start_x = selected_individual.position_x - selected_individual.width - selected_individual.spacing_x # ο σύζυγος μπαινει αριστερά
            direction = -1 # αριστερή κίνηση
        start_y = selected_individual.position_y
        spouse = Person() # δημιουργία αντικειμένου τύπου person
        spouse.position_x = start_x # ορισμός της θέσης του αντικειμένου
        spouse.position_y = start_y # στα Χ και Υ
        if selected_individual.gender == "Άρρεν":
            spouse.gender = "Θήλυ"
        elif selected_individual.gender == "Θήλυ":
            spouse.gender = 'Άρρεν'
        if spouse_name!=None: spouse.name = spouse_name # ορισμός ονόματος συζύγου στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
        if spouse_surname!=None: spouse.surname = spouse_surname # και του επιθέτου αν έχει δηλωθεί
        selected_individual.spouse = spouse # ορίζουμε την συγγένεια του επιλεγμένου κόμβου σε σύζυγο
        spouse.spouse = selected_individual # και αντιστρόφως
        spouse.level = selected_individual.level # ίδια γενιά
        for child in selected_individual.children: # αν το επιλεγμένο άτομο έχει παιδιά
            spouse.children.append(child) # τα προσθέτουμε και στον/στην σύζυγο
        self.reposition_children(selected_individual) # αναδιάταξη παιδιών
        if selected_individual.children: # αν ο επιλεγμένος κόμβος που πάμε να προσθέσουμε σύζυγο έχει παιδιά
            offset = selected_individual.spacing_x  # περιθώριο για μετακίνηση
            self.update_descendants_x_position(selected_individual, direction * offset) # μετακίνηση των παιδιών για τη σωστή στοίχιση
        self.person_list.append(spouse) # προσθήκη του συζύγου στη λίστα των ατόμων
        self.draw_family_tree() # (επανα)σχεδιασμός δέντρου
    #προσθήκη γονέων
    def add_parents(self):
        # αμυντικός στην περίπτωση που δεν εχει επιλεγέι κάποιος κόμβος
        if self.current_shape == None:
            messagebox.showwarning(title="Δεν έχει επιλεγέι κόμβος", message="Παρακαλώ επιλέξτε εναν κόμβο προτού προσθέσετε συγγένεια")
            return
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                break
        mother_name, mother_surname = self.name_enter("μητέρας") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        father_name, father_surname = self.name_enter("πατέρα") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        #ορισμός συντεταγμένων (το Χ μειώνεται (αριστερά) κατά το μήκος του κόμβου για να εχουμε sort,το Υ μειώνεται (προηγούμενη γενια) συμφωνα με τισ αποστάσεις)
        #start_x = selected_individual.position_x - selected_individual.spacing_y # εναλλακτική προσέγγιση       
        start_x = selected_individual.position_x - selected_individual.width
        start_y = selected_individual.position_y - (selected_individual.height) - selected_individual.spacing_y
        #προσθήκη μητέρας αριστερά
        mother = Person() # δημιουργία αντικειμένου τύπου person
        mother.position_x = start_x # ορισμός της θέσης του αντικειμένου
        mother.position_y = start_y # στα Χ και Υ
        mother.gender = "Θήλυ" # ορισμός γένους
        if mother_name!=None: mother.name = mother_name # ορισμός ονόματος της μητέρας στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
        if mother_surname!=None:
            mother.surname = mother_surname # Ορισμός και επιθέτου αν έχει δηλωθεί
        else:
            mother.surname = selected_individual.surname # Ορισμός του ίδιου επιθέτου στη μητέρα για λόγους ευκολίας
        # προσθήκη πατέρα δεξιά
        father = Person() # δημιουργία αντικειμένου τύπου person
        father.position_x = start_x + selected_individual.width + selected_individual.spacing_x # ορισμός της θέσης του αντικειμένου
        father.position_y = start_y # στα Χ και Υ
        father.gender = "Άρρεν" # ορισμός γένους
        if father_name!=None: father.name = father_name # ορισμός ονόματος του πατέρα στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
        if father_surname!=None:
            father.surname = father_surname # Ορισμός και επιθέτου αν έχει δηλωθεί
        else:
            father.surname = selected_individual.surname # Ορισμός του ίδιου επιθέτου στον Πατέρα για λόγους ευκολίας
        mother.spouse, father.spouse = father, mother # ορισμός συζύγων στους γονείς μεταξύ τους
        selected_individual.mother = mother
        selected_individual.father = father
        mother.children.append(selected_individual) # ορισμός επιλεγμένου κόμβου ως παιδί 
        father.children.append(selected_individual) # και στους 2 γονείς
        mother.level = selected_individual.level - 1 # προηγούμενη γενιά
        father.level = selected_individual.level - 1 # και στους 2 γονείς
        self.person_list.append(mother) # προσθήκη γονέων στη λίστα ατόμων
        self.person_list.append(father)
        # Έλεγχος για την παρουσία συζύγου με ύπαρξη γονέων για την αποφυγή αλληλοκάλυψης
        print(min(abs(selected_individual.position_x - selected_individual.spouse.father.position_x), #Υπολογισμός Χ κοντυνότερου γονέα
                                        abs(selected_individual.position_x - selected_individual.spouse.mother.position_x)))
        
        if selected_individual.spouse: # Υπάρχει σύζυγος
            spouse = selected_individual.spouse # τον ορίζουμε ως spouse
            if spouse.father or spouse.mother:  # Αν υπάρχει έστω ένας γονέας
                closest_parent_x = None # αρχικοποίηση συντεταγμένης Χ κοντυνότερου γονέα
                if spouse.father and spouse.mother: # Αν υπάρχουν και οι δύο γονέις
                    closest_parent_x = min(abs(selected_individual.position_x - spouse.father.position_x), #Υπολογισμός Χ κοντυνότερου γονέα
                                        abs(selected_individual.position_x - spouse.mother.position_x))
                    #print (closest_parent_x) # debug
                elif spouse.father: # Μόνο Πατέρας
                    closest_parent_x = abs(selected_individual.position_x - spouse.father.position_x) # Υπολογισμός Χ πατέρα
                else: # Μόνο Μητέρα
                    closest_parent_x = abs(selected_individual.position_x - spouse.mother.position_x) # Υπολογισμός Χ μητέρας
                # αν το Χ του κοντυνότερου γονέα είναι μικρότερο ή ίσο 2 μηκών διαστήματος
                # τότε η προσθήκη γονέων θα μας οδηγήσει σε αλληλοκαλυπτόμενους ή εφαπτόμενους κόμβους και θέλουμε να το αποφύγουμε αυτό
                # απομακρύνοντας τους γονείς των δύο συζύγων μεταξύ τους
                if closest_parent_x <= selected_individual.spacing_x * 2: 
                    shift_direction = -1 if selected_individual.position_x < spouse.position_x else 1 
                    selected_individual.father.position_x += shift_direction * (selected_individual.spacing_x*3-closest_parent_x)/2
                    selected_individual.mother.position_x += shift_direction * (selected_individual.spacing_x*3-closest_parent_x)/2
                    spouse.father.position_x -= shift_direction * (selected_individual.spacing_x*3-closest_parent_x)/2
                    spouse.mother.position_x -= shift_direction * (selected_individual.spacing_x*3-closest_parent_x)/2      
        self.draw_family_tree() # (επανα)σχεδιασμός δέντρου
    #προσθήκη παιδιού
    def add_child(self):
        if self.current_shape == None:
            # αμυντικός στην περίπτωση που δεν εχει επιλεγέι κάποιος κόμβος
            messagebox.showwarning(title="Δεν έχει επιλεγέι κόμβος", message="Παρακαλώ επιλέξτε εναν κόμβο προτού προσθέσετε συγγένεια")
            return
        child_name, child_surname = self.name_enter("παιδιού") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                break
        children_count = len(selected_individual.children) + 1 # υπολογισμός αριθμου παιδιών (+1 για το παιδί που πρόκειται να προστεθεί)
        # Υπολογισμός συνολικού μήκους βοηθητικής γραμμής για την τοποθέτηση του παιδιού σε σχέση με την θέση των γονέων
        # προσπαθούμε να πάρουμε το μεσαίο σημείο, και μετά αφαιρείται το μισό πλάτος του κόμβου του επιλεγμένου ατόμου για να πάρουμε το αρχικό σημείο της γραμμής.
        line_length = (selected_individual.width * children_count) // 2 - (selected_individual.width//2)
        line_length += (selected_individual.spacing_x * (children_count -1)//2)
        # Έλεγχος αν το επιλεγμένο άτομο έχει σύζυγο για να καθορίσουμε τις αρχικες συντεταγμένες που θα τοποθετηθεί το παιδί
        #(βασικά μονο το Χ μας ενδιαφέρει εδω
        if selected_individual.spouse == None: #Αν δεν υπάρχει σύζυγος
            initial_x = selected_individual.position_x # Το αρχικό Χ παραμένει ίδιο (το παιδί μπαίνει ΚΑΤΩ απο τον γονέα)
            initial_y = selected_individual.position_y # Υ ίδιο
        else:
            if selected_individual.position_x < selected_individual.spouse.position_x: # Επιλεγμένο Άτομο έχει σύζυγο στα ΔΕΞΙΑ του
                initial_x = selected_individual.position_x + selected_individual.width # Αρχικό Χ μετακινείται προς τα ΔΕΞΙΑ για να μπει ανάμεσα στους γονείς
                initial_y = selected_individual.position_y # Υ ίδιο
            else:
                initial_x = selected_individual.spouse.position_x + selected_individual.spouse.width # Επιλεγμένο Άτομο έχει σύζυγο στα ΑΡΙΣΤΕΡΑ του
                initial_y = selected_individual.spouse.position_y # Αρχικό Χ μετακινείται προς τα ΑΡΙΣΤΕΡΑ για να μπει ανάμεσα στους γονείς
        #αφού έχουμε το αρχικό Χ και το μήκος γραμμής ορίζουμε τις συντεταγμένες που θα μπει ο κόμβος παιδιού
        start_x = initial_x  - line_length  # το Χ σύμφωνα με τους υπολογισμούς παραπάνω
        start_y = initial_y + selected_individual.spacing_y + selected_individual.height # μια γενιά παραπάνω απο τον επιλεγμένο κόμβο
        for i in range(children_count): # Διατρέχουμε ολα τα παιδιά
            #print(i)
            if i >= children_count - 1: # Εφτασε στο τέλος,αρα έφτασε η στιγμή να προσθέσουμε νέο παιδί
                person = Person() # δημιουργία αντικειμένου τύπου person
                person.position_x = start_x # ορισμός της θέσης του σύμφωνα με τους υπολογισμούς που κάναμε παραπάνω
                person.position_y = start_y # και Υ
                if child_name!=None: person.name = child_name # ορισμός ονόματος του παιδιού στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
                if child_surname!=None:
                    child.surname = child_surname # Ορισμός και επιθέτου αν έχει δηλωθεί
                else:
                    if selected_individual.gender == "Άρρεν":
                        person.surname = selected_individual.surname # Κληρονόμηση επιθέτου σε περίπτωση πατέρα
                        person.father = selected_individual
                        person.mother = selected_individual.spouse
                    elif selected_individual.gender == "Θήλυ" and selected_individual.spouse is not None: # και κληρονόμηση σε περίπτωση μητέρας με σύζυγο
                        person.surname = selected_individual.spouse.surname
                        person.father = selected_individual.spouse
                        person.mother = selected_individual
                    elif selected_individual.gender == "Θήλυ": # και κληρονόμηση σε περίπτωση μητέρας μονογονεικής οικογένειας
                        person.surname = selected_individual.surname
                        person.father = selected_individual.spouse
                        person.mother = selected_individual
                selected_individual.children.append(person) # Προσθήκη του παιδιού στη λίστα των παιδιών του επιλεγμένου κόμβου
                person.level = selected_individual.level + 1 # Αύξηση γενιάς κατά 1 για το παιδί
                if selected_individual.spouse != None: # Αν υπάρχει σύζυγος του επιλεγμένου κόμβου
                    selected_individual.spouse.children.append(person) # τότε προσθήκη του παιδιού και στη λίστα παιδιών του συζύγου
                self.person_list.append(person) # προσθήκη του παιδιού και στη γενική λίστα ατόμων
                # Αν υπάρχει αδελφικός κόμβος με παραπάνω απο 1 παιδί αυξάνουμε αποστάσεις απο πρίν μεταξύ των αδελφών
                for sibling in selected_individual.children:
                    if sibling != person and abs(sibling.position_x - person.position_x) <= selected_individual.spacing_x + sibling.width:
                        if len(sibling.children) > 1:
                            shift_factor= (len(sibling.children)-1) * selected_individual.spacing_x // 2
                            for individual in self.person_list:
                                if (individual.level >= sibling.level and individual.position_x < sibling.position_x + sibling.width + selected_individual.spacing_x // 2) or (individual in sibling.children):
                                    individual.position_x -= shift_factor
                                elif (individual.level >= person.level and individual.position_x > person.position_x - selected_individual.spacing_x // 2) or (individual in person.children):
                                    individual.position_x += shift_factor 
                            break
                # Aν το προστιθέμενο παιδί εφάπτεται με ξάδελφο κόμβο αυξάνουμε τις αποστάσεις μεταξύ των αδελφών
                if selected_individual.father or selected_individual.mother:
                    for parent in [selected_individual.mother, selected_individual.father]:
                        if parent is not None:
                            for sibling in parent.children:
                                if sibling != selected_individual:
                                    for sibling_child in sibling.children:
                                        for selected_child in selected_individual.children:
                                            if abs(sibling_child.position_x - selected_child.position_x) <= selected_individual.spacing_x:
                                                shift_factor = selected_individual.spacing_x // 2
                                                self.repulsion(sibling.level, sibling.position_x, shift_factor)
                                                self.repulsion(selected_individual.level, selected_individual.position_x, shift_factor)
                                                break                        
            else: # τα προηγούμενα υπάρχοντα παιδιά
                child = selected_individual.children[i] #επιλογή υπάρχοντος παιδιού
                offset = -120 # Υπολογισμός πόσο θα μετακινηθέι το παιδί
                child.position_x = child.position_x + offset # ανανέωση της θέσης του υπάρχοντος παιδιού
                child.position_y = start_y # σε Χ και Υ σύμφωνα με τους υπολογισμούς
                if selected_individual.spouse != None: # αν υπάρχει σύζυγος 
                    if child not in selected_individual.spouse.children: # και το παιδί [i] δεν υπάρχει στη λίστα του
                        selected_individual.spouse.children.append(child) # τότε πρόσθεσέ το στη λίστα παιδιών του συζύγου
                # ανανέωση του Χ (μόνο το Χ μας ενδιαφέρει,το Υ μένει ίδιο)
                # και μετακίνηση προς τα δεξιά σύμφωνα με τις δηλωμένες αποστάσεις για να μπει το επόμενο παιδί
                start_x = child.position_x + selected_individual.width + selected_individual.spacing_x
                self.update_descendants_x_position(child, offset) # μετακίνηση απογόνων για την αποφυγή αλληλοκαλύψεων
        self.draw_family_tree()# (επανα)σχεδιασμός δέντρου
    # προσθήκη αδελφού/αδελφής
    # Ακολουθείται η ίδια λογική με την add_child απλά κρατάμε τα αδέρφια στο ίδιο επίπεδο(γενιά)
    def add_sibling(self):
        # αμυντικός στην περίπτωση που δεν εχει επιλεγέι κάποιος κόμβος
        if self.current_shape == None:
            messagebox.showwarning(title="Δεν έχει επιλεγέι κόμβος", message="Παρακαλώ επιλέξτε εναν κόμβο προτού προσθέσετε συγγένεια")
            return
        sibling_name, sibling_surname = self.name_enter("αδελφού/ής") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                surname=selected_individual.surname # μεταβλητή για την κληρονόμηση επιθέτου
                break
        selected_parent = None # αρχικοποίηση γονέα επιλεγμένου ατόμου
        for individual in self.person_list: # iteration για να βρουμε γονέα  
            #print(selected_individual, individual.children)
            if selected_individual in individual.children: # αν το επιλεγμένο άτομο ανήκει στη λίστα παιδιών
                selected_parent = individual # τότε έχουμε γονέα και τον καταχωρούμε
                # σημειωτέον οτι μας ενδιαφέρει μόνο ο ένας γονέας.Ο έλεγχος αν υπάρχει και άλλος γονέας γίνεται παρακάτω
                break
        #αμύντικός στη περίπτωση απουσίας γονέων
        if selected_parent == None: # αν δεν υπάρχει γονέας μήνυμα σφάλματος και επιστροφή
            messagebox.showwarning(title="Το Επιλεγμένο Άτομο δεν έχει γονέα/εις", message="Παρακαλώ προσθέστε γονείς πρίν την προσθήκη αδελφού/ης")
            return 
        selected_individual = selected_parent # καταχώρηση του γονέα του επιλεγμένου ατόμου για περεταίρω επεξεργασία παρακάτω
        # βασικά είναι σαν να κάνουμε add_child για τον γονέα αυτή τη φορά
        #ίδια λογική με add child για τον γονέα
        children_count = len(selected_individual.children) + 1 # υπολογισμός αριθμου παιδιών (+1 για το παιδί που πρόκειται να προστεθεί)
        # Υπολογισμός συνολικού μήκους βοηθητικής γραμμής για την τοποθέτηση του παιδιού σε σχέση με την θέση των γονέων
        # προσπαθούμε να πάρουμε το μεσαίο σημείο, και μετά αφαιρείται το μισό πλάτος του κόμβου του επιλεγμένου ατόμου για να πάρουμε το αρχικό σημείο της γραμμής.      
        line_length = (selected_individual.width * children_count) // 2 - (selected_individual.width//2)
        line_length += (selected_individual.spacing_x * (children_count -1)//2)
        # Έλεγχος αν το επιλεγμένο άτομο έχει σύζυγο για να καθορίσουμε τις αρχικες συντεταγμένες που θα τοποθετηθεί το παιδί
        #(βασικά μονο το Χ μας ενδιαφέρει εδω
        if selected_individual.spouse == None: #Αν δεν υπάρχει σύζυγος
            initial_x = selected_individual.position_x # Το αρχικό Χ παραμένει ίδιο (το παιδί μπαίνει ΚΑΤΩ απο τον γονέα)
            initial_y = selected_individual.position_y # Υ ίδιο
        else:
            if selected_individual.position_x < selected_individual.spouse.position_x: # Επιλεγμένο Άτομο έχει σύζυγο στα ΔΕΞΙΑ του
                initial_x = selected_individual.position_x + selected_individual.width # Αρχικό Χ μετακινείται προς τα ΔΕΞΙΑ για να μπει ανάμεσα στους γονείς
                initial_y = selected_individual.position_y # Υ ίδιο
            else:
                initial_x = selected_individual.spouse.position_x + selected_individual.spouse.width # Επιλεγμένο Άτομο έχει σύζυγο στα ΑΡΙΣΤΕΡΑ του
                initial_y = selected_individual.spouse.position_y # Αρχικό Χ μετακινείται προς τα ΑΡΙΣΤΕΡΑ για να μπει ανάμεσα στους γονείς
        # for child in self.everyone[self.current_shape].children:
        # self.everyone[self.current_shape].children = []
        #αφού έχουμε το αρχικό Χ και το μήκος γραμμής ορίζουμε τις συντεταγμένες που θα μπει ο κόμβος παιδιού
        start_x = initial_x  - line_length  # το Χ σύμφωνα με τους υπολογισμούς παραπάνω
        start_y = initial_y + selected_individual.spacing_y + selected_individual.height # μια γενιά παραπάνω απο τον επιλεγμένο κόμβο
        for i in range(children_count): # Διατρέχουμε ολα τα παιδιά
            #print(i)
            if i >= children_count - 1: # Εφτασε στο τέλος,αρα έφτασε η στιγμή να προσθέσουμε νέο παιδί
                person = Person() # δημιουργία αντικειμένου τύπου person
                person.position_x = start_x # ορισμός της θέσης του σύμφωνα με τους υπολογισμούς που κάναμε παραπάνω
                person.position_y = start_y # και Υ
                if sibling_surname!=None:
                    person.surname = sibling_surname
                else:
                    person.surname = surname # ορισμός ίδιου επιθέτου για ευκολία
                if sibling_name!=None: person.name = sibling_name # ορισμός ονόματος αδελφού στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
                if selected_individual.father is not None: 
                    person.father = selected_individual.father 
                if selected_individual.mother is not None: 
                    person.mother = selected_individual.mother 
                selected_individual.children.append(person) # Προσθήκη του παιδιού στη λίστα των παιδιών του επιλεγμένου κόμβου
                person.level = selected_individual.level + 1 # Αύξηση γενιάς κατά 1 για το παιδί
                if selected_individual.spouse != None: # Αν υπάρχει σύζυγος του επιλεγμένου κόμβου
                    selected_individual.spouse.children.append(person) # τότε προσθήκη του παιδιού και στη λίστα παιδιών του συζύγου
                self.person_list.append(person) # προσθήκη του παιδιού και στη γενική λίστα ατόμων
                for sibling in selected_individual.children:
                    if sibling != person and abs(sibling.position_x - person.position_x) <= selected_individual.spacing_x + sibling.width:
                        if len(sibling.children) > 1:
                            shift_factor= (len(sibling.children)-1) * selected_individual.spacing_x // 2
                            for individual in self.person_list:
                                if (individual.level >= sibling.level and individual.position_x < sibling.position_x + sibling.width + selected_individual.spacing_x // 2) or (individual in sibling.children):
                                    individual.position_x -= shift_factor
                                elif (individual.level >= person.level and individual.position_x > person.position_x - selected_individual.spacing_x // 2) or (individual in person.children):
                                    individual.position_x += shift_factor 
                            break                          
            else: # τα προηγούμενα υπάρχοντα παιδιά
                child = selected_individual.children[i] #επιλογή υπάρχοντος παιδιού
                offset = start_x - child.position_x # Υπολογισμός πόσο θα μετακινηθέι το παιδί
                child.position_x = start_x # ανανέωση της θέσης του υπάρχοντος παιδιού
                child.position_y = start_y # σε Χ και Υ σύμφωνα με τους υπολογισμούς
                if selected_individual.spouse != None: # αν υπάρχει σύζυγος 
                    if child not in selected_individual.spouse.children: # και το παιδί [i] δεν υπάρχει στη λίστα του
                        selected_individual.spouse.children.append(child) # τότε πρόσθεσέ το στη λίστα παιδιών του συζύγου
                # ανανέωση του Χ (μόνο το Χ μας ενδιαφέρει,το Υ μένει ίδιο)
                # και μετακίνηση προς τα δεξιά σύμφωνα με τις δηλωμένες αποστάσεις για να μπει το επόμενο παιδί
                start_x += selected_individual.width + selected_individual.spacing_x
                #self.update_descendants_x_position(child, offset) # μετακίνηση απογόνων για την αποφυγή αλληλοκαλύψεων
        self.draw_family_tree()# (επανα)σχεδιασμός δέντρου
    # ΣΥΓΕΝΕΙΕΣ ΚΑΙ ΑΚΜΕΣ
    # Σύνδεση συζύγων
    def draw_spouse_relation(self, node1, node2): # node1 node 2 Οι δυο σύζυγοι
        if node1.position_x < node2.position_x: # Σιγουρεύουμε οτι το node1 είναι αριστερά του node 2
            x1 = node1.position_x + node1.width # ένας απο τους δύο συζύγους σίγουρα θα βρίσκεται αριστερά του αλλου αν βγάλουμε το check τότε θα σχεδιάσει 2 αλληλοεπικαλυπτόμενες γραμμές 
            x2 = node2.position_x # παίρνουμε τα Χ ,το ενα είναι στη δεξιά άκρη του αριστερού κόμβου και το άλλο στην αριστερή του δεξιού κόμβου
            # else: # Περισσότερο debug Θα χρειαστεί πρίν βγάλουμε εντελώς τον έλεγχο
            #     x2 = node1.position_x + node1.width
            #     x1 = node2.position_x
            y = node1.position_y + (node1.height//2) # το Υ βρίσκεται στο μέσο του ύψους κάθε κόμβου
            self.canvas.create_line(x1, y, x2, y, width = 2, fill='red') # φτιάχνουμε μια γραμμή (ακμή) συνδέοντας τους κόμβους κόκκινου χρώματος (σύζυγοι)
    # Σύνδεση γονέων με παιδιά
    def draw_parental_relation(self, parent, child, canvas): # parent : γονέας child: παιδί προσθήκη και αντικειμένου canvas για να διαλέξουμε που να σχεδιάσει
        if parent.spouse != None: # αν υπάρχει σύζυγος
            if parent.position_x < parent.spouse.position_x: #γονέας αριστερά του συζύγου
                x1 = parent.position_x + parent.width + (parent.spacing_x//2) # πρώτο σημείο πρώτης γραμμής στο μέσο της απόστασης των 2 γονέων            
                y1 = parent.position_y + (parent.height//2) # και πάνω στη γραμμή που τους ενώνει
                y2  = y1 + (parent.spacing_y//2) + (parent.spacing_y//4) # δεύτερο σημείο της πρώτης γράμμης λιγο πιο κάτω (κάθετα) στο μέσο της απόστασης μεταξύ των γενεών 
                canvas.create_line(x1, y1, x1, y2, width = 2) # δημιουργία πρώτης γραμμής
                x2 = child.position_x + (child.width//2) # πρώτο σημέιο δεύτερης γραμμής στο μέσο του μήκους του κόμβου του παιδιού
                y1 = y2 # και στο ίδιο ύψος με την προηγούμενη γραμμή (στο μέσο της απόστασης μεταξύ των γενεών)
                y2 = y1 + (child.spacing_y//2) + child.width//4 - (parent.spacing_y//4) #δεύτερο σημέιο δεύτερης γραμμής στο ίδιο Χ και κάθετα προς τα κάτω για να ενωσει τον κόμβο παιδιού
                canvas.create_line(x2, y1, x2, y2, width = 2) # δημιουργία δεύτερης γραμμής
                # τρίτη γραμμή (οριζόντια)
                if x1 != x2: # αν x1 Και x2 δεν ταυτίζονται(δηλαδή υπάρχει και άλλο παιδί)
                    canvas.create_line(x1, y1, x2, y1, width = 2) # τότε ένωσε τις κάθετες γραμμές μεταξύ τους
        else: # δεν υπάρχει σύζυγος
            #ίδια λογική με πριν
            x1 = parent.position_x + (parent.width//2) # απλά η πρώτη γραμμή ξεκινάει απο τον μοναδικό γονέα (στο μέσο του μήκους του)
            y1 = parent.position_y + parent.height # και στην κάτω επιφάνεια του κόμβου
            y2  = y1 + (parent.spacing_y//2)  # και καταλήγει στο μέσο της απόστασης μταξύ των γενεών
            canvas.create_line(x1, y1, x1, y2, width = 2) # και κατευθύνεται κάθετα
            x2 = child.position_x + (child.width//2)# πρώτο σημέιο δεύτερης γραμμής στο μέσο του μήκους του κόμβου του παιδιού
            y1 = y2  # και στο ίδιο ύψος με την προηγούμενη γραμμή (στο μέσο της απόστασης μεταξύ των γενεών)
            y2 = y1 + (child.spacing_y//2) # δευτερο σημείο στο πάνω μέρος της επιφάνειας του κόμβου παιδιού
            canvas.create_line(x2, y1, x2, y2, width = 2) # δευτερη κάθετη γραμμή
            # τρίτη γραμμή (οριζόντια)
            if x1 != x2:# αν x1 Και x2 δεν ταυτίζονται(δηλαδή υπάρχει και άλλο παιδί)
                canvas.create_line(x1, y1, x2, y1, width = 2) # τότε ένωσε τις κάθετες γραμμές μεταξύ τους
    # ανενεργή συνάρτηση σύνδεσης παιδιών που που προσφέρει ΑΠΕΥΘΕΙΑΣ σύνδεση γονέων με παιδιά με ακμές (χωρίς γωνίες)
    # το αφήνω για testing καθώς επίσης είναι θέμα γούστου ποιόν απο τους δυο τρόπους θα προτιμήσουμε
    # βασίζεται στην προηγούμενη συνάρτηση 
    def draw_parental_relations(self, parent, child, canvas, x, y):
        if parent.spouse != None:
            if parent.position_x < parent.spouse.position_x:
                x1 = parent.position_x + parent.width + (parent.spacing_x//2)
                
                y1 = parent.position_y + (parent.height)  
                y2  = y1 + (parent.spacing_y//2) + (parent.spacing_y//4) - parent.height//2
                #self.canvas.create_line(x1, y1 - child.width//4, x1, y2 - child.width//4, width = 2)
                x2 = child.position_x + (child.width//2) 
                y1 = y2
                y2 = y1 + (child.spacing_y//2) + child.width//4 - (parent.spacing_y//4) 
                #self.canvas.create_line(x2, y1, x2, y2, width = 2)
                # if x1 != x2:
                #     self.canvas.create_line(x1, y1, x2, y1, width = 2)
                canvas.create_line(x1, y1 - (child.spacing_y//4) - 60, x2, y2, width = 2)
        else:
            x1 = parent.position_x + (parent.width//2) 
                
            y1 = parent.position_y + parent.height 
            y2  = y1 + (parent.spacing_y//2)
            #self.canvas.create_line(x1, y1, x1, y2, width = 2)
            x2 = child.position_x + (child.width//2) 
            y1 = y2
            y2 = y1 + (child.spacing_y//2) 
            #self.canvas.create_line(x2, y1, x2, y2, width = 2)
            # if x1 != x2:
            #     self.canvas.create_line(x1, y1, x2, y1, width = 2)
            canvas.create_line(x1, y1 - (child.spacing_y//2), x2, y2, width = 2)
    # Οργάνωση κόμβων οπτικά και προσπάθεια αποφυγής αλληλοκαλύψεων βασικά στον άξονα Χ
    def reorganize_nodes(self):
        level = 0 # μεταβλητή απθήκευσης επιπέδων (γενεών) του δέντρου
        keys = [] # αρχικοπίηση λίστας αποθήκευσης των κλειδιών απο το level_dict
        for key in self.level_dict: #iteration όλων των κλειδιών
            keys.append(key) # αποθήκευση κλειδιών στη λίστα
        while True: # λούπα ελέγχου αλληλοκαλυπτόμενων κόμβων στην ίδια γενιά
            found = False # boolean ελέγχου αλληλοκαλυπτόμενων κόμβων
            for level in keys: #iteration στις γενιές
                for node in self.level_dict[level]: # iteration στου κόμβους της γενιάς
                    for comparison_node in self.level_dict[level]: # σύγκριση με τους υπόλοιπους κόμβους της γενιάς
                        if node != comparison_node: #αποφυγή ελέχγου του κόμβου με τον εαυτό του
                            if node.position_x == comparison_node.position_x: #έχουμε αλληλοκάλυψη
                                node.position_x = node.position_x - node.width - node.spacing_x # διόρθωση θέσης κόμβου
                                if node.spouse != None: #αν υπάρχει σύζυγος
                                    node.spouse.position_x = node.spouse.position_x - node.width - node.spacing_x # διόρθωση θέσης και του συζύγου
                                found = True # βρέθηκε αληλλοκάλυψη
                            elif (node.position_x + node.width) == comparison_node.position_x: # κολλημενοι κόμβοι μεταξύ τους
                                node.position_x = node.position_x - node.spacing_x # διόρθωση θέσης κόμβου
                                if node.spouse != None:#αν υπάρχει σύζυγος
                                    node.spouse.position_x = node.spouse.position_x - node.spacing_x # διόρθωση θέσης και του συζύγου
                                found = True # βρέθηκε αληλλοκάλυψη (εφαπτόμενοι κόμβοι)
            if not found: # όταν δεν υπάρχουν άλλες αλληλοκαλύψεις
                break # τερματισμός λούπας
        #Επαναδιάταξη παιδιών 
        for level in sorted(keys)[1:]: # iteration απο τη δευτερη γενια ([1:]) και κάτω μιας και η πρώτη γενια (0) δεν έχει γονείς
            parents_dict = {} #  είναι ένα λεξικό αποθηκεύσης των κόμβων-γονείς ως τιμές με τα αντίστοιχα κόμβους-παιδιά ως κλειδιά
            parent_list = [] # λίστα αποθήκευσης μοναδικών γονικών κόμβων καθε γενιας για την αποφυγή διπλότυπων
            coordinate_list = [] # Λιστα αποθήκευσης Χ συντεταγμένων παιδιών κάθε γενιάς για την επαναδιάταξη
            parent_coordinate_list = [] # Λιστα αποθήκευσης Χ συντεταγμένων γονέων τρέχων γενιάς για την επαναδιάταξη
            parent_coordinate_dict = {} # Λεξικό αντιστοίχισης Χ συντεταγμένων γονέων (key:Χ συντεταγμενη,value:γονικοί κόμβοι)
            node_list = [] # λίστα αποθήκευσης κόμβων παιδιών για το σορτάρισμα ανάλογα με τους γονεις
            for node in self.level_dict[level]: #Iteration στα node του επιπέδου 
                for comparison_node in self.level_dict[level - 1]:# και σύγκρισή τους με τα Nodes του προηγούμενου επιπέδου (γονείς)
                    if node in comparison_node.children: # Αν ο κόμβος ανήκει στα παιδιά του υπο σύγκριση κόμβου
                        parent_node = comparison_node # ορισμός του υπο σύγκριση κόμβου ως κόμβου γονέα
                        parents_dict[node] = parent_node # και αποθήκευση στο λεξικό της σχέσης μεταξύ γονέα και κόμβου παιδιού 
                        if parent_node not in parent_list: # αν ο γονικός κόμβος δεν υπάρχει στη λιστα μονδικών γονικών κόμβων
                            parent_list.append(parent_node) #τότε προσθήκη
                            parent_coordinate_list.append(parent_node.position_x) #και αποθήκευση συντεταγμένη Χ στη λίστα
                            parent_coordinate_dict[parent_node.position_x] = parent_node # όπως επίσης και στο λεξικό ως κλειδί η συντεταγμένη
                coordinate_list.append(node.position_x) # προσθήκη της θεσης Χ του κόμβου στη λίστα συντεταγμένων
            node_list = [] # Αρχικοποίηση λίστας παιδιών για να βάλουμε τα παιδιά με τη σειρά που θέλουμε
            # Ταξινόμηση γονέων σύμφωνα με την Χ συντεταγμένη και iteration
            for parent in sorted(parent_list, key=lambda x: x.position_x):
                # Ταξινόμηση παιδιών ανάλογα με το αν έχουν σύζυγο ή όχι (θέλουμε το παιδί με σύζυγο να μπει τερμα δεξιά για αποφυγή συγχύσεων)
                sorted_children = sorted(parent.children, key=lambda child: child.spouse is not None)
                for child in sorted_children: # Για κάθε παιδί στην ταξινομημένη λίστα παιδιών του γονέα
                    node_list.append(child) # προσθήκη παδιών στη λίστα παιδιων με τη σειρά
            # Ορισμός νεων ταξινομημένων συντεταγμένων
            # Εδω κάνουμε χρήση της συνάρτησης zip που δημιουργει ζευγάρια απο τις δυο λίστες
            # https://realpython.com/python-zip-function/
            for node, coord in zip(node_list, sorted(coordinate_list)): # Ορίζουμε τις νεες συντεταγμένες Χ των κόμβων 
                offset = coord - node.position_x # Υπολογισμός πόσο θα μετακινηθέι το παιδί
                node.position_x = coord # Σύμφωνα με σύμφωνα με τις ταξινομημένες συντεταγμένες της λίστας coordinate_list
                self.update_descendants_x_position(node, offset) # κουνάμε όλους τους απογόνους σύμφωνα με το offset
            coordinate_list = [] # Λιστα αποθήκευσης Χ συντεταγμένων τρέχων γενιάς για την επαναδιάταξη
            node_list = [] # Λίστα αποθήκευσης κόμβων σε συγκεκριμένη σειρά
            node_coordinate_dict = {} # Λεξικό που αντιστοιχίζει τις Χ συντεταγμένες και τους κόμβους σε μια γενιά
            number_married = 0 # Μετρητής κόμβων που έχουν σύζυγο στο τρέχον επίπεδο
            for node in self.level_dict[level]: #για κάθε κόμβο στο τρέχων επίπεδο
                coordinate_list.append(node.position_x) # Αποθήκευση της Χ συντεταγμένης του κόμβου στη λίστα 
                node_coordinate_dict[node.position_x] = node # και στο λεξικό
                if node.spouse != None: # Αν υπάρχει σύζυγος
                    number_married += 1 #Αυξηση δείκτη παντρεμένων κατά 1
            sorted_coordinates = sorted(coordinate_list) # ταξινόμηση λίστας συντεταγμένων και αποθήκευση στο sorted_coordinates
            start_x = sorted_coordinates[0] # Ορισμός αρχικού Χ στο πρώτο στοιχείο του sorted_coordinates
            # n = Person() 
            # for i in range(1):
            #     start_x = start_x - n.spacing_x - n.width
            for coord in sorted_coordinates: # για κάθε συντεταγμένη στις λίστα με τις ταξινομημένες συντεταγμενες
                node = node_coordinate_dict[coord] # παίρνουμε τον κόμβο απο το λεξικό
                node.position_x = start_x # Ορίζουμε την συντεταγμένη Χ
                start_x = start_x + node.width + node.spacing_x # Την αυξάνουμε σύμφωνα με τις αποστάσεις για να την θέσουμε στον επόμενο κόμβο
                if node.spouse != None:# αν έχουμε σύζυγο δίνουμε προτεραιότητα
                    node.spouse.position_x = start_x # Ορίζουμε την συντεταγμένη Χ του συζύγου
                    start_x = start_x + node.width + node.spacing_x # Και Την αυξάνουμε σύμφωνα με τις αποστάσεις για να την θέσουμε στον επόμενο κόμβο
    def reorganize_nodes2(self):
        level = 0 # μεταβλητή απθήκευσης επιπέδων (γενεών) του δέντρου
        keys = [] # αρχικοπίηση λίστας αποθήκευσης των κλειδιών απο το level_dict
        for key in self.level_dict: #iteration όλων των κλειδιών
            keys.append(key) # αποθήκευση κλειδιών στη λίστα
        while True: # λούπα ελέγχου αλληλοκαλυπτόμενων κόμβων στην ίδια γενιά
            found = False # boolean ελέγχου αλληλοκαλυπτόμενων κόμβων
            for level in keys: #iteration στις γενιές
                for node in self.level_dict[level]: # iteration στου κόμβους της γενιάς
                    for comparison_node in self.level_dict[level]: # σύγκριση με τους υπόλοιπους κόμβους της γενιάς
                        if node != comparison_node: #αποφυγή ελέχγου του κόμβου με τον εαυτό του
                            if node.position_x == comparison_node.position_x: #έχουμε αλληλοκάλυψη
                                node.position_x = node.position_x - node.width - node.spacing_x # διόρθωση θέσης κόμβου
                                if node.spouse != None: #αν υπάρχει σύζυγος
                                    node.spouse.position_x = node.spouse.position_x - node.width - node.spacing_x # διόρθωση θέσης και του συζύγου
                                found = True # βρέθηκε αληλλοκάλυψη
                            elif (node.position_x + node.width) == comparison_node.position_x: # κολλημενοι κόμβοι μεταξύ τους
                                node.position_x = node.position_x - node.spacing_x # διόρθωση θέσης κόμβου
                                found = True # βρέθηκε αληλλοκάλυψη (εφαπτόμενοι κόμβοι)
            if not found: # όταν δεν υπάρχουν άλλες αλληλοκαλύψεις
                break # τερματισμός λούπας
        
        
    # Αναδιάταξη παιδιών και ευθυγράμμιση με τους γονείς
    def reposition_children(self, selected_individual):
        children_count = len(selected_individual.children) # Υπολογισμός παιδιών του επιλεγμένου κόμβου
        line_length = (selected_individual.width * children_count) // 2 - (selected_individual.width//2) #Υπολογισμός μήκους γραμμής
        line_length += (selected_individual.spacing_x * (children_count -1)//2) # που θα καλύψει το μήκος των παιδιών
        if selected_individual.position_x > selected_individual.spouse.position_x: # αν ο γονέας βρίσκεται δεξιά του συζύγου
            return                                                                 # τοτε επιστροφή (μας ενδιαφέρει μόνο ο αριστερός γονέας)
        initial_x = selected_individual.position_x + selected_individual.width # υπολογισμός αρχικών συντεταγμένων Χ και
        initial_y = selected_individual.position_y                             # και Υ
        # for child in self.everyone[self.current_shape].children:
        # self.everyone[self.current_shape].children = []
        start_x = initial_x  - line_length # συντεταγμένες εκκίνησης σχεδιασμού κόμβων παιδιών Χ 
        start_y = initial_y + selected_individual.spacing_y + selected_individual.height # και Υ (μια γενια πάνω)
        for i in range(children_count): #διατρέχουμε όλα τα παιδιά
            #print(i)
            child = selected_individual.children[i] #επιλογή κάθε παιδιού
            child.position_x = start_x # και τοποθέτησή τους στις συντεταγμένες Χ
            child.position_y = start_y # και Υ (η Υ δεν αλλάζει φυσικά)
            if selected_individual.spouse != None: # αν υπάρχει σύζυγος
                if child not in selected_individual.spouse.children: # και δεν ειναι το παιδί καταχωρημένο σε αυτόν
                    selected_individual.spouse.children.append(child) # τότε καταχώρησέ το
            start_x += selected_individual.width + selected_individual.spacing_x # αύξηση του Χ σύμφωνα με τις αποστάσεις γισ νσ μπει το επόμενο παιδί
        #self.draw_family_tree()
    # Οργάνωση κόμβων ανα επίπεδο (γενιά)
    def group_nodes_by_levels(self):
        for person in self.person_list: # διατρέχουμε όλα τα άτομα του δέντρου
            self.level_dict[person.level] = [] # Αρχικοποιούμε τα κλειδιά (επίπεδα) του λεξικού με κενές λίστες    
        for person in self.person_list: # διατρέχουμε πάλι όλα τα άτομα του δέντρου
            self.level_dict[person.level].append(person) # προσθήκη του ατόμου στο λεξικό στο αντίστοιχο κλειδί (γενιά)
        #print(self.level_dict)
    # Σχεδιασμός Δέντρου
    def draw_family_tree(self): # Αυτή η συνάρτηση καλείται για να σχεδιάσει/ανανεώσει το δέντρο
        self.group_nodes_by_levels() # Οργάνωση κόμβων ανα επίπεδο
        self.reorganize_nodes2() # Οργάνωση κόμβων για την αποφυγή αλληλοκαλύψεων
        self.canvas.delete("all") # Καθαρίζουμε τον καμβά https://stackoverflow.com/questions/15839491/how-to-clear-tkinter-canvas
        for person in self.person_list: # Διατρέχουμε όλα τα άτομα του δέντρου
            x = person.position_x # μεταβλητες πουτ αποθηκεύουν τις πληροφορίες του κόμβου ...μεταβλητή Χ
            y = person.position_y # μεταβλητή Υ
            width = person.width # πλάτος κόμβου
            height = person.height # ύψος κόμβου
            color = OTHER_COLOR_VALUE # χρώματισμός κόμβου...ξεκινάμε με το non binary
            if person.gender == "Άρρεν": # Άνδρας
                color = MALE_COLOR_VALUE #χρωματισμός Άνδρα
            if person.gender == "Θήλυ": # Γυναίκα
                color = FEMALE_COLOR_VALUE # Χρωματισμός Γυναίκας
            square = self.canvas.create_rectangle(x, y, x + width, y + height, # δημιουργία παραλληλόγραμμου με τις ιδιότητές του
            outline="#333333", fill=color, width = 0,tags="single_shape") # συντεταγμένες,χρώμα,σχήμα,tag κτλ
            self.canvas.create_text(x + (width//2),y + (height//2),fill="white",font="Roboto 10", anchor="center", justify="center", # Ετικέτα ονόματος στο μέσο του παραλληλόγραμμου
                        text=person.name + "\n" + person.surname) 
            person.shape = square # Αποθήκευση σχήματος στο αντικείμενο person
            # Όλα τα τετράγωνα που αντιπροσωπεύουν άτομα στον καμβά έχουν την ετικέτα "single_shape"
            self.canvas.tag_bind("single_shape","<Button-1>",self.single_shape_clicked) # κλήση της single_shape_clicked όταν κάνουμε κλίκ με το ποντίκι
            #Προσθήκη δεξιού κλικ με lambda function.Πρώτα καλούμε το single_shape_clicked για να επιλεγεί ο κόμβος και μετά το show_context_menu για να εμφανιστεί το μενού
            self.canvas.tag_bind("single_shape", "<Button-3>", lambda event: (self.single_shape_clicked(event), self.show_context_menu(event)))
            # https://anzeljg.github.io/rin2/book2/2405/docs/tkinter/canvas-methods.html
            # https://python.hotexamples.com/examples/tkinter/Canvas/tag_bind/python-canvas-tag_bind-method-examples.html
            if person.spouse != None: # Αν εχουμε σύζυγο
                self.draw_spouse_relation(person, person.spouse) # σχεδιασμός συγγένειας συζύγων με ακμή
            if person.children: # Αν έχουμε παιδιά
                for child in person.children: # για κάθε παιδί
                    self.draw_parental_relation(person, child, self.canvas) #Σχεδιασμός συγγένειας με ακμές για τα παιδιά στον κυρίως καμβά
    # Ανάγνωση ιδιοτήτων ατόμου απο τα πλαίσια κειμένου και ενημέρωση των ιδιοτήτων του επιλεγμένου ατόμου
    def update_information(self):
        # Αποθήκευση των ιδιοτήτων των ατόμων απο τα πεδια κειμένου σε μεταβλητές
        info_1 = self.id_entry.get() # Αναγνωριστικό ID
        info_2 = self.name_entry.get() # Όνομα
        info_3 = self.surname_entry.get() #Επίθετο
        info_4 = self.option_variable.get() # φύλλο
        info_5 = self.birth_entry.get() # ημερομηνία γεννησης 
        info_6 = self.death_entry.get() # και θανάτου
        #Εντοπισμός Επιλεγμένου ατόμου με το κλασσικό πλέον τρόπο
        selected = None #αρχικοποίηση και καθαρισμός επιλεγμένου ατόμου
        for individual in self.person_list: # για κάθε άτομο στο δέντρο
            if individual.shape == self.current_shape: # αν έχουμε επιλεγμένο σχήμα
                selected = individual # Αποθήκευση επιλεγμένου
                break # και έξοδος
        if selected == None: # αν δεν έχουμε επιλέξει κάτι
            return # μη κάνεις τίποτα
        #Εισαγωγή των αποθηκευμένων ιδιοτήτων του ατόμου στην κλάση
        selected.id = info_1 # Αναγνωριστικό ID
        selected.name = info_2 # Όνομα
        selected.surname = info_3 # Επίθετο
        selected.gender = info_4 # φύλλο
        selected.birth = info_5 # ημερομηνία γεννησης
        selected.death = info_6 # και θανάτου
        self.draw_family_tree()  # ανανέωση δέντρου  
    # Αντιγραφή πληροφοριών απο αρχείο
    def fetch_information(self):
        pass
    # Εμφάνιση πληροφοριών ατόμου στα πεδία κειμένου
    def display_information(self):
        #Εντοπισμός Επιλεγμένου ατόμου με το κλασσικό πλέον τρόπο
        selected = None #αρχικοποίηση και καθαρισμός επιλεγμένου ατόμου
        for individual in self.person_list: # για κάθε άτομο στο δέντρο
            if individual.shape == self.current_shape: # αν έχουμε επιλεγμένο σχήμα
                selected = individual # Αποθήκευση επιλεγμένου
                break # και έξοδος    
        if selected == None: # αν δεν έχουμε επιλέξει κάτι
            return # μη κάνεις τίποτα
        #Αποθήκευση των ιδιοτήτων σε λίστα
        data = [selected.id, selected.name, selected.surname, selected.gender, selected.birth, selected.death
        ]
        #Και επανάκτηση τους για εισαγωγή στα αντίστοιχα πεδία
        self.id_entry.insert(0,data[0]) # Αναγνωριστικό ID
        self.name_entry.insert(0,data[1]) # Όνομα
        self.surname_entry.insert(0,data[2]) # Επίθετο
        self.option_variable.set(data[3]) # φύλλο
        self.birth_entry.insert(0,data[4]) # ημερομηνία γεννησης
        self.death_entry.insert(0,data[5]) # και θανάτου
    # καθαρισμός πεδίων πληροφοριών (πλαίσια κειμένου)
    def clear_information(self):
        self.id_entry.delete(0, END) # Αναγνωριστικό ID
        self.name_entry.delete(0, END) # Όνομα
        self.surname_entry.delete(0, END) # Επίθετο
        self.option_variable.set("Επιλογή") # φύλλο
        self.birth_entry.delete(0, END) # ημερομηνία γεννησης
        self.death_entry.delete(0, END) # και θανάτου
    # Αποθήκευση δέντρου σε αρχείο JSON
    def save_data(self):
        #data = list(self.shape_data.values())
        data = [] # Αρχικοποίηση κενής λίστας που θα χρησιμοποιηθεί για την αποθήκευση του δέντρου
        for person in self.person_list: # για κάθε άτομο στη λίστα
            person_data = {} # Αρχικοποίηση λεξικού που αποθηκέυει τις ιδιότητες του ατόμου (key:ιδιότητα value:τιμή)
            # Αποθήκευση σε μεταβλητές
            id = person.id # Αναγνωριστικό ID
            name = person.name # Όνομα
            surname = person.surname # Επίθετο
            gender = person.gender # φύλλο
            birth = person.birth # ημ/ν/ια γέννησης
            death = person.death # και θανάτου
            spouse = person.spouse # Σύζυγος
            children = person.children # παιδιά
            x_pos = person.position_x # Συντεταγμένη Χ
            y_pos = person.position_y # Συντεταγμένη Υ
            level = person.level # Γενιά
            # Αν οι παραπάνω μεταβλητές περιέχουν τιμές τότε αποθήκευση στο λεξικό με τα κλειδιά τους 
            if id:
                person_data["id"] =  id # Αναγνωριστικό ID
            if name:
                person_data["name"] = name # Όνομα
            if surname:
                person_data["surname"] = surname # Επίθετο
            if gender:
                person_data["gender"] = gender # φύλλο
            if birth:
                person_data["birth"] = birth # ημ/ν/ια γέννησης
            if death:
                person_data["death"] = death  # και θανάτου          
            if spouse != None: #αν υπάρχει σύζυγος
                person_data["spouse"] = str(spouse.id) # το ID του/της συζύγου
            if children != None: # Αν έχουμε παιδιά 
                person_data["children"] = [] #αρχικοποίηση λίστας που τα αποθηκέυει
                for child in children: #iteration για κάθε παιδί
                    person_data["children"].append(str(child.id)) #Και αποθήκευση στη λίστα
            person_data["x"] = str(x_pos) # Συντεταγμένη Χ
            person_data["y"] = str(y_pos) # Συντεταγμένη Υ
            person_data["level"] = str(level) # Γενιά
            data.append(person_data) # Προσθήκη του ολοκληρωμένου λεξικού στη λίστα
            filename = "output1.json" # Αρχείο αποθήκευσης,ίσως χρειαστει να βάλουμε User input interaction για την επιλογή ονόματος με το fd
            # Αποθήκευση της λίστα σε JSON format
            # https://www.geeksforgeeks.org/json-dump-in-python/
            with open(filename, "w") as outfile:
                json.dump(data, outfile, indent=4, separators=(',', ': '))
    # Εισαγωγή Δέντρου απο αρχείο
    def import_data(self):
        # πλαίσιο διαλόγου για την επιλογή αρχείου προς εισαγωγή
        # https://docs.python.org/3/library/dialog.html
        # https://pythonspot.com/tk-file-dialogs/
        filename = fd.askopenfilename() # το όνομα του αρχείου που επιλέξαμε
        if not filename: # αν δε διαλέξουμε,ακύρωση κτλ
            return # μη κάνεις τίποτα
        self.person_list = [] # Άδειασμα της λίστας των ατόμων για επανεισαγωγή απο το αρχείο
        #ανοίγουμε το αρχείο για διάβασμα
        file = open (filename, "r") # https://tutorial.eyehunts.com/python/python-file-modes-open-write-append-r-r-w-w-x-etc/
        """ΣΗΜΑΝΤΙΚΟ!Εδώ θα χρειαστεί να εισάγουμε αμυντικό προγραμματισμό που να εξασφαλίζει οτι το αρχείο έχει το σωστό format και τα σωστα
            δεδομένα.Μια ιδέα είναι να βάλουμε ενα μοναδικό αναγνωριστικό μέσα στο αρχείο JSON που θα μας επιτρεπει να καταλάβουμε οτι το
            αρχείο δημιουργήθηκε απο την εφαρμογή μας"""
        # Διάβασμα/προσπέλαση του JSON
        # https://www.geeksforgeeks.org/json-loads-in-python/
        data = json.loads(file.read())
        # Διατρέχουμε το JSON και αποκτούμε πρόσβαση στα λεξικά του
        for dict in data: # Για κάθε λεξικό στη λίστα του JSON
            person = Person() # δημιουργουμε ενα αντικείμενο τύπου person,ενα άτομο δηλαδή για να εισάγουμε τις ιδιότητες του
            # Αν οι ιδιότητες είναι υπαρκτές στο λεξικό τότε τις εισάγουμε
            if "id" in dict:
                person.id = dict["id"] # Αναγνωριστικό ID
            if "name" in dict:
                person.name = dict["name"] # Όνομα
            if "surname" in dict:
                person.surname = dict["surname"] # Επίθετο    
            if "gender" in dict:
                person.gender = dict["gender"] # φύλλο
            if "birth" in dict:
                person.birth = dict["birth"] # ημ/ν/ια γέννησης
            if "death" in dict:
                person.death = dict["death"] # και θανάτου 
            if "children" in dict:
                person.children = dict["children"] # παιδιά.Προσοχή!Αυτό γυρίζει το ID του παιδιού,αλλά εμέις θέλουμε το αντικείμενο τύπου person για αυτό μετατρέπουμε παρακάτω
            if "spouse" in dict:
                person.spouse = dict["spouse"] # σύζυγος!Ομοίως με τα παιδιά
            if "x" in dict:
                person.position_x = int(dict["x"]) # Συντεταγμένη Χ
            if "y" in dict:
                person.position_y = int(dict["y"]) # Συντεταγμένη Υ
            if "level" in dict:
                person.level = int(dict["level"]) # Γενιά   
            self.person_list.append(person) # προσθήκη του ατόμου στη γενική λίστα ατόμων
        # Κλείσμο αρχείου μετά την προσπέλαση
        file.close()
        #print("length", (self.person_list))
        # διόρθωση αναφορών παιδιών απο το ID τους σε αντικείμενα
        for person in self.person_list: # προσπέλαση όλων των ατόμων στη λίστα
            children_count = len(person.children) # αποθήκευση αριθμού παιδιών του ατόμου σε μεταβλητή
            if children_count > 0: # αν έχουμε παιδιά
                for i in range(children_count): # προσπέλαση τους
                    #print(i)
                    if isinstance(person.children[i], str): # Αν η ιδιότητα children[i] είναι τύπου string (δλδ ID απο την εισαγωγή) θέλει μετατροπή
                        for each in self.person_list: # Για κάθε άτομο ξανά απο το σύνολο των ατόμων
                            if each.id == person.children[i]: # Αν εχουν το ID για ιδιότητα
                                person.children[i] = each # μετατροπή σε αντικείμενο και αποθήκευση Overwrite στην ιδιότητα του αντικειμένου αυτή τη φορά
                                break #εξοδος και επόμενο ατομο
            # Ίδια λογική ακολουθειται για τους συζύγους
            if person.spouse != "None": # Υπάρχει σύζυγος
                for each in self.person_list: # για κάθε άτομο στη συνολική λίστα
                    if each.id == person.spouse: # αν το ID του συζύγου ταιριάζει με αυτό απο το εισαγόμενο αρχείο
                        person.spouse = each # αντικατέστησε το με αντικείμενο τυπου person και δήλωσε το σύζυγο
                        break # εξοδος και επόμενο ατομο
            else: # δεν εχουμε σύζυγο
                person.spouse = None # αντικατάσταση του string με None
        self.draw_family_tree() # Σχεδιασμός δέντρου για την εμφάνιση δέμτρου που εισάγαμε απο αρχείο 
    # καθαρισμός όλων των κόμβων
    def clear_all(self):
        # Προσθήκη παραθύρου διαλόγου πριν την διαγραφή με προειδοποίηση
        # https://www.geeksforgeeks.org/python-tkinter-askquestion-dialog/
        msg_box = messagebox.askquestion('Διαγραφή Όλων', 'Είστε σίγουροι οτι θέλετε να διαγράψετε όλους τους κόμβους?', 
                                        icon='warning') # Προειδοποίηση
        if msg_box != 'yes': # ακύρωση
            return
        self.person_list = [] # Απλά καθαρίζουμε τη λίστα με τα συνολικά άτομα
        self.draw_family_tree() # και ανανεώνουμε τον σχεδιασμό του καμβά
    # Διαγραφή ατόμου
        """Η λογική που ακολουθούμε για την διαγραφή του ατόμου έχει ώς εξής:
        Εκτός απο την διαγραφή του ίδιου του ατόμου διαγράφουμε και τους απογόνους του σε περίπτωση που το ιδιο το άτομο αποτελεί το μοναδικό σύνδεσμο μεταξύ προηγούμενης
        και επόμενης γενιάς γιατί αλλιώς θα έχουμε κενό μεταξύ των γενεών και θα δημιουργηθούν προβλήματα.Οι περιπτώσεις που εξετάζουμε είναι:
        1. Το άτομο να έχει γονείς και παιδιά αλλά όχι σύζυγο (διαγραφή απογόνων)
        2. Το άτομο να έχει γονείς και παιδιά και σύζυγο χωρίς γονείς (διαγραφή απογόνων και συζύγου)
        """
    def delete_node(self):
        if self.current_shape == None:
            messagebox.showwarning(title="Δέν έχει επιλεγεί κόμβος", message="Παρακαλώ επιλέξτε τον κόμβο που θέλετε να διαγράψετε")
            return
        # Προσθήκη παραθύρου διαλόγου πριν την διαγραφή με προειδοποίηση
        # https://www.geeksforgeeks.org/python-tkinter-askquestion-dialog/
        msg_box = messagebox.askquestion('Προειδοποίηση Διαγραφής!', 'Είστε σίγουροι οτι θέλετε να διαγράψετε τον επιλεγμένο κόμβο? \nΑυτή η ενέργεια μπορεί να διαγράψει και όλους τους απογόνους του κόμβου!',
                                        icon='warning') # Προειδοποίηση
        if msg_box != 'yes': # ακύρωση
            return
        # else:    
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                break
        # Ομαδοποίηση κόμβων ανα επίπεδο (γενιά) και έλεγχος για γονείς
        self.group_nodes_by_levels()
        nodes_above = [] # Αρχικοποίηση λίστας αποθήκευσης κόμβων προηγούμενης γενιάς
        if (selected_individual.level - 1) in self.level_dict: # Έλεγχος επιπέδου που είναι μία γενιά πάνω από το επίπεδο του επιλεγμένου ατόμου (γονείς) στο self.level_dict.
            nodes_above = self.level_dict[selected_individual.level - 1] # Αν υπάρχει, αποθηκεύση της λίστας των κόμβων που ανήκουν σε αυτό το επίπεδο στη μεταβλητή nodes_above.
        has_parent = False # Μεταβλητή παρακολούθησης αν ο επιλεγμένος κόμβος έχει γονείς
        # Έλεγχος αν ο σύζυγος του επλεγμένου ατόμου υπάρχει και αν υπάρχει έλεγχος αν εχει παιδιά
        spouse_has_parent = False # boolean μεταβλητή ελέγχου ύπαρξης γονέων του συζύγου
        for node in nodes_above: # για κάθε κόμβο στη γενιά γονέων
            if selected_individual in node.children: # αν ο επιλεγμένος κόμβος έχει γονείς
                has_parent= True # αλλαγή της μεταβλητής σε αληθή
            if selected_individual.spouse != None: # Αν υπάρχει σύζυγος
                if selected_individual.spouse in node.children: # αν ο σύζυγος έχει γονείς (αντιστρόφως αν στη λίστα γονέων υπάρχει κόμβος με δηλωμένο παιδί τον/την σύζυγο)
                    spouse_has_parent = True # Εχει ο σύζυγος γονείς και μετατροπή της μεταβλήτής σε αληθή
        # πρίν τη διαγραφή του κόμβου πρέπει να τον αφαιρέσουμε και ως σύζυγο απο τον/την σύζυγο!
        if selected_individual.spouse != None: # αν υπάρχει σύζυγος
            selected_individual.spouse.spouse = None # αφαίρεση του ατόμου απο τον σύζυγο ώς σύζυγο
        if not spouse_has_parent and has_parent: # αν ο σύζυγος δεν έχει γονείς πρέπει να διαγραφεί και αυτός μαζί με τους απογόνους για να μη μείνει ξεκρέμαστος
            recursively_delete_children(selected_individual, self.person_list) # κλήση αναδρομικής συνάρτησης διαγραφής παιδιών
            if selected_individual.spouse != None: # αν πάρχει σύζυγος
                self.person_list.remove(selected_individual.spouse) # διέγραψέ τον
        for node in nodes_above: # για κάθες κόμβο στο επίπεδο γονέων
            if selected_individual in node.children: # Αν ο επιλεγμένος κόμβος ανήκει στα παιδιά του
                node.children.remove(selected_individual) # Διαγραφή απο παιδί
        self.person_list.remove(selected_individual) # Και εν τέλει διαγραφή και του ίδιου το ατόμου
        self.draw_family_tree() # Επανασχεδιασμός δέντρου
    # Αποθήκευση σε αρχείο εικόνας (δεν έχει υλοποιηθεί ακόμα)
    def export_data(self):
        save_as_png(self.canvas, "trial")
    # Εμφάνιση παραθύρου βοήθειας (υπο υλοποίηση)
    def show_help(self):
        # https://www.geeksforgeeks.org/python-tkinter-toplevel-widget/
        help_window = Toplevel(root) # δημιουργία αναδυόμενου παραθύρου
        help_window.geometry("640x400") # διαστάσεις παραθύρου
        help_window.title("Βοήθεια") # τίτλος
        help_text = Label(help_window, text = "Εμφάνιση βοήθειας για την εφαρμογή") # δημιουργία ετικέτας label
        help_text.pack() # τοποθέτηση της ετικέτας με τη μέθοδο pack https://www.pythontutorial.net/tkinter/tkinter-pack/
        # Ακολουθεί κώδικας με οδηγίες χειρισμού της εφαρμογής 
    # Συνάρτηση για την εμφάνιση των πληροφοριών του ατόμου
    # Προαπαιτούμενο
    def show_person_info(self):
        # Εύρεση ατόμου Με τον κλασσικό τρόπο
        selected = None
        for person in self.person_list:
            if person.shape == self.current_shape:
                selected = person
                break
        if selected is None:
            return
        # Δημιουργία παραθύρου για τις πληροφορίες Ατόμου
        # for testing purpose ...Χρειάζεται επανασχεδιασμός!!
        info_window = Toplevel(self.canvas)
        info_window.title("Πληροφορίες Ατόμου")
        info_window.geometry("300x200")
        # Προσθήκη ετικετών
        Label(info_window, text="ID:").grid(row=0, column=0)
        Label(info_window, text="Όνομα:").grid(row=1, column=0)
        Label(info_window, text="Γένος:").grid(row=2, column=0)
        Label(info_window, text="Ημν/νία Γέννησης:").grid(row=3, column=0)
        Label(info_window, text="Ημνία Θανάτου:").grid(row=4, column=0)
        # Εμφάνιση πληροφοριών
        Label(info_window, text=selected.id).grid(row=0, column=1)
        Label(info_window, text=selected.name).grid(row=1, column=1)
        Label(info_window, text=selected.gender).grid(row=2, column=1)
        Label(info_window, text=selected.birth).grid(row=3, column=1)
        Label(info_window, text=selected.death).grid(row=4, column=1)
    # Δημιουργία και παραμετροποίηση γραφικού περιβάλλοντος GUI ή UI
    def initUI(self):
        # https://python-textbok.readthedocs.io/en/1.0/Introduction_to_GUI_Programming.html
        # https://zetcode.com/tkinter/introduction/
        # https://stackoverflow.com/questions/62536863/tkinter-help-difference-between-master-and-root-keywords-in-this-code
        self.master.title("Οικογενειακό Δέντρο") # Τίτλος του κυρίως παραθύρου
        # https://stackoverflow.com/questions/28089942/difference-between-fill-and-expand-options-for-tkinter-pack-method
        self.pack(fill=BOTH, expand=1) # https://www.youtube.com/watch?v=40nqqDD3Frk Δημιουργία επετασιμου παραθύρου που αξιοποιεί όλο το χώρο
        # δημιουργία ενός νέου αντικείμενο Style από τη βιβλιοθήκη ttk της Tkinter για την προσαρμογή της εμφάνισης των widgets.
        # έτσι μπορούμε να δημιουργήσουμε προκαθοριθσμένα στυλ για την διαχείριση των στοιχείων το GUI...κουμπιά λίστες πλαισια κειμένου κτλ
        # https://www.pythontutorial.net/tkinter/ttk-style/
        style = ttk.Style()
        """χρησιμοποιούμε το αντικείμενο Style που δημιουργήθηκε προηγουμένως για να προσαρμόσoυμε την εμφάνιση των κουμπιών (TButton)
            της εφαρμογής. Η μέθοδος configure ορίζει τις ιδιότητες του στυλ που θέλουμε να αλλάξουμε. το όνομα του στύλ είναι W.Tbutton"""
        style.configure('W.TButton', font = # Γραμματοσειρές
                    ('calibri', 10, 'bold', 'underline'), # χρώμα κτλ
                        foreground = 'red')
        # με τον ίδιο τρόπο ορίχουμε το στυλ των κουμπιών του μενού
        style.configure("TMenubutton", background="#cccccc") # φόντο σε γκριζάκι
        # Δημιουργία μπάρας μενού
        menu = Menu(self.master, bg="gray") # δημιουργία μπάρας με το όνομα menu για το περιβάλλον self.master (μαστερ παραθυρο) με φόντο γκρίζο
        self.master.config(menu=menu) # ορισμός του menu που φτιάξαμε πριν...ως menu ! σωστά μαντέψατε!!
        # Δημιουργία του αντικειμένου file ("Αρχείο") χωρίς δυνατότητα αποκόλλησης απο την εφαρμογή
        file = Menu(menu, tearoff = 0) # https://www.geeksforgeeks.org/what-does-the-tearoff-attribute-do-in-a-tkinter-menu/
        #Εισαγωγή εντολών και επιλογών https://www.tutorialspoint.com/python/tk_menu.htm
        file.add_command(label="Εισαγωγή απο αρχείο", command=self.import_data) # προσθηκη στο υπομενου file επιλογής εισαγωγη απο αρχείο(τρεχει την self.import_data κατά την επιλογή του χρήστη)
        file.add_command(label="Εξαγωγή απο αρχείο", command=self.save_data) # Αντίστοιχα επιλογη εξαγωγής σε αρχείο με την αντίστοιχη συναρτηση που θα κληθεί αν ο χρήστης την επιλέξει
        file.add_command(label="Εξαγωγή σε εικόνα .PNG", command=self.export_data) # ομοίως εξαγωγή σε εικόνα 
        #Προσθήκη του υπομενου "file" με τις επιλογές που φτιάξαμε παραπάνω στη μπαρα με ετικέτα "Aρχείο"
        # https://pythonbasics.org/tkinter-menu/
        menu.add_cascade(label="Αρχείο", menu=file) # προσθήκη στο υπομενού
        # με την ίδια ακριβώς λογική φτιάχνουμε το μενού βοήθειας
        help = Menu(menu, tearoff = 0)
        help.add_command(label="Εμφάνιση Βοήθειας", command=self.show_help) # συναρτηση show_help (υπο υλοποίηση)
        #Με τον ίδιο τρόπο όπως πιο πάνω προσθέτουμε και την επιλογή της βοήθειας για την εφαρμογή
        menu.add_cascade(label="Βοήθεια", menu=help)
        # Δημιουργία πλαισίων
        # Εδω θα χρησιμοποιήσουμε την Custom Tkinter Βιβλιοθήκη για όμορφα αποτελέσματα
        # https://pypi.org/project/customtkinter/0.3/
        # Θα δημιουργήσουμε 4 frame
        # 1. Το main_frame που θα περιέχει όλα τα άλλα πλαίσια
        self.main_frame = customtkinter.CTkFrame(self) # δημιουργία του πλαισίου
        self.main_frame.pack(fill = BOTH, expand = True) # Επεκτάσιμο και γεμίζει κατακόρυφα και οριζόντια σε ολο το παράθυρο (fill =BOTH)
        # 2. Το buttons_frame που θα περιέχει τα κουμπιά ελέγχου των κόμβων ("προσθήκη γονέων" κτλ)
        # σημείωση:εδω αντί για pack χρησιμοποιούμε grid μέθοδο
        # https://www.pythontutorial.net/tkinter/tkinter-grid/
        self.buttons_frame = customtkinter.CTkFrame(self.main_frame) # δημιουργία του πλαισίου στο main_frame
        # γραμμη και στήλη 0 (πάνω αριστερά),sticky west east north south(πιάνει όλο το χώρο του κελιού του),και περιθώριο 10 απο αριστερά-δεξιά και 20 απο πάνω-κάτω
        self.buttons_frame.grid(row = 0, column = 0, sticky="ewns", padx = 10, pady = 20) 
        # 3. Το information_frame που περιέχει τα πεδία κειμένου πληροφοριών του επιλεγμένου ατόμου
        self.information_frame = customtkinter.CTkFrame(self.main_frame) # δημιουργία του πλαισίου στο main_frame
        self.information_frame.grid(row = 1, column = 0,sticky="ewns", padx = 10, pady = 20) # γραμμή 1 (κάτω απο το buttons_frame)
        # Το canvas_frame που περιέχει τον καμβά σχεδίασης του δέντρου
        self.canvas_frame = Frame(self.main_frame) # δημιουργία του πλαισίου στο main_frame
        # 2η στήλη (δεξιά των άλλων 2 πλαισίων) και rowspan 2 που σημάινει επεκτείνεται σε 2 γραμμές (καλύπτοντας ουσιαστικά όλο το υψος του main frame)
        self.canvas_frame.grid(row = 0, column = 1, rowspan=2, sticky="ewns", padx = 20, pady = 20) 
        # Δημιουργία κουμπιών ελεγχου
        # Εδω παλι θα χρησιμοποιήσουμε την customtkinter.Τα κουμπιά αποτελουν instances της κλασης CTkButton απο την customtkinter
        # εχουν εύρος πλήρες απο αριστερά προς τα δεξιά (sticky="ew"),πιανουν χώρο 2 στηλών και πάλι τοποθετούνται με τη μέθοδο grid
        # Αρχικά βάζουμε μια κενή ετικέττα για λόγους συμμετρίας και ομορφιάς
        empty = customtkinter.CTkLabel(self.buttons_frame, text = "") # κενή ετικέττα
        empty.grid(columnspan=2, sticky="ew", padx = 30) 
        # Κουμπί προσθήκης νέου κόμβου που καλεί την αντίστοιχη συνάρτηση
        self.add_node_button = customtkinter.CTkButton(self.buttons_frame, text = "Προσθήκη Κόμβου", command=self.add_new_node)
        self.add_node_button.grid(columnspan=2, sticky="ew", padx = 30)
        # Κουμπί προσθήκης παιδιού που καλεί την αντίστοιχη συνάρτηση
        self.add_child_button = customtkinter.CTkButton(self.buttons_frame, text = "Προσθήκη Παιδιού", command=self.add_child)
        self.add_child_button.grid(columnspan=2, pady = 8, sticky="ew", padx = 30)
        # Κουμπί προσθήκης συζύγου που καλεί την αντίστοιχη συνάρτηση
        self.add_spouse_button = customtkinter.CTkButton(self.buttons_frame, text = "Προσθήκη Συζύγου", command=self.add_spouse)
        self.add_spouse_button.grid(columnspan=2, sticky="ew", padx = 30)
        # Κουμπί προσθήκης γονέων που καλεί την αντίστοιχη συνάρτηση
        self.add_parents_button = customtkinter.CTkButton(self.buttons_frame, text = "Προσθήκη Γονέων", command=self.add_parents)
        self.add_parents_button.grid(columnspan=2, pady = 8, sticky="ew", padx = 30)
        # Κουμπί προσθήκης αδελφών που καλεί την αντίστοιχη συνάρτηση
        self.add_sibling_button = customtkinter.CTkButton(self.buttons_frame, text = "Προσθήκη Αδελφών", command=self.add_sibling)
        self.add_sibling_button.grid(columnspan=2, sticky="ew", padx = 30)
         # Κουμπί διαγραφής κόμβου
        self.delete_node_button = customtkinter.CTkButton(self.buttons_frame, text = "Διαγραφή Κόμβου", command=self.delete_node)
        self.delete_node_button.grid(columnspan=2 , pady = 8, sticky="ew", padx = 30)
        # Κουμπί προβολής Απογόνων
        self.view_descendants_button = customtkinter.CTkButton(self.buttons_frame, text="Προβολή Απογόνων", command=self.view_descendants)
        self.view_descendants_button.grid(columnspan=2, pady=8, sticky="ew", padx=30)
        # Κουμπί καθαρισμού όλου του καμβά
        self.clear_all_button = customtkinter.CTkButton(self.buttons_frame, text = "Καθαρισμός Όλων", command=self.clear_all)
        self.clear_all_button.grid(columnspan = 2, sticky="ew", padx = 30)
        # Τέλος βάζουμε άλλη μια κενή ετικέττα για λόγους συμμετρίας όπως προαναφέραμε
        empty = customtkinter.CTkLabel(self.buttons_frame, text = "")
        empty.grid(columnspan=2, sticky="ew", padx = 30)
        # Προσθήκη πεδίων εισαγωγής πληροφοριών επιλεγμένου ατόμου
        # Εδω θα χρησιμοποιήσουμε το CTkLabel για ετικέττα περιγραφής αριστερα (column 0) και το CTkEntry πεδίο κειμένου δεξιά (column 1)
        # Το anchor = W στις ετικέττες στοιχίζει το κείμενο αριστερά (West)
        # Αρχικά βάζουμε μια κενή ετικέττα για λόγους συμμετρίας και ομορφιάς
        empty = customtkinter.CTkLabel(self.information_frame, text = "")
        empty.grid(columnspan=2, sticky="ew", padx = 30)
        # Ετικέττα και πλαίσιο κειμένου αναγνωριστικού (ID)
        self.id_label = customtkinter.CTkLabel(self.information_frame, text = "Αναγνωριστικό", anchor = W) # Δημιουργία ετικέτας
        self.id_label.grid(sticky="ew", pady = 5, padx = 30, row = 1, column = 0) # πλασάρισμα με grid
        self.id_entry = customtkinter.CTkEntry(self.information_frame) # δημιουργία πλαισίου κειμένου
        self.id_entry.grid(sticky="ew", pady = 5, padx = 30, row = 1, column = 1) # πλασάρισμα με grid
        # Ετικέττα και πλαίσιο κειμένου ονόματος
        self.name_label = customtkinter.CTkLabel(self.information_frame, text = "Όνομα", anchor = W)# Δημιουργία ετικέτας
        self.name_label.grid(sticky="ew", pady = 5, padx = 30, row = 2, column = 0) # πλασάρισμα με grid       
        self.name_entry = customtkinter.CTkEntry(self.information_frame) # δημιουργία πλαισίου κειμένου
        self.name_entry.grid(sticky="ew", padx = 30, row = 2, column = 1) # πλασάρισμα με grid
        # Ετικέττα και πλαίσιο κειμένου επιθέτου
        self.surname_label = customtkinter.CTkLabel(self.information_frame, text = "Επίθετο", anchor = W)# Δημιουργία ετικέτας
        self.surname_label.grid(sticky="ew", pady = 5, padx = 30, row = 3, column = 0) # πλασάρισμα με grid       
        self.surname_entry = customtkinter.CTkEntry(self.information_frame) # δημιουργία πλαισίου κειμένου
        self.surname_entry.grid(sticky="ew", padx = 30, row = 3, column = 1) # πλασάρισμα με grid
        
        # Ετικέττα και μενού επιλογών για το γένος
        self.gender_label = customtkinter.CTkLabel(self.information_frame, text = "Γένος", anchor = W) # Δημιουργία ετικέτας
        self.gender_label.grid(sticky="ew", pady = 5, padx = 30, row = 4, column = 0) # πλασάρισμα με grid
        # για το γένος θα χρησιμοποιήσουμε μενού επιλογών αντι για πλαίσιο κειμένου το οποίο θα περιλαμνάνει τις 3 δυνατες επιλογες ανδρας γυναίκα και άλλο
        # https://www.geeksforgeeks.org/how-to-create-option-menu-in-tkinter/
        # Αρχικά δημιουργούμε μια μεταβλητή self.option_variable τύπου customtkinter.StringVar, που χρησιμοποιείται για να αποθηκεύσει και να ελέγξει την τιμή που επιλέγεται από το χρήστη στο OptionMenu
        self.option_variable = customtkinter.StringVar(self)
        # Δηλώνουμε την προεπιλεγμένη τιμή του self.option_variable ως "Άρρεν" με τη μέθοδο set
        self.option_variable.set("Άρρεν")
        # Θέτουμε τις επιλογές της λίστας
        option_list = ["Επιλογή", "Άρρεν", "Θήλυ", "Άλλο"]
        # δημιουργία μενού επιλογών σύμφωνα με τα παραπάνω
        self.gender_entry = customtkinter.CTkOptionMenu(self.information_frame, variable = self.option_variable, values = option_list)
        self.gender_entry.grid(sticky="ew", pady = 5, padx = 30, row = 4, column = 1)# πλασάρισμα με grid
        # Ετικέττα και πλαίσιο κειμένου ημερομηνίας γέννησης
        self.birth_label = customtkinter.CTkLabel(self.information_frame, text = "Ημ/νία Γέννησης", anchor = W)# Δημιουργία ετικέτας
        self.birth_label.grid(sticky="ew", pady = 5, padx = 30, row = 5, column = 0)# πλασάρισμα με grid
        self.birth_entry = customtkinter.CTkEntry(self.information_frame) # δημιουργία πλαισίου κειμένου
        self.birth_entry.grid(sticky="ew", padx = 30, row = 5, column = 1) # πλασάρισμα με grid
        # Ετικέττα και πλαίσιο κειμένου ημερομηνίας θανάτου
        self.death_label = customtkinter.CTkLabel(self.information_frame, text = "Ημ/νια Θανάτου", anchor = W)# Δημιουργία ετικέτας
        self.death_label.grid(sticky="ew", pady = 5, padx = 30, row = 6, column = 0) # πλασάρισμα με grid
        self.death_entry = customtkinter.CTkEntry(self.information_frame) # δημιουργία πλαισίου κειμένου
        self.death_entry.grid(sticky="ew", padx = 30, row = 6, column = 1) # πλασάρισμα με grid
        # δημιουργία κουμπιού για την ενημέρωση των πληροφοριών του επιλεγμένου ατόμου
        self.save_info_button = customtkinter.CTkButton(self.information_frame, text = "Ενημέρωση Πληροφοριών", command = self.update_information)
        self.save_info_button.grid(sticky="ew", padx = 30, pady= 10, columnspan = 2)
        # Τέλος βάζουμε άλλη μια κενή ετικέττα για λόγους συμμετρίας όπως προαναφέραμε
        empty = customtkinter.CTkLabel(self.information_frame, text = "")
        empty.grid(columnspan=2, sticky="ew", padx = 30)
        # Δημιουργία καμβά σχεδιασμού δέντρου
        # Δημιουργία συνάρτησης για το zoom με τη ροδέλα του ποντικιού
        # https://stackoverflow.com/questions/25787523/move-and-zoom-a-tkinter-canvas-with-mouse
        def do_zoom(event):
            x = self.canvas.canvasx(event.x) # αντιστοίχιση συντεταγμένησ Χ του ποντικιού (event.x) με την συντεταγμενη Χ του καμβά
            y = self.canvas.canvasy(event.y) # αντίστοιχα και για την Υ
            # Η event.delta περιέχει την τιμή της μεταβολής (διαφορά) της ροδέλας του ποντικιού (mouse wheel).
            factor = 1.001 ** event.delta # παράγοντας αύξησης ή σμίκρυνσης (ζοομ) 
            #  χρησιμοποιείται τη μέθοδο scale για να εφαρμόσουμε το ζουμ (scaling) σε όλα τα στοιχεία του καμβά βάσει του παράγοντα μεταβολής που υπολογίστηκε προηγουμένως.
            self.canvas.scale(ALL, x, y, factor, factor)
        self.canvas = Canvas(self.canvas_frame, bg = "#eeeeee") # δημιουργία καμβά στο canvas_frame με φόντο γκριζάκι   
        self.canvas.bind("<MouseWheel>", do_zoom) #σύνδεση του συμβάντος <MouseWheel> με την συνάρτηση do_zoom.Κάθε φορά που μετακινείται η ροδέλα του ποντικιού καλείται η do_zoom 
        # Παρακάτω συνδέουμε το συμβάν <ButtonPress-1> με μια ανώνυμη (lambda) συνάρτηση που καλεί τη μέθοδο self.canvas.scan_mark(event.x, event.y)
        # για την παρακολούθηση της θέσης του ποντικιού πάνω στον καμβά
        # https://realpython.com/python-lambda/
        # https://anzeljg.github.io/rin2/book2/2405/docs/tkinter/canvas-methods.html
        self.canvas.bind('<ButtonPress-1>', lambda event: self.canvas.scan_mark(event.x, event.y))
        # εφόσον έχουμε τη θέση του ποντικιού πάνω στον καμβά μπορούμε ευκολα να κάνουμε scroll τον καμβά
        # https://stackoverflow.com/questions/74682813/tkinter-canvas-scrolling-scrollregion-explained-un-restricted-area
        self.canvas.bind("<B1-Motion>", lambda event: self.canvas.scan_dragto(event.x, event.y, gain=1))
        self.canvas.pack(fill=BOTH, expand=True) # τοποθέτηση με pack
        # Θέτουμε την βαρύτητα στα πλαίσια για να καθορίσουμε το πως επεκτείνονται κατά την αλλαγή μεγέθους του παραθύρου
        # https://www.plus2net.com/python/tkinter-rowconfigure.php
        # κυρίως πλαίσιο
        self.main_frame.grid_columnconfigure(1,weight=4) # Στήλη βαρύτητα της στήλης 1 στο 4, που σημαίνει ότι θα παίρνει περισσότερο χώρο σε σχέση με άλλες στήλες όταν αλλάζει το μέγεθος του παραθύρου. 
        self.main_frame.grid_rowconfigure(0,weight=1) # γραμμή 0 βαύτητα στο 1, που σημαίνει ότι θα τεντώνει μαζί με το παράθυρο.
        # πλαίσιο πληροφοριών
        self.information_frame.grid_columnconfigure(0, weight=1) # Στήλη 1 μεγαλύτερο βάρος απο την 2
        self.information_frame.grid_columnconfigure(1, weight=4)
        # πλαίσιο κουμπιών
        self.buttons_frame.grid_columnconfigure(0, weight=1) # ίδιο βάρος και οι 2 στήλες (τεντώνονται ισομερώς)
        self.buttons_frame.grid_columnconfigure(1, weight=1)
# Δημιουργία κυρίως παραθύρου και ξεκίνημα βρόχου γεγονότων
def main(): # ορίζουμε την συνάρτηση Main
    global root # ορισμός της root (παράθυρο της customtkinter) ως global για προσπέλαση απο παντού στον κώδικα
    root = customtkinter.CTk() # δημιουργία του κυρίως παραθύρου
    ex = Window() # δημιουργεί ένα αντικείμενοu Window  
    root.geometry("1100x650+150+30") # Ορίσμός αρχικού μεγεθους και της θέσης του παραθύρου στην οθόνη.
    root.mainloop() # ξεκίνημα του βρόχου γεγονότων της εφαρμογής
if __name__ == '__main__': # https://www.tutorialspoint.com/What-does-the-if-name-main-do-in-Python#:~:text=A%20Python%20programme%20uses%20the,is%20imported%20as%20a%20module.
    main() # εκτέλεση της main()
