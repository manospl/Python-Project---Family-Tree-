import sqlite3 as sql
# import db_set_name
from FamilyTree import Person
#database_name = "people.db"
database_name = None
#db_set_name.get_database_name()
#print (database_name)


"""
# Connect to the database (or create a new one)
with sql.connect(database_name) as conn:
    pass
"""

# 1. apothikeysh 
# 2. fortwsh
# 3. diagrafh
## 4. epeksergasia

# apothikeyw ola ta dedomena ths everyone sth vash
def save(everyone_list,database_name):
    # create_table()
    # prwta diagrafh olwn twn periexomenwn toy pinaka
    delete()
    
    # apothikeyw thn lista ston pinaka
    with sql.connect(database_name) as conn:
        
        cursor = conn.cursor()

        for person in everyone_list:
            children_str = ""
            for child in person.children:
                children_str += child.id + "-"

            # SQL command to insert data into the "users" table
            insert_query = """
            INSERT INTO person (id, 
            name, 
            surname, 
            gender,
            birth,
            live,
            death, 
            level, 
            position_x, 
            position_y,
            spouse, 
            children,
            comments)
            VALUES (?, ?, ?, ?, ?, ?, 
            ?, ?, ?, ?, ?, ?, ?);
            """

            # Execute the SQL command with the data
            cursor.execute(insert_query, (person.id, person.name, 
                                          person.surname, 
                                          person.gender, 
                                          person.birth, 
                                          person.live,
                                          person.death, 
                                          person.level, 
                                          person.position_x, 
                                          person.position_y, 
                                          person.spouse.id if person.spouse else None, 
                                          children_str if children_str != "" else None,
                                          person.comments))

        # Commit the changes
        conn.commit()
         

# fortwsh olwn twn dedomenwn. epistrefei mia lista kai dyo leksika
def load():
    #create_table()

    everyone_list = []
    everyone = {}
    level_dict = {}

    with sql.connect(database_name) as conn:
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM person;")
        
        rows = cursor.fetchall()
        #print('grammes', rows)
        
        for row in rows:
            # φτιαχνω καινουριο ανθρωπο
            #print(row)
            spouse_ = None

            try:
                spouse_ = everyone[row[9]]
                # to row[9] einai o syzhgos moy. thelw kai o syzhgos moy na kserei oti taxoyme
                
            except:
                #print('den yparxei akoma!')
                pass

            new_person = create_person(id=row[0], 
                                       name=row[1], 
                                       surname = row[2], 
                                       gender = row[3], 
                                       birth = row[4], 
                                       live = row[5], 
                                       level=row[6], 
                                       position_x = row[7], 
                                       position_y = row[8], 
                                       spouse = spouse_, # einai to id, thelw to antikeimeno!
                                       children = row[10],
                                       death = row [11],
                                       comments = row[12]
                                       ) # bazw gia ola.
            
            
            if spouse_:
                everyone[spouse_.id].spouse = new_person

            everyone_list.append(new_person)
            everyone[new_person.id] = new_person
            
            try:
                level_dict[new_person.level].append(new_person)
            except:
                level_dict[new_person.level] = [new_person]
                
    # edw exw oti oi goneis exoyn sto .children toys ena string me ta paidia toys, enw ta paidia (gia kapoio logo)
    # exoyn mia kenh lista

    # exw thn lista me oloys toys anthrwpoys
    # exw to dictionary me kleidia ta id kai times toys anthrwpoys

    # thelw na kanw to .children twn goniwn apo ena string me ta id twn paidiwn na ginei mia lista poy mesa exei
    # ta paidia ws antikeimena

    for person in everyone_list:
        if person.children == []:
            continue

        children_str = person.children

        person.children = []
        for child_id in children_str.split('-'):
            if child_id == '':
                continue
            person.children.append(everyone[child_id])
        
    

    return everyone_list, everyone, level_dict


# diagrafh olwn twn dedomenwn sth vash
def delete():
    # anoigw syndesh
    with sql.connect(database_name) as conn:

        cursor = conn.cursor()
        cursor.execute("DELETE FROM person")

        conn.commit()
    # ftiaxnw kersora
    # ektelw thn entolh 

def create_person(id = None, name = None, surname = None, gender = None, birth = None, live = None, level = None, position_x = None, position_y = None, spouse = None, children = None, death = None, comments = None):
    new_person = Person()

    if name:
        new_person.name = name
    
    if id:
        new_person.id = id

    if surname:
        new_person.surname=surname
    
    if gender:
        new_person.gender = gender

    if level:
        new_person.level = level

    if birth:
        new_person.birth = birth

    if live:
        new_person.live = live

    if position_x:
        new_person.position_x = position_x
    
    if position_y:
        new_person.position_y = position_y
    
    if spouse:
        new_person.spouse = spouse
    
    if children:
        new_person.children = children
    
    if death:
        new_person.death = death
    
    if comments:
        new_person.comments = comments

    return new_person  

def create_table():
    # Connect to the database (or create a new one)
    with sql.connect(database_name) as conn:
        
        # Create a cursor object
        cursor = conn.cursor()

        # SQL command to create the "users" table
        create_table_query = """
        CREATE TABLE IF NOT EXISTS person (
            id TEXT PRIMARY KEY,
            name TEXT,
            surname TEXT,
            gender TEXT,
            birth TEXT,
            live TEXT,
            level INTEGER NOT NULL,
            position_x INTEGER NOT NULL,
            position_y INTEGER NOT NULL,
            spouse TEXT,
            children TEXT,
            death TEXT,
            comments TEXT
        );
        """

        # Execute the SQL command
        cursor.execute(create_table_query)

        # Commit the changes
        conn.commit()

