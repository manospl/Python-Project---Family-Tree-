import os
import tkinter.messagebox
import sqlite3 as sql
database_name = None


def set_database_name(name):
    global database_name
    database_name = name


def create_table():
    # Connect to the database (or create a new one)
    with sql.connect(database_name) as conn:

        # Create a cursor object
        cursor = conn.cursor()

        # Kαταστρέφουμε τον πίνακα person αν υπάρχει
        # drop_table_query = "DROP TABLE IF EXISTS person;"
        # cursor.execute(drop_table_query)
        
        # SQL command to create the "users" table
        create_table_query = """
        CREATE TABLE IF NOT EXISTS person (
            id TEXT PRIMARY KEY,
            name TEXT,
            surname TEXT,
            gender TEXT,
            birth TEXT,
            live TEXT,
            level INTEGER NOT NULL,
            position_x INTEGER NOT NULL,
            position_y INTEGER NOT NULL,
            spouse TEXT,
            children TEXT,
            death TEXT,
            comments TEXT
        );
        """

        # Execute the SQL command
        cursor.execute(create_table_query)

        # Commit the changes
        conn.commit()


def get_database_name():
    return database_name
