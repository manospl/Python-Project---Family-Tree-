# ΠΛΗΠΡΟ 2022-2023 Project Ομάδα 2

## Μέλη ομάδας

* ΛΑΓΙΟΥ ΕΙΡΗΝΗ 
* ΔΕΜΙΣΑΡΛΗΣ ΘΩΜΑΣ 
* ΠΛΑΡΙΝΟΣ ΕΡΜΑΝΟΣ
* ΔΗΜΗΤΡΟΥΛΑΣ ΘΕΟΔΩΡΟΣ 
* ΓΙΑΤΡΟΠΟΥΛΟΣ ΘΕΟΔΩΡΟΣ


## environment

Δημιουργία python environment και εγκατάσταση modules (γίνεται 1 φορά)

```
> python -m virtualenv venv
> venv/Scripts/activate.bat
> pip install -r requirements.txt
> venv/Scripts/deactivate.bat
```

Ενεργοποίηση, απενεργοποίηση python environment

```
> venv/Scripts/activate.bat
> python FamilyTree.py
> venv/Scripts/deactivate.bat
```

