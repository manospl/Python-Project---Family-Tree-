from tkinter import *
from tkinter import ttk
from tkinter import simpledialog
import tkinter as tk
import customtkinter as ctk
from datetime import datetime
import shortuuid # https://pypi.org/project/shortuuid/
from tkinter import messagebox
from tkinter import filedialog as fd
import json
import customtkinter
import pygraphviz as pgv
import xml.etree.ElementTree as ET
import os
from PIL import Image, ImageGrab
import math
import sqlite3
import sys
import subprocess
from collections import deque # https://www.geeksforgeeks.org/deque-in-python/
import db
import db_set_name
customtkinter.set_appearance_mode("dark")  # Μορφή: system (default), light, dark
customtkinter.set_default_color_theme("green")  # Θέματα: blue (default), dark-blue, green
# Χρωματισμοί γένους
MALE_COLOR_VALUE = "#0073cf" #μπλε άνδρας
DEAD_MALE_COLOR_VALUE = "#66a3e0" # πεθαμένο χρώμα
FEMALE_COLOR_VALUE = "#f88379" #ανοιχτό κόκκινο γυναίκα
DEAD_FEMALE_COLOR_VALUE = "#fcab9e"
OTHER_COLOR_VALUE = "#00755E" #πράσινο άλλο
DEAD_OTHER_COLOR_VALUE = "#66cdaa"

database_name = sys.argv[2]
db.database_name = sys.argv[2]
print(database_name)
def process_file(file_path):
    # Access and use the filePath variable as needed
    print("Received file path:", file_path)
    # Perform additional operations with the file p
#Συνάρτηση για να πάρουμε το πρώτο κόμβο 
def show_records(table):
    sql = "SELECT * FROM {} where level=0;"
    try:
        with sqlite3.connect(database_name) as conn:
            cursor = conn.cursor()
            cursor.execute(sql.format(table))
            results = cursor.fetchall()
            return results
    except sqlite3.Error as err:
        print("Error: ", err)  # Προβολή μηνύματος σφάλματος
        return False
# Αναδρομική Συνάρτηση για την επαναλαμβανόμενη διαγραφή απογόνων ενός κόμβου στην περίπτωση ειπλογής διαγραφής του
# Χρησιμοποιείται οταν ο κόμβος αποτελεί τον μοναδικό σύνδεσμο μεταξύ προγόνων και απογόνων
# σε αυτή τη περίπτωση διαγράφουμε τους απογόνους του για να μη μείνουν ξεκρέμαστοι
def recursively_delete_children(node, node_list):
    for child in node.children: # για κάθε παιδί στη λίστα παιδιών του επιλεγμένου ατόμου
        if child.spouse != None: # αν υπάρχει και σύζυγος του παιδιού
            node_list.remove(child.spouse) # διαγραφή και του συζύγου μη μείνει ξεκρέμαστος
        node_list.remove(child) # διαγραφή παιδιού
        recursively_delete_children(child, node_list) # επανάκλησ του εαυτό της για τα παιδιά των παιδιών κτλ
def save_as_png(canvas,fileName): # Αποθήκευση σε PNG (δεν εχει υλοποιηθει ακόμα)
    # https://stackoverflow.com/questions/9886274/how-can-i-convert-canvas-content-to-an-image
    # postscipt image 
    canvas.postscript(file = fileName + '.eps') 
    # PIL to convert to PNG 
    img = Image.open(fileName + '.eps') 
    img.save(fileName + '.png', 'png')
# Κλάση που περιέχει τις ιδιότητες και λεπτομέρειες κάθε ατόμου 
class Person():
    def __init__(self) -> None:
        self.id = str(shortuuid.uuid())[0:12] #το id του κάθε ατόμου (12 πρώτοι χαρακτήρες)
        self.name = "" # Όνομα
        self.surname = ""
        self.gender = "Άρρεν" # Γένος
        self.birth = "" # Γέννηση
        self.death = "" # Θάνατος
        self.children = [] # Αρχικοποίηση λίστας παιδιών του ατόμου
        self.spouse = None # σύζυγος
        self.father = None
        self.mother = None
        self.comments = ""
        self.live = "NAI"
        self.level = 0 # η Γενιά
        self.position_x = 0 # Αρχικοποίησ συντεταγμένων Χ
        self.position_y = 0 # και Υ
        self.shape = None # Αρχικοποίηση σχήματος
        # Μεγέθη κόμβων και αποστάσεις μεταξύ τους
        self.width = 120
        self.height = 60
        self.spacing_x = 120
        self.spacing_y = 120
        self.grid_x = None
        self.grid_y = None
# Main window class
class Window(Frame): # Υποκλάση της γονικής Frame
    def __init__(self):
        super().__init__() # Κλήση της γονικής κλάσης frame apo customtkinter
        self.start_x = 310 # Αρχικές συντεταγμένες σχεδιασμού του δέντρου Χ
        self.start_y = 150 # και Υ
        self.shape_index = 0 # Δείκτης για το επιλεγμένο Κόμβο του δέντρου
        self.current_shape = None # Μεταβλητές αποθήκευσης του επιλεγμένου κόμβοτ
        self.previous_shape = None # καθώς και του προηγούμενου
        self.current_person = None # επιλεγμένος κόμβος για ανάκτηση μετά απο refresh
        self.everyone = {} # αρχικοποίση λεξικού αποθήκευσης αντικειμένου τύπου person (key:id,value:person object)
        self.person_list = [] # λίστα αποθήκευσης αντικειμένων τύπου Person έτσι όπως δημιουργήθηκαν
        self.level_dict = {} # αρχικοποίηση λεξικού αποθήκευσης ατόμων σε λίστα ανάλογα με τη γενιά τους (key:γενιά,value:λιστα ατόμων γενιάς)
        self.initUI() # αρχικοποίηση γραφικού περιβάλλοντος GUI     
        if (sys.argv[1]=="False"):
            self.add_new_node()
        if(sys.argv[1]!="False" and sys.argv[1]!="error-chosen file"):
            self.import_db_data() 
    # Δημιουργία συνάρτησης προσθήκης πλαισίου διαλόγου για την εισαγωωή ονόματος του υπο προσθήκη ατόμου
    def name_enter(self, relation):
        # πλαίσιο διαλόγου απο tkinter https://docs.python.org/3/library/dialog.html
        name = simpledialog.askstring("Εισαγωγή Ονόματος", f"Παρακαλώ εισάγετε το όνομα {relation}:") 
        if ' ' in name:
            # Διαχωρισμός του ονόματος σε όνομα και επίθετο
            first_name, last_name = name.split(' ')
            # Επιστροφή ονόματος και επιθέτου ξεχωριστά
            return first_name, last_name
        else:
            # Αν έχουμε μόνο Όνομα και OXI επίθετο επιστροφή None αντί για επίθετο
            return name, None
    # Δημιουργία μενού όταν ο χρήστης κάνει δεξί κλικ σε εναν κόμβο
    # οι επιλογές είναι οι ίδιες με αυτές των κουμπιών ελέγχου (χωρίς τη προσθήκη κόμβου που δεν έχει νόημα)     
    def show_context_menu(self, event):
        # Δημιουργία νέου μενού (tearoff=0 σταθερό μενού)
        menu = Menu(self.canvas, tearoff=0)
        # Προσθήκη επιλογών στο μενού
        menu.add_command(label="Εμφάνιση πληροφοριών ατόμου", command=self.show_person_info)
        menu.add_separator() # διαχωριστικό
        # Προσθήκη επιλογών των κουμπιών
        menu.add_command(label="Προσθήκη Παιδιού", command=self.add_child)
        menu.add_command(label="Προσθήκη Συζύγου", command=self.add_spouse)
        menu.add_command(label="Προσθήκη Γονέων", command=self.add_parents)
        menu.add_command(label="Προσθήκη Αδελφού", command=self.add_sibling)
        menu.add_command(label="Διαγραφή Κόμβου", command=self.delete_node)
        menu.add_command(label="Προβολή Απογόνων", command=self.view_descendants)
        menu.add_separator() # διαχωριστικό
        menu.add_command(label="Διαγραφή Όλων", command=self.clear_all)
        # Αμυντικός προγραμματισμός απενεργοποίησης επιλογών
        if self.current_person.spouse: menu.entryconfig(3, state="disabled")
        if self.current_person.father or self.current_person.mother: menu.entryconfig(4, state="disabled")
        if not self.current_person.father and not self.current_person.mother: menu.entryconfig(5, state="disabled")
        # Εμφάνιση του μενού στη θέση του ποντικιού
        menu.post(event.x_root, event.y_root)
    # Συνάρτηση για την εμφάνιση απογόνων
    def view_descendants(self):
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                break
        # Δημιουργία νέου Toplevel παραθύρου ( ο καμβάς τώρα είναι στατικός χωρίς dag and drop)
        descendants_window = tk.Toplevel(self.master) # Πάνω απο τον καμβά
        descendants_window.geometry("1600x1200") # διαστάσεις
        # τίτλος παραθύρου με πρόβλεψη για αρσενικό θηλυκό (χμμμ για άλλο?αφήνουμε αρσενικό προς το παρόν)
        descendants_window.title("Δέντρο απεικόνισης απογόνων της " + selected_individual.name + " " + selected_individual.surname if selected_individual.gender == "female" else "Δέντρο απεικόνισης απογόνων του " + selected_individual.name + " " + selected_individual.surname)
        # Φτιάχνουμε τον καμβά (Ίσως είναι καλύτερα να παραλείψουμε το ύψος και πλάτος)
        descendants_canvas = tk.Canvas(descendants_window, width=1600, height=1200)
        descendants_canvas.pack() # τοποθέτησή του με .pack
        descendants_canvas.delete("all") # καθαρισμός του καμβά
        # Κλήση συνάρητησης ορισμού συντεταγμένων απο pygrahviz
        positions = self.generate_descendants_positions(selected_individual)
        # Στοιχιση του δέντρου στο κέντρο του καμβά
        # Πρώτα υπολογισμός ύψους και πλάτους του δέντρου 
        all_x = [pos[0] for pos in positions.values()]
        all_y = [pos[1] for pos in positions.values()]
        min_x, max_x = min(all_x), max(all_x)
        min_y, max_y = min(all_y), max(all_y)
         # και αποθήκευση στις μεταβλητές
        graph_width = max_x - min_x
        graph_height = max_y - min_y
        # υπολογισμός περιθωρίων σχεδιασμού σε σχέση με τις διαστάσεις του παραθύρου
        offset_x = (1600 - graph_width) / 2
        offset_y = (1200 - graph_height) / 2
        # aδιόρθωση των συντεταγμένων σύμφωνα με τα παραπάνω περιθώρια
        positions = {node: [pos[0] + offset_x, pos[1] + offset_y] for node, pos in positions.items()}
        # Εδώ θα καλέσουμε την αναδρομική συνάρτηση αναζήτησης και απεικόνισης των απογόνων του ατόμου
        #descendants_canvas.config(scrollregion=(min_x + offset_x, min_y + offset_y, max_x + offset_x, max_y + offset_y))
        self.draw_children_recursive(selected_individual, descendants_canvas, positions)
    # Συνάρτηση pygraphviz ορισμού συντεταγμένων
    def generate_descendants_positions(self, selected_individual):
        G = pgv.AGraph(directed=True) # αρχικοποίηση γραφήματος
        # μέθοδος προσθήκης του ατόμου και όλων των απογόνων στο γράφημα
        def add_to_graph(individual):
            G.add_node(individual.id)
            for child in individual.children:
                G.add_node(child.id)
                G.add_edge(individual.id, child.id)
                add_to_graph(child)  # αναδρομική κλήση προσθήκης απογόνων
        # προσθήκη του επιλεγμένου ατόμου στο γράφημα 
        # για να ξεκινήση η αναδρομική διαδικασία προσθήκης απογόνων
        add_to_graph(selected_individual)
        # ορισμός μεσοδιαστήματος σχεδιασμού
        G.graph_attr['ranksep'] = '2.0' 
        G.graph_attr['nodesep'] = '2.2' 
        # dot αλγόριθμος ιεραρχικού δέντρου
        G.layout(prog='dot')
        # δημιουργία λεξικού αποθήκευσης συντεταγμένων
        pos = {node: [float(coord) for coord in G.get_node(node).attr['pos'].split(',')] for node in G.nodes()}
        positions = self.positions_to_grid_positions(pos) 
        return positions
    # Η αναδρομική συνάρτηση σχδιασμού που είπαμε παραπάνω     
    def draw_children_recursive(self, person, canvas, positions):
        # παίρνουμε έτοιμες τις διαστάσεις και συντεταγμένες του ατόμου απο την generate_descendants_positions
        x, y = positions[person.id]
        y = 1200 - y
        width = person.width # πλάτος ήδη υπάρχων
        height = person.height # ύψος επίσης
        color = OTHER_COLOR_VALUE # Αρχικοποίηση χρώματος
        # Ορισμός χρωμάτων ανάλογα με το γένος
        if person.gender == "Άρρεν": 
            color = MALE_COLOR_VALUE
        if person.gender == "Θήλυ":
            color = FEMALE_COLOR_VALUE
        # Κατασκευή ορθογωνίου σύμφωνα με τα παραπάνω στον νέο καμβά
        # Ίδια με την μέθοδο κατασκευής ορθογωνίου απο την συνάρτηση draw_family_tree
        canvas.create_rectangle(x, y, x + width, y + height,
            outline="#333333", fill=color, width=0, tags="single_shape")
        canvas.create_text(x + (width//2), y + (height//2), fill="white", font="Roboto 10", anchor="center", justify="center",
            text=person.name + "\n" + person.surname)
        # Εδώ θα αλλάξουμε λίγο τρόπο σχεδιασμού ακμών και θα δανειστούμε τον τρόπο σχεδιασμού τους απο την ανενεργή draw_parental_relations
        # Οι ακμές οδηγούνται απευθείας απο τους γονείς στα παιδιά
        # Υπολογισμός πρώτου σημείου γραμμής (μέσον και κάτω στον κόμβο γονέα) 
        if not person.children: 
            return 
        for child in person.children:
            self.draw_children_recursive(child, canvas, positions) #κλήση αναδρομικά
            # σχεδιασμός ακμών απο τον γονέα προς το παιδί απευθείας     
            x1 = x + (width//2) 
            y1 = y + height 
            x2, y2 = positions[child.id]
            x2 += child.width//2
            y2 = 1200 - y2
            canvas.create_line(x1, y1 , x2, y2, width = 2)
    # event handler (χειρισμός συμβάντων κατά την επιλογή με κλίκ)
    def single_shape_clicked(self, event): 
        
        x, y = event.x, event.y # καθορισμός συντεταγμένων που προκλήθηκαν απο το κλικ
        print(x, y)
        #shape = self.canvas.find_closest(x,y)
        # εντοπισμός του αντικείμενου του καμβά που βρίσκεται κάτω απο το δείκτη του ποντικιού και αποθήκευση στο index
        # https://www.pythontutorial.net/tkinter/tkinter-canvas/
        # https://stackoverflow.com/questions/70423920/how-do-i-detect-tags-of-clicked-objects-in-tkinter-canvas
        index = (event.widget.find_withtag("current")[0]) 
        #c.delete(shape)
        self.previous_shape = self.current_shape # Αποθήκευση του προηγούμενου επιλεγμένου κόμβου
        self.current_shape = index # Ορισμός του τρέχοντος κόμβου στο index που βρήκαμε παραπάνω
        for individual in self.person_list: 
            if individual.shape == self.current_shape: 
                self.current_person = individual  # Αποθηκεύουμε το επιλεγμένο άτομο για ανάκτηση
                self.current_person_label.configure(text=f"{self.current_person.name} {self.current_person.surname}")
                self.reorganize_buttons(self.current_person)
                break
        if self.previous_shape != None: # Αν υπάρχει προηγούμενος επιλεγμένος κόμβος 
            self.canvas.itemconfig(self.previous_shape, width = 0) # σβήνουμε το περίγραμμα απο το προηγούμενο (πάχος 0)
        self.canvas.itemconfig(self.current_shape, width = 3) # και το ορίζουμε το περιγραμμα στο τρέχων μας βοηθάει οπτικα ποιός κόμβος ειναι επιλεγμένος
        #το πάχος του περιγράμματος είναι παραμετροποιήσιμο ανάλογα με τα γούστα μας
        self.clear_information() # καθαρισμός πληροφοριών προηγούμενου ατόμου
        self.display_information() # εμφάνιση πληροφοριών επιλεγμένου ατόμου
        ### Βοηθητικές συναρτήσεις μετακίνησης κόμβων και απογόνων για την αποφυγή αλληλοκαλύψεων ### 
    # Προσθήκη κόμβου (αρχικού)
    def add_new_node(self):
        # name, surname = self.name_enter("του ατόμου") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        result = show_records('person')
        # print(result)
        name = result[0][1]
        surname = result[0][2]
        gender = result[0][3]
        birth = result[0][4]
        live = result[0][5]
        id = result[0][0]
        start_x = self.start_x # ορισμός των αρχικών συντεταγμένων
        start_y = self.start_y # Χ και Υ όπως τις ορίσαμε παραπάνω
        sql = "update person set position_x = ? , position_y = ? where id = ?"
        try:                 
            # Σύνδεση με τη Β.Δ. people
            with sqlite3.connect(database_name) as conn:
                cursor = conn.cursor()
                cursor.execute(sql, (start_x,start_y,id))
        except sqlite3.Error as err:
            print("Error: ", err)  # Προβολή μηνύματος σφάλματος
        person = Person() # δημιουργία αντικειμένου τύπου person
        #person.position_x = start_x # ορισμός της θέσης του αντικειμένου 
        #person.position_y = start_y # στα Χ και Υ
        person.birth = birth
        person.gender = gender
        person.id = id
        person.live = live
        person.level = 0 # η Γενιά του ατόμου
        if name!=None: person.name = name # ορισμός ονόματος του ατόμου στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
        if surname!=None: person.surname = surname # ορισμός και του επιθέτου στην περίπτωση που έχει καταχωρηθεί
        self.person_list.append(person) # προσθήκη του ατόμου στη λίστα των ατόμων

        self.current_person = person
        self.current_person_label.configure(text=f"{self.current_person.name} {self.current_person.surname}")
        self.clear_information()
        self.display_information() # εμφάνιση πληροφοριών επιλεγμένου ατόμου
        self.draw_family_tree() # σχεδιασμός δέντρου

    # Προσθήκη συζύγων
    def add_spouse(self):
        # αμυντικός στην περίπτωση που δεν εχει επιλεγέι κάποιος κόμβος
        if self.current_shape == None: 
            messagebox.showwarning(title="Δεν έχει επιλεγέι κόμβος", message="Παρακαλώ πρώτα επιλέξτε έναν κόμβο για την προσθήκη συζύγου")
            return
        spouse_name, spouse_surname = self.name_enter("συζύγου") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                break
        if selected_individual.spouse != None: # αν το επιλεγμένο ατομο έχει ήδη σύζυγο 
            return # μη κανεις τίποτα
        # εδω ίσως μπορούμε να εχουμε μια πρόβλεψη για πρώην συζύγους κτλ
        #ορισμός συντεταγμένων (το Υ παραμένει ίδιο ειναι ίδια γενιά,το Χ ορίζεται ανάλογα με την ύπαρξη αδερφικού κόμβου)
        spouse = Person() # δημιουργία αντικειμένου τύπου person
        if selected_individual.gender == "Άρρεν":
            spouse.gender = "Θήλυ"
        elif selected_individual.gender == "Θήλυ":
            spouse.gender = 'Άρρεν'
        if spouse_name!=None: spouse.name = spouse_name # ορισμός ονόματος συζύγου στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
        if spouse_surname!=None: spouse.surname = spouse_surname # και του επιθέτου αν έχει δηλωθεί
        selected_individual.spouse = spouse # ορίζουμε την συγγένεια του επιλεγμένου κόμβου σε σύζυγο
        spouse.spouse = selected_individual # και αντιστρόφως
        spouse.level = selected_individual.level # ίδια γενιά
        for child in selected_individual.children: # αν το επιλεγμένο άτομο έχει παιδιά
            spouse.children.append(child) # τα προσθέτουμε και στον/στην σύζυγο
        self.person_list.append(spouse) # προσθήκη του συζύγου στη λίστα των ατόμων
        #diagrafh basis - save vasis - self.import_db_data() 
        db.save(self.person_list, database_name)
        self.draw_family_tree() # (επανα)σχεδιασμός δέντρου
    #προσθήκη γονέων
    def add_parents(self):
        # αμυντικός στην περίπτωση που δεν εχει επιλεγέι κάποιος κόμβος
        if self.current_shape == None:
            messagebox.showwarning(title="Δεν έχει επιλεγέι κόμβος", message="Παρακαλώ επιλέξτε εναν κόμβο προτού προσθέσετε συγγένεια")
            return
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                break
        mother_name, mother_surname = self.name_enter("μητέρας") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        father_name, father_surname = self.name_enter("πατέρα") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        #προσθήκη μητέρας
        mother = Person() # δημιουργία αντικειμένου τύπου person
        mother.gender = "Θήλυ" # ορισμός γένους
        if mother_name!=None: mother.name = mother_name # ορισμός ονόματος της μητέρας στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
        if mother_surname!=None:
            mother.surname = mother_surname # Ορισμός και επιθέτου αν έχει δηλωθεί
        else:
            mother.surname = selected_individual.surname # Ορισμός του ίδιου επιθέτου στη μητέρα για λόγους ευκολίας
        # προσθήκη πατέρα
        father = Person() # δημιουργία αντικειμένου τύπου person
        father.gender = "Άρρεν" # ορισμός γένους
        if father_name!=None: father.name = father_name # ορισμός ονόματος του πατέρα στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
        if father_surname!=None:
            father.surname = father_surname # Ορισμός και επιθέτου αν έχει δηλωθεί
        else:
            father.surname = selected_individual.surname # Ορισμός του ίδιου επιθέτου στον Πατέρα για λόγους ευκολίας
        mother.spouse, father.spouse = father, mother # ορισμός συζύγων στους γονείς μεταξύ τους
        selected_individual.mother = mother
        selected_individual.father = father
        mother.children.append(selected_individual) # ορισμός επιλεγμένου κόμβου ως παιδί 
        father.children.append(selected_individual) # και στους 2 γονείς
        mother.level = selected_individual.level - 1 # προηγούμενη γενιά
        father.level = selected_individual.level - 1 # και στους 2 γονείς
        self.person_list.append(mother) # προσθήκη γονέων στη λίστα ατόμων
        self.person_list.append(father)    
        db.save(self.person_list, database_name)
        self.draw_family_tree() # (επανα)σχεδιασμός δέντρου
    #προσθήκη παιδιού
    def add_child(self):
        if self.current_shape == None:
            # αμυντικός στην περίπτωση που δεν εχει επιλεγέι κάποιος κόμβος
            messagebox.showwarning(title="Δεν έχει επιλεγέι κόμβος", message="Παρακαλώ επιλέξτε εναν κόμβο προτού προσθέσετε συγγένεια")
            return
        child_name, child_surname = self.name_enter("παιδιού") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                break
        person = Person() # δημιουργία αντικειμένου τύπου person
        if child_name!=None: person.name = child_name # ορισμός ονόματος του παιδιού στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση
        if child_surname!=None:
            person.surname = child_surname # Ορισμός και επιθέτου αν έχει δηλωθεί
        else:
            if selected_individual.gender == "Άρρεν":
                person.surname = selected_individual.surname # Κληρονόμηση επιθέτου σε περίπτωση πατέρα
            elif selected_individual.gender == "Θήλυ" and selected_individual.spouse is not None: # και κληρονόμηση σε περίπτωση μητέρας με σύζυγο
                person.surname = selected_individual.spouse.surname
            elif selected_individual.gender == "Θήλυ": # και κληρονόμηση σε περίπτωση μητέρας μονογονεικής οικογένειας
                person.surname = selected_individual.surname
        selected_individual.children.append(person) # Προσθήκη του παιδιού στη λίστα των παιδιών του επιλεγμένου κόμβου
        person.level = selected_individual.level + 1 # Αύξηση γενιάς κατά 1 για το παιδί
        if selected_individual.spouse != None: # Αν υπάρχει σύζυγος του επιλεγμένου κόμβου
            selected_individual.spouse.children.append(person) # τότε προσθήκη του παιδιού και στη λίστα παιδιών του συζύγου
        self.person_list.append(person) # προσθήκη του παιδιού και στη γενική λίστα ατόμων   
        # db.database_name = db_set_name.get_database_name()
        db.save(self.person_list, database_name)
        self.draw_family_tree()# (επανα)σχεδιασμός δέντρου
    # προσθήκη αδελφού/αδελφής
    # Ακολουθείται η ίδια λογική με την add_child απλά κρατάμε τα αδέρφια στο ίδιο επίπεδο(γενιά)
    def add_sibling(self):
        # αμυντικός στην περίπτωση που δεν εχει επιλεγέι κάποιος κόμβος
        if self.current_shape == None:
            messagebox.showwarning(title="Δεν έχει επιλεγέι κόμβος", message="Παρακαλώ επιλέξτε εναν κόμβο προτού προσθέσετε συγγένεια")
            return
        sibling_name, sibling_surname = self.name_enter("αδελφού/ής") # κλήση του πλαισίου διαλόγου για την εισαγωγή ονόματος
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                surname=selected_individual.surname # μεταβλητή για την κληρονόμηση επιθέτου
                break
        selected_parent = None # αρχικοποίηση γονέα επιλεγμένου ατόμου
        for individual in self.person_list: # iteration για να βρουμε γονέα  
            #print(selected_individual, individual.children)
            if selected_individual in individual.children: # αν το επιλεγμένο άτομο ανήκει στη λίστα παιδιών
                selected_parent = individual # τότε έχουμε γονέα και τον καταχωρούμε
                # σημειωτέον οτι μας ενδιαφέρει μόνο ο ένας γονέας.Ο έλεγχος αν υπάρχει και άλλος γονέας γίνεται παρακάτω
                break
        #αμύντικός στη περίπτωση απουσίας γονέων
        if selected_parent == None: # αν δεν υπάρχει γονέας μήνυμα σφάλματος και επιστροφή
            messagebox.showwarning(title="Το Επιλεγμένο Άτομο δεν έχει γονέα/εις", message="Παρακαλώ προσθέστε γονείς πρίν την προσθήκη αδελφού/ης")
            return 
        # βασικά είναι σαν να κάνουμε add_child για τον γονέα αυτή τη φορά
        #ίδια λογική με add child για τον γονέα
        person = Person() # δημιουργία αντικειμένου τύπου person
        if sibling_surname!=None:
            person.surname = sibling_surname
        else:
            person.surname = surname # ορισμός ίδιου επιθέτου για ευκολία
        if sibling_name!=None: person.name = sibling_name # ορισμός ονόματος αδελφού στην περίπτωση που ο χρήστης δεν πατήσει ακύρωση 
        selected_parent.children.append(person) # Προσθήκη του παιδιού στη λίστα των παιδιών του επιλεγμένου κόμβου
        person.level = selected_individual.level + 1 # Αύξηση γενιάς κατά 1 για το παιδί
        if selected_parent.spouse != None: # Αν υπάρχει σύζυγος του επιλεγμένου κόμβου
            selected_parent.spouse.children.append(person) # τότε προσθήκη του παιδιού και στη λίστα παιδιών του συζύγου
        self.person_list.append(person) # προσθήκη του παιδιού και στη γενική λίστα ατόμων
        db.save(self.person_list, database_name)
        self.draw_family_tree()# (επανα)σχεδιασμός δέντρου
    # ΣΥΓΕΝΕΙΕΣ ΚΑΙ ΑΚΜΕΣ
    # Σύνδεση συζύγων
    def draw_spouse_relation(self, node1, node2): # node1 node 2 Οι δυο σύζυγοι      
        if node1.position_x < node2.position_x: # Σιγουρεύουμε οτι το node1 είναι αριστερά του node 2
            x1 = node1.position_x + node1.width # ένας απο τους δύο συζύγους σίγουρα θα βρίσκεται αριστερά του αλλου αν βγάλουμε το check τότε θα σχεδιάσει 2 αλληλοεπικαλυπτόμενες γραμμές 
            x2 = node2.position_x # παίρνουμε τα Χ ,το ενα είναι στη δεξιά άκρη του αριστερού κόμβου και το άλλο στην αριστερή του δεξιού κόμβου
            # else: # Περισσότερο debug Θα χρειαστεί πρίν βγάλουμε εντελώς τον έλεγχο
            #     x2 = node1.position_x + node1.width
            #     x1 = node2.position_x
            y = node1.position_y + (node1.height//2) # το Υ βρίσκεται στο μέσο του ύψους κάθε κόμβου
            self.canvas.create_line(x1, y, x2, y, width = 2, fill='red') # φτιάχνουμε μια γραμμή (ακμή) συνδέοντας τους κόμβους κόκκινου χρώματος (σύζυγοι)
    # Σύνδεση γονέων με παιδιά
    def draw_parental_relation(self, person, child, canvas): # person : γονέας child: παιδί προσθήκη και αντικειμένου canvas για να διαλέξουμε που να σχεδιάσει
        if person.spouse != None: # αν υπάρχει σύζυγος
            if person.position_x < person.spouse.position_x: #γονέας αριστερά του συζύγου
                x1 = (person.position_x + person.width + person.spouse.position_x) // 2 # πρώτο σημείο πρώτης γραμμής στο μέσο της απόστασης των 2 γονέων            
                y1 = person.position_y + (person.height//2) # και πάνω στη γραμμή που τους ενώνει
                y2  = y1 + (person.spacing_y//2) + (person.spacing_y//4) # δεύτερο σημείο της πρώτης γράμμης λιγο πιο κάτω (κάθετα) στο μέσο της απόστασης μεταξύ των γενεών 
                canvas.create_line(x1, y1, x1, y2, width = 2) # δημιουργία πρώτης γραμμής
                x2 = child.position_x + (child.width//2) # πρώτο σημέιο δεύτερης γραμμής στο μέσο του μήκους του κόμβου του παιδιού
                y1 = y2 # και στο ίδιο ύψος με την προηγούμενη γραμμή (στο μέσο της απόστασης μεταξύ των γενεών)
                y2 = y1 + (child.spacing_y//2) + child.width//4 - (person.spacing_y//4) #δεύτερο σημέιο δεύτερης γραμμής στο ίδιο Χ και κάθετα προς τα κάτω για να ενωσει τον κόμβο παιδιού
                canvas.create_line(x2, y1, x2, y2, width = 2) # δημιουργία δεύτερης γραμμής
                # τρίτη γραμμή (οριζόντια)
                if x1 != x2: # αν x1 Και x2 δεν ταυτίζονται(δηλαδή υπάρχει και άλλο παιδί)
                    canvas.create_line(x1, y1, x2, y1, width = 2) # τότε ένωσε τις κάθετες γραμμές μεταξύ τους
        else: # δεν υπάρχει σύζυγος
            #ίδια λογική με πριν
            x1 = person.position_x + (person.width//2) # απλά η πρώτη γραμμή ξεκινάει απο τον μοναδικό γονέα (στο μέσο του μήκους του)
            y1 = person.position_y + person.height # και στην κάτω επιφάνεια του κόμβου
            y2  = y1 + (person.spacing_y//2)  # και καταλήγει στο μέσο της απόστασης μταξύ των γενεών
            canvas.create_line(x1, y1, x1, y2, width = 2) # και κατευθύνεται κάθετα
            x2 = child.position_x + (child.width//2)# πρώτο σημέιο δεύτερης γραμμής στο μέσο του μήκους του κόμβου του παιδιού
            y1 = y2  # και στο ίδιο ύψος με την προηγούμενη γραμμή (στο μέσο της απόστασης μεταξύ των γενεών)
            y2 = y1 + (child.spacing_y//2) # δευτερο σημείο στο πάνω μέρος της επιφάνειας του κόμβου παιδιού
            canvas.create_line(x2, y1, x2, y2, width = 2) # δευτερη κάθετη γραμμή
            # τρίτη γραμμή (οριζόντια)
            if x1 != x2:# αν x1 Και x2 δεν ταυτίζονται(δηλαδή υπάρχει και άλλο παιδί)
                canvas.create_line(x1, y1, x2, y1, width = 2) # τότε ένωσε τις κάθετες γραμμές μεταξύ τους
    # Αναδιάταξη παιδιών και ευθυγράμμιση με τους γονείς
    # Οργάνωση κόμβων ανα επίπεδο (γενιά)
    def group_nodes_by_levels(self):
        for person in self.person_list: # διατρέχουμε όλα τα άτομα του δέντρου
            self.level_dict[person.level] = [] # Αρχικοποιούμε τα κλειδιά (επίπεδα) του λεξικού με κενές λίστες    
        for person in self.person_list: # διατρέχουμε πάλι όλα τα άτομα του δέντρου
            self.level_dict[person.level].append(person) # προσθήκη του ατόμου στο λεξικό στο αντίστοιχο κλειδί (γενιά)
    # Η καρδιά του προγράμματος και η βασική μέθοδος που θέτει τις συντεταγμένες σχεδιασμού των κόμβων
    # χρσιμοποιεί τον dot αλγόριθμο της Pygraphviz βιβλιοθήκης για να τοποθετήσει τους κόμβους σε δεντροειδές layout 
    # https://pygraphviz.github.io/documentation/stable/tutorial.html       
    def generate_positions(self):
        # δημιουργία ενός κενού κατευθυνόμενου διαγράμματος απο την pygraphviz
        G = pgv.AGraph(directed=True)
        # Προσθήκη των κόμβων και των συγγενειών(πρόγονος -> απόγονος)
        # στην παρούσα φάση οι σύζυγοι αγνοούνται για να προστεθούν αργότερα
        # Sort της λίστας ανα level αλλά αποδείχτηκε αχρείαστο
        # self.person_list.sort(key=lambda person: person.level)
        # Διόρθωση των γενεών ώστε η αρχαιότερη να ξεκινάει απο το 1
        min_level = min(person.level for person in self.person_list) # βρισκω την αρχαιότερη γενιά

        shift_value = abs(min_level) + 1 # υπολογίζω πόσο θα μετακινηθούν όλες οι γενιές
        for person in self.person_list: # για κάθε άτομο
            person.level += shift_value # διόρθωση της γενιάς τους
        # διόρθωση και sort των παιδιών ανάλογα με το αν εχουν σύζυγο με γονέα
        self.group_nodes_by_levels()
        for person in self.person_list:
            # παιδιά που έχουν σύζυγο με τουλάχιστον ένα γονέα
            children_with_spouse_and_parent = [child for child in person.children if child.spouse and (child.spouse.father or child.spouse.mother)]
            # παιδιά που δεν έχουν σύζυγο ή ο σύζυγος δεν έχει γονείς
            children_without_spouse_or_parent = [child for child in person.children if not child.spouse or not (child.spouse.father or child.spouse.mother)]
            # Αρχικοποίηση deque με τα παιδιά που δεν έχουν σύζυγο ή ο σύζυγος δεν έχει γονείς
            deque_children = deque(children_without_spouse_or_parent)
            # Now, for the children who have a spouse with a parent, we append them alternately to the start and end of the deque
            # Τώρα όσον αφορά τα παιδιά που έχουν σύζυγο με τουλάχιστον ένα γονέα
            # τα προσθέτουμε στο deque εναλλάξ στο τέλος και στην αρχή της λίστας.το πρωτο στο τελος το δευτερο στην αρχη κτλ
            for i, child in enumerate(children_with_spouse_and_parent):
                if i % 2 == 0:  # ζυγός στο τέλος
                    deque_children.append(child)
                else:  # μονός στην αρχή appendleft
                    deque_children.appendleft(child)
            # Μετατροπη του deck πίσω στη λίστα παιδιών του ατόμου
            person.children = list(deque_children)
        for person in self.person_list: # για κάθε άτομο στη λίστα
            # Νεα λογική προσθήκης ατόμων και συγγενειών στο γράφημα
            # διατρέχουμε τα παιδιά και τα πρσθέτουμε (μας βοηθάει στην περίπτωση που θέλουμε custom sort στην λίστα παιδιών)
            # παιδί με σύζυγο τερμα δεξιά κτλ
            if person.id not in G.nodes(): G.add_node(person.id) # προσθήκη του ατόμου στο γράφημα
            # Αν το άτομο είναι ζευγάρι με κάποιο χωρίς παιδιά,προσθέτουμε ενα ψευτικο παιδί για να κρατήσει τον κόμβο στην ίδια γενιά με τον σύζυγο
            #ειδάλλως επειδή ο κόμβος δεν εχει παιδιά ο αλγόριθμος τον θεωρεί ξεκρέμαστο και τον παει στο root (αρχαιότερη γενιά)
            if person.spouse and len(person.children)==0 : G.add_edge(person.id, "False_Child") 
            for child in person.children:  # για κάθε παιδί του ατόμου
                G.add_edge(person.id, child.id)  # Ορίζουμε τις συγγένειες
        # Ορισμός των αποστάσεων μεταξύ κόμβων και γενεών (πόσο απλωμένο θα είναι το γράφημα)
        G.graph_attr['ranksep'] = '2.0' # γενεές
        G.graph_attr['nodesep'] = '2.3' # κόμβοι
        # ορισμός της διάταξης σε dot αλγόριθμο
        # https://pygraphviz.github.io/documentation/stable/reference/agraph.html
        # https://graphviz.org/docs/layouts/
        G.layout(prog='dot')
        # εξαγωγή συντεταγμένων και τοποθέτηση σε λεξικό
        pos = {node: [float(coord) for coord in G.get_node(node).attr['pos'].split(',')] for node in G.nodes()}
        print(pos)
        positions = self.positions_to_grid_positions(pos) #βοηθητική συνάρτηση για διορθώσεις,ανενεργή προς το παρόν
        # Ορισμός των συντεταγμένων απο το λεξικό στα άτομα του δέντρου
        for person in self.person_list: # για κάθε άτομο στη συνολική λίστα
            if person.id in positions: # Αν το άτομο περιέχεται στο γράφημα (δεν έχει αγννοηθεί)
                position_x, position_y = positions[person.id] # ορισμός των μεταβλητών συντεταγμένων απο το λεξικό
                person.position_x = math.floor(position_x) # παραμένει ως έχει σύμφωνα με τον αλγόριθμο 
                # αντιστροφή της συντεταγμένης Υ γιατί το pygraphviz σχεδιάζει απο κάτω (μικρότερο Υ) προς τα πάνω (μεγαλύτερο Υ)
                person.position_y = 100 - math.floor(position_y) # ενω το tkinter που θέλουμε αναποδα απο πάνω προς τα κάτω 
    def positions_to_grid_positions(self, positions): # ανενεργή ,γυρνάει όλο το λεξικό
        return positions
    # Σχεδιασμός και ανανέωση Δέντρου
    # Εδώ χρησιμοποιούμε το Tkinter για να μας σχεδιάσει τους κόμβους με την create_rectangle
    def draw_family_tree(self):
        self.add_node_button.grid_remove()
        # Απαραίτητο Fix...ορισμός ιδιοτήτων Πατέρα και μητέρας στα παιδιά
        # γιατί η db load δεν τις υποστήριζε και η generate positions τις χρειάζεται
        for person in self.person_list: # για κάθε άτομο στη λίστα
            for child in person.children: # για κάθε παιδί του ατόμου 
                if person.gender == 'Άρρεν': # αν ο πρόγονος είναι γένους αρσενικού
                    child.father = person # τότε όρισέ τον ως πατέρα
                else: # αλλιώς 
                    child.mother = person # Ως μητέρα
        self.generate_positions() # κλήση συνάρτησης ορισμού συντεταγμένων απο τον αλγόριθμο
        self.canvas.delete("all") # καθαρισμός καμβά για επανασχεδίαση
        for person in self.person_list: # για κάθε άτομο στη λίστα
            x = person.position_x  # Ορισμός μεταβλητών συντεταγμένων Χ
            y = person.position_y  # και Υ
            if len(self.person_list) == 1:
                self.canvas.update()
                x = 530
                y = 430
            width = person.width  # πλάτος κόμβου
            height = person.height  # Ύψος κόμβου
            # Χρωματισμοί εν ζωή ή όχι
            if person.live == 'OXI':
                if person.gender == "Άρρεν":
                    color = DEAD_MALE_COLOR_VALUE
                elif person.gender == "Θήλυ":
                    color = DEAD_FEMALE_COLOR_VALUE
                else:
                    color = DEAD_OTHER_COLOR_VALUE
            elif person.gender == "Άρρεν":
                color = MALE_COLOR_VALUE 
            elif person.gender == "Θήλυ":
                color = FEMALE_COLOR_VALUE 
            else:
                color = OTHER_COLOR_VALUE
            
            # κλήση της create_rectangle σύμφωνα με τις παραπάνω μεταβλητές 
               
            square = self.canvas.create_rectangle(x, y, x + width, y + height,
                                                outline="#333333", fill=color, width=0, tags="single_shape") 
            # Τοποθέτηση του ονόματος του κόμβου στη μέση του τετραγώνου
            self.canvas.create_text(x + (width//2), y + (height//2), fill="white", font="Roboto 10", anchor="center", justify="center", 
                                    text=person.name + "\n" + person.surname) 
            person.shape = square # Αποθήκευση σχήματος στο αντικείμενο person
            if person == self.current_person:  # Αν το άτομο είναι το επιλεγμένο άτομο
                self.current_shape = square  # Ανανέωση του ID του κόμβου
                self.canvas.itemconfig(square, width = 3)  # Ορισμός ώς επιλεγμένου ξανά
                self.reorganize_buttons(self.current_person)
            # Όλα τα τετράγωνα που αντιπροσωπεύουν άτομα στον καμβά έχουν την ετικέτα "single_shape"
            self.canvas.tag_bind("single_shape","<Button-1>",self.single_shape_clicked) # κλήση της single_shape_clicked όταν κάνουμε κλίκ με το ποντίκι
            #Προσθήκη δεξιού κλικ με lambda function.Πρώτα καλούμε το single_shape_clicked για να επιλεγεί ο κόμβος και μετά το show_context_menu για να εμφανιστεί το μενού
            self.canvas.tag_bind("single_shape", "<Button-3>", lambda event: (self.single_shape_clicked(event), self.show_context_menu(event)))
            # https://anzeljg.github.io/rin2/book2/2405/docs/tkinter/canvas-methods.html
            # https://python.hotexamples.com/examples/tkinter/Canvas/tag_bind/python-canvas-tag_bind-method-examples.html
            if person.spouse != None: # Αν εχουμε σύζυγο
                self.draw_spouse_relation(person, person.spouse) # σχεδιασμός συγγένειας συζύγων με ακμή
            if person.children: # Αν έχουμε παιδιά
                for child in person.children: # για κάθε παιδί
                    self.draw_parental_relation(person, child, self.canvas) #Σχεδιασμός συγγένειας με ακμές για τα παιδιά στον κυρίως καμβά
            if len(self.person_list) > 1:
                ### συμμετρική στοίχιση του δέντρου τόσο κάθετα όσο και οριζόντια στον καμβά
                # Σχεδιασμός μπάρας κύλισης σε Χ και Υ για να ενεργοποιηθεί η δυνατότητα xview_moveto της Tkinter
                #https://stackoverflow.com/questions/54962248/move-tkinter-view-on-widget
                # Δεν τις τοποθετούμε όμως με Pack και τις κρατάμε κρυφές
                self.hsb = tk.Scrollbar(root, orient="horizontal", command=self.canvas.xview)
                self.vsb = tk.Scrollbar(root, orient="vertical", command=self.canvas.yview)
                # Ορίζουμε την περιχή κύλισης ως το bbox όλων των ζωγραφισμένων αντικειμένων στον καμβά
                # https://stackoverflow.com/questions/74682813/tkinter-canvas-scrolling-scrollregion-explained-un-restricted-area
                self.canvas.configure(scrollregion=self.canvas.bbox("all"))
                # Παίρνουμε τις συντεταγμένες του 'κουτιού' που περιέχει όλα τα elements Του καμβά
                # https://stackoverflow.com/questions/62712481/tkinter-why-is-there-such-a-thing-like-bbox
                x1, y1, x2, y2 = self.canvas.bbox("all")
                # Υπολογίζουμε το κέντρο τους τόσο οριζόντια όσο και κάθετα
                center_x = (x1 + x2) / 2
                center_y = (y1 + y2) / 2
                # παίρνουμε τις διαστάσεις του καμβά (ορατή περιοχή)
                canvas_width = self.canvas.winfo_width()
                canvas_height = self.canvas.winfo_height()
                # Υπολογίζουμε το ποσοστό κύλισης (scrollable area) που αντιπροσωπεύει το κέντρο όλων των αντικειμένων
                # και το προσαρμόζουμε για το μισό της ορατής περιοχής (visible area)
                x_fraction = (center_x - x1 - canvas_width / 2) / (x2 - x1)
                y_fraction = (center_y - y1 - canvas_height / 2) / (y2 - y1)
                # Εκτελούμε την xview_moveto και yview_moveto σύμφωνα με το παραπάνω ποσοστό για κύλιση στο κέντρο
                self.canvas.xview_moveto(x_fraction)
                self.canvas.yview_moveto(y_fraction)
            #if len(self.person_list) == 1:
            #    self.update_information()
    # Ανάγνωση ιδιοτήτων ατόμου απο τα πλαίσια κειμένου και ενημέρωση των ιδιοτήτων του επιλεγμένου ατόμου
    def update_information(self):
        # Αποθήκευση των ιδιοτήτων των ατόμων απο τα πεδια κειμένου σε μεταβλητές
        info_1 = self.id_entry.get() # Αναγνωριστικό ID
        info_2 = self.name_entry.get() # Όνομα
        info_3 = self.surname_entry.get() #Επίθετο
        info_4 = self.option_variable.get() # φύλλο
        info_5 = self.birth_entry.get() # ημερομηνία γεννησης 
        info_6 = self.option2_variable.get() #nai oxi en zvh
        info_7 = self.death_entry.get() # και θανάτου
        info_8 = self.comments_entry.get('1.0', 'end')
        birth_date_str = self.birth_entry.get()
        death_date_str = self.death_entry.get()

        try:
            # Αμυντικός προγραμματισμός εισαγωγής σωστής μορφής ημερομηνίας
            birth_date = datetime.strptime(birth_date_str, "%d/%m/%Y").date() if birth_date_str else None
            death_date = datetime.strptime(death_date_str, "%d/%m/%Y").date() if death_date_str else None
        except ValueError:
            print("ΣΦΑΛΜΑ! Η ημερομηνία πρέπει να έιναι της μορφής 'ΗΗ/ΜΜ/ΕΕΕΕ'")
            return
        ##ΑΜΥΝΤΙΚΟΣ ΠΡΟΓΡΑΜΜΑΤΙΣΜΟΣ ΗΜΕΡΟΜΗΝΙΩΝ ΔΙΑΦΟΡΩΝ ΠΕΡΙΠΤΩΣΕΩΝ
        # Γενέθλια στο μέλλον
        if birth_date and birth_date > datetime.today().date():
            print("ΣΦΑΛΜΑ! Τα γενέθλια δεν μπορεί να είναι μεταγενέστερα της σημερινής ημερομηνίας.")
            return

        # Θάνατος πρίν τα γενέθλια
        if death_date and death_date < birth_date:
            print("ΣΦΑΛΜΑ! Η ημερομηνια θανάτου δεν μπορεί να είναι προγενέστερη της γέννησης")
            return

        # Άτομο με παιδι/ια και μικρότερο των 18 
        if self.current_person.children and birth_date and  ((datetime.today().date() - birth_date).days / 365) < 18:
            print("ΣΦΑΛΜΑ! Ενα άτομο με παιδιά δεν μπορεί να είναι κάτω των 18 ετών.")
            return

        # Θάνατος στο μέλλον
        if death_date and death_date > datetime.today().date():
            print("ΣΦΑΛΜΑ! Η ημερομηνία θανάτου δεν μπορεί να είναι μεταγενέστερη της σημερινής ημερομηνίας.")
            return

        
        
        # if(sys.argv[1]=="False" or sys.argv[1]=="error-chosen file"):
        #     # print("mpika")
        #     try:                 
        #         # Σύνδεση με τη Β.Δ. poy dothike
        #         with sqlite3.connect(sys.argv[2]) as conn:
        #             cursor = conn.cursor()
        #             sql2 = "update person set name = ? ,surname = ?, gender = ?, birth = ?, live = ? where id = ?"
        #             cursor.execute(sql2, (str(info_2), str(info_3), str(info_4), str(info_5), str(info_6), str(info_1)))
        #     except sqlite3.Error as err:
        #         print("Error: ", err)  # Προβολή μηνύματος σφάλματος
        # else:
            # print("enter sto else")
        try:
            with sqlite3.connect(database_name) as conn:
                cursor = conn.cursor()
                sql2 = "UPDATE person SET name=?, surname=?, gender=?, birth=?, live=?, comments=? WHERE id=?"
                cursor.execute(sql2, (str(info_2), str(info_3), str(info_4), str(info_5), str(info_6), str(info_8), str(info_1)))
                # print(str(info_2)+" "+ str(info_3)+" "+ str(info_4)+" "+ str(info_5)+" "+str(info_6)+" "+ str(info_1))
                conn.commit()
        except sqlite3.Error as err:
            print("Error: ", err)  # Προβολή μηνύματος σφάλματος
        #Εντοπισμός Επιλεγμένου ατόμου με το κλασσικό πλέον τρόπο
        selected = None #αρχικοποίηση και καθαρισμός επιλεγμένου ατόμου
        selected = self.current_person
        #for individual in self.person_list: # για κάθε άτομο στο δέντρο
        #    if individual.shape == self.current_shape: # αν έχουμε επιλεγμένο σχήμα
        #        selected = individual # Αποθήκευση επιλεγμένου
        #        break # και έξοδος
        if selected == None: # αν δεν έχουμε επιλέξει κάτι
            return # μη κάνεις τίποτα
        #Εισαγωγή των αποθηκευμένων ιδιοτήτων του ατόμου στην κλάση
        selected.id = info_1 # Αναγνωριστικό ID
        selected.name = info_2 # Όνομα
        selected.surname = info_3 # Επίθετο
        selected.gender = info_4 # φύλλο
        selected.birth = info_5 # ημερομηνία γεννησης
        selected.live = info_6
        if selected.death :  selected.live = "OXI"
        selected.death = info_7 # και θανάτου
        selected.comments = info_8
        self.clear_information()
        self.display_information()
        self.draw_family_tree()  # ανανέωση δέντρου  
    # Εμφάνιση πληροφοριών ατόμου στα πεδία κειμένου
    def display_information(self):
        #Εντοπισμός Επιλεγμένου ατόμου με το κλασσικό πλέον τρόπο
        selected = None #αρχικοποίηση και καθαρισμός επιλεγμένου ατόμου
        selected = self.current_person
        #for individual in self.person_list: # για κάθε άτομο στο δέντρο
        #   if individual.shape == self.current_shape: # αν έχουμε επιλεγμένο σχήμα
        #        selected = individual # Αποθήκευση επιλεγμένου
        #        break # και έξοδος    
        if selected == None: # αν δεν έχουμε επιλέξει κάτι
            return # μη κάνεις τίποτα
        #Αποθήκευση των ιδιοτήτων σε λίστα
        data = [selected.id, selected.name, selected.surname, selected.gender, selected.birth, selected.death, selected.live, selected.comments]
        #Και επανάκτηση τους για εισαγωγή στα αντίστοιχα πεδία
        self.id_entry.insert(0,data[0]) # Αναγνωριστικό ID
        self.name_entry.insert(0,data[1]) # Όνομα
        self.surname_entry.insert(0,data[2]) # Επίθετο
        self.option_variable.set(data[3]) # φύλλο
        self.birth_entry.insert(0,data[4]) # ημερομηνία γεννησης
        self.death_entry.insert(0,data[5]) # και θανάτου
        self.option2_variable.set(data[6]) # και live
        self.comments_entry.insert("1.0",data[7])
    # καθαρισμός πεδίων πληροφοριών (πλαίσια κειμένου)
    def clear_information(self):
        self.id_entry.delete(0, END) # Αναγνωριστικό ID
        self.name_entry.delete(0, END) # Όνομα
        self.surname_entry.delete(0, END) # Επίθετο
        self.option_variable.set("Επιλογή") # φύλλο
        self.option2_variable.set("Επιλογή") # φύλλο
        self.birth_entry.delete(0, END) # ημερομηνία γεννησης
        self.death_entry.delete(0, END) # και θανάτου
        self.comments_entry.delete("1.0", END)
    # Αποθήκευση δέντρου σε αρχείο JSON
    def save_JSON_data(self):
        #data = list(self.shape_data.values())
        data = [] # Αρχικοποίηση κενής λίστας που θα χρησιμοποιηθεί για την αποθήκευση του δέντρου
        for person in self.person_list: # για κάθε άτομο στη λίστα
            person_data = {} # Αρχικοποίηση λεξικού που αποθηκέυει τις ιδιότητες του ατόμου (key:ιδιότητα value:τιμή)
            # Αποθήκευση σε μεταβλητές
            id = person.id # Αναγνωριστικό ID
            name = person.name # Όνομα
            surname = person.surname # Επίθετο
            gender = person.gender # φύλλο
            birth = person.birth # ημ/ν/ια γέννησης
            death = person.death # και θανάτου
            live = person.live # εν ζωή
            comments = person.comments # σχόλια
            spouse = person.spouse # Σύζυγος
            children = person.children # παιδιά
            x_pos = person.position_x # Συντεταγμένη Χ
            y_pos = person.position_y # Συντεταγμένη Υ
            level = person.level # Γενιά
            # Αν οι παραπάνω μεταβλητές περιέχουν τιμές τότε αποθήκευση στο λεξικό με τα κλειδιά τους 
            if id:
                person_data["id"] =  id # Αναγνωριστικό ID
            if name:
                person_data["name"] = name # Όνομα
            if surname:
                person_data["surname"] = surname # Επίθετο
            if gender:
                person_data["gender"] = gender # φύλλο
            if birth:
                person_data["birth"] = birth # ημ/ν/ια γέννησης
            if death:
                person_data["death"] = death  # και θανάτου
            if live:
                person_data["live"] = live # εν ζωή
            if comments:
                person_data["comments"] = comments # σχόλια           
            if spouse != None: #αν υπάρχει σύζυγος
                person_data["spouse"] = str(spouse.id) # το ID του/της συζύγου
            if children != None: # Αν έχουμε παιδιά 
                person_data["children"] = [] #αρχικοποίηση λίστας που τα αποθηκέυει
                for child in children: #iteration για κάθε παιδί
                    person_data["children"].append(str(child.id)) #Και αποθήκευση στη λίστα
            person_data["x"] = str(x_pos) # Συντεταγμένη Χ
            person_data["y"] = str(y_pos) # Συντεταγμένη Υ
            person_data["level"] = str(level) # Γενιά
            data.append(person_data) # Προσθήκη του ολοκληρωμένου λεξικού στη λίστα
            filename = "output1.json" # Αρχείο αποθήκευσης,ίσως χρειαστει να βάλουμε User input interaction για την επιλογή ονόματος με το fd
            # Αποθήκευση της λίστα σε JSON format
            # https://www.geeksforgeeks.org/json-dump-in-python/
            with open(filename, "w") as outfile:
                json.dump(data, outfile, indent=4, separators=(',', ': '))
                
                
    # Αποθήκευση δέντρου σε αρχείο XML
    def save_XML_data(self):
        root = ET.Element("tree")
            
        # Δημιουργία ενός λεξικό για την αποθήκευση αντικειμένων ατόμων με την ταυτότητά τους
        person_dict = {}

        # Επανάληψη για κάθε άτομο στη λίστα person_list
        for person in self.person_list:

            # Δημιουργία ενός στοιχείου <person> για κάθε άτομο
            person_element = ET.SubElement(root, "person")

            # Προσθήκη του αντικειμένου προσώπου στο λεξικό χρησιμοποιώντας το ID του ως κλειδί
            person_dict[person.id] = person

            # Ορισμός των χαρακτηριστικών για το στοιχείο person
            person_element.set("id", str(person.id) if person.id else "")
            person_element.set("name", person.name if person.name else "")
            person_element.set("surname", person.surname if person.surname else "")
            person_element.set("gender", person.gender if person.gender else "")
            person_element.set("birth", person.birth if person.birth else "")
            person_element.set("death", person.death if person.death else "")
            person_element.set("live", person.live if person.live else "")
            person_element.set("comments", person.comments if person.comments else "")
            person_element.set("x", str(person.position_x))
            person_element.set("y", str(person.position_y))
            person_element.set("level", str(person.level))

            # Προσθήκη στοιχείου <spouse> αν υπάρχει σύζυγος
            if person.spouse:
                spouse_element = ET.SubElement(person_element, "spouse")
                spouse_element.set("ref", str(person.spouse.id))

            # Προσθήκη στοιχείου <children> αν υπάρχουν παιδιά
            if person.children:
                children_element = ET.SubElement(person_element, "children")
                for child in person.children:
                    # Προσθήκη στοιχείου <child> για κάθε παιδί και ορισμός του ref ως το ID του παιδιού
                    child_element = ET.SubElement(children_element, "child")
                    child_element.set("ref", str(child.id))

        # Δημιουργία του δέντρου XML χρησιμοποιώντας το ριζικό στοιχείο
        tree = ET.ElementTree(root)

        filename_xml = "output_xml.xml"

        # Εγγραφή του δέντρου XML στο αρχείο
        tree.write(filename_xml) 
        
                   
    # Εισαγωγή Δέντρου απο αρχείο
    def import_data(self):
        # πλαίσιο διαλόγου για την επιλογή αρχείου προς εισαγωγή
        # https://docs.python.org/3/library/dialog.html
        # https://pythonspot.com/tk-file-dialogs/
        filename = fd.askopenfilename() # το όνομα του αρχείου που επιλέξαμε
        if not filename: # αν δε διαλέξουμε,ακύρωση κτλ
            return # μη κάνεις τίποτα
        self.person_list = [] # Άδειασμα της λίστας των ατόμων για επανεισαγωγή απο το αρχείο
        #ανοίγουμε το αρχείο για διάβασμα
        file = open (filename, "r") # https://tutorial.eyehunts.com/python/python-file-modes-open-write-append-r-r-w-w-x-etc/
        """ΣΗΜΑΝΤΙΚΟ!Εδώ θα χρειαστεί να εισάγουμε αμυντικό προγραμματισμό που να εξασφαλίζει οτι το αρχείο έχει το σωστό format και τα σωστα
            δεδομένα.Μια ιδέα είναι να βάλουμε ενα μοναδικό αναγνωριστικό μέσα στο αρχείο JSON που θα μας επιτρεπει να καταλάβουμε οτι το
            αρχείο δημιουργήθηκε απο την εφαρμογή μας"""
        # Προσδιορισμός του τύπου αρχείου βάσει της κατάληξης του αρχείου
        file_ext = os.path.splitext(filename)[1]

        if file_ext == ".json":
            with open(filename) as file:
                #Διάβασμα/προσπέλαση του JSON
                # https://www.geeksforgeeks.org/json-loads-in-python/
                data = json.loads(file.read())
                # Διατρέχουμε το JSON και αποκτούμε πρόσβαση στα λεξικά του
                for dict in data: # Για κάθε λεξικό στη λίστα του JSON
                    person = Person() # δημιουργουμε ενα αντικείμενο τύπου person,ενα άτομο δηλαδή για να εισάγουμε τις ιδιότητες του
            # Αν οι ιδιότητες είναι υπαρκτές στο λεξικό τότε τις εισάγουμε
                    if "id" in dict:
                        person.id = dict["id"] # Αναγνωριστικό ID
                    if "name" in dict:
                        person.name = dict["name"] # Όνομα
                    if "surname" in dict:
                        person.surname = dict["surname"] # Επίθετο    
                    if "gender" in dict:
                        person.gender = dict["gender"] # φύλλο
                    if "birth" in dict:
                        person.birth = dict["birth"] # ημ/ν/ια γέννησης
                    if "death" in dict:
                        person.death = dict["death"] # και θανάτου 
                    if "live" in dict:
                        person.live = dict["live"]
                    if "comments" in dict:
                        person.comments = dict["comments"]
                    if "children" in dict:
                        person.children = dict["children"] # παιδιά.Προσοχή!Αυτό γυρίζει το ID του παιδιού,αλλά εμέις θέλουμε το αντικείμενο τύπου person για αυτό μετατρέπουμε παρακάτω
                    if "spouse" in dict:
                        person.spouse = dict["spouse"] # σύζυγος!Ομοίως με τα παιδιά
                    if "x" in dict:
                        person.position_x = int(dict["x"]) # Συντεταγμένη Χ
                    if "y" in dict:
                        person.position_y = int(dict["y"]) # Συντεταγμένη Υ
                    if "level" in dict:
                        person.level = int(dict["level"]) # Γενιά   
                    self.person_list.append(person) # προσθήκη του ατόμου στη γενική λίστα ατόμων
                # Κλείσμο αρχείου μετά την προσπέλαση
                file.close()
                #print("length", (self.person_list))
                # διόρθωση αναφορών παιδιών απο το ID τους σε αντικείμενα
                for person in self.person_list: # προσπέλαση όλων των ατόμων στη λίστα
                    children_count = len(person.children) # αποθήκευση αριθμού παιδιών του ατόμου σε μεταβλητή
                    if children_count > 0: # αν έχουμε παιδιά
                        for i in range(children_count): # προσπέλαση τους
                            #print(i)
                            if isinstance(person.children[i], str): # Αν η ιδιότητα children[i] είναι τύπου string (δλδ ID απο την εισαγωγή) θέλει μετατροπή
                                for each in self.person_list: # Για κάθε άτομο ξανά απο το σύνολο των ατόμων
                                    if each.id == person.children[i]: # Αν εχουν το ID για ιδιότητα
                                        person.children[i] = each # μετατροπή σε αντικείμενο και αποθήκευση Overwrite στην ιδιότητα του αντικειμένου αυτή τη φορά
                                        break #εξοδος και επόμενο ατομο
                # Ίδια λογική ακολουθειται για τους συζύγους
                    if person.spouse != "None": # Υπάρχει σύζυγος
                        for each in self.person_list: # για κάθε άτομο στη συνολική λίστα
                            if each.id == person.spouse: # αν το ID του συζύγου ταιριάζει με αυτό απο το εισαγόμενο αρχείο
                                person.spouse = each # αντικατέστησε το με αντικείμενο τυπου person και δήλωσε το σύζυγο
                                break # εξοδος και επόμενο ατομο
                    else: # δεν εχουμε σύζυγο
                        person.spouse = None # αντικατάσταση του string με None
                self.draw_family_tree() # Σχεδιασμός δέντρου για την εμφάνιση δέμτρου που εισάγαμε απο αρχείο

        elif file_ext == ".xml":
            tree = ET.parse(filename)
            root = tree.getroot()

            person_dict = {}  # Λεξικό για να αποθηκεύει τα αντικείμενα ατόμων με βάση το αναγνωριστικό (ID) τους

            for person_element in root.findall("person"):
                person = Person()

                if "id" in person_element.attrib:
                    person.id = person_element.attrib["id"]
                if "name" in person_element.attrib:
                    person.name = person_element.attrib["name"]
                if "surname" in person_element.attrib:
                    person.surname = person_element.attrib["surname"]
                if "gender" in person_element.attrib:
                    person.gender = person_element.attrib["gender"]
                if "birth" in person_element.attrib:
                    person.birth = person_element.attrib["birth"]
                if "death" in person_element.attrib:
                    person.death = person_element.attrib["death"]
                if "live" in person_element.attrib:
                    person.live = person_element.attrib["live"]
                if "comments" in person_element.attrib:
                    person.comments = person_element.attrib["comments"]
                if "x" in person_element.attrib:
                    person.position_x = int(person_element.attrib["x"])
                if "y" in person_element.attrib:
                    person.position_y = int(person_element.attrib["y"])
                if "level" in person_element.attrib:
                    person.level = int(person_element.attrib["level"])

                children = person_element.findall("children")
                if children:
                    person.children = [child.attrib.get("ref") for child in children[0].findall("child")]

                    spouse = person_element.findall("spouse")
                if spouse:
                    person.spouse = spouse[0].attrib.get("ref")

                    person_dict[person.id] = person  # Αποθήκευση του αντικείμενου τύπου προσώπου στο λεξικό χρησιμοποιώντας το ID ως κλειδί.

            # Σύνδεση των παιδιών και συζύγων με τα αντίστοιχα αντικείμενα προσώπων.
            for person in person_dict.values():
                if person.children:
                    person.children = [person_dict[child_id] for child_id in person.children if child_id in person_dict]
                else:
                    person.children = []

                if person.spouse:
                    person.spouse = person_dict.get(person.spouse)

            self.person_list = list(person_dict.values())  # Μετατροπή του λεξικού προσώπων σε μια λίστα.

            self.draw_family_tree()  # Σχεδιασμός δέντρου βάσει # Σχεδιασμός δέντρου βάσει του αρχείου που εισήχθει

        else:
            raise ValueError("Invalid file type. Only json and xml files are supported.")



    # καθαρισμός όλων των κόμβων
    def clear_all(self):
        # Προσθήκη παραθύρου διαλόγου πριν την διαγραφή με προειδοποίηση
        # https://www.geeksforgeeks.org/python-tkinter-askquestion-dialog/
        msg_box = messagebox.askquestion('Διαγραφή Όλων', 'Είστε σίγουροι οτι θέλετε να διαγράψετε όλους τους κόμβους?', 
                                        icon='warning') # Προειδοποίηση
        if msg_box != 'yes': # ακύρωση
            return
        self.person_list = [] # Απλά καθαρίζουμε τη λίστα με τα συνολικά άτομα
        self.canvas.delete("all")
        self.add_node_button.grid()
        db.delete()
        self.master.destroy()
        string_to_pass_synexisoume = "συνεχίσουμε"
        subprocess.Popen(["python", "build\page1.py",string_to_pass_synexisoume]).wait()
        #self.draw_family_tree() # και ανανεώνουμε τον σχεδιασμό του καμβά
    #Αποθήκευση δέντρου σε βλαση δεδομένων    
    def save_db_data(self):
        filename = fd.asksaveasfilename()
        if filename == '':
            return
        # db.database_name = filename
        filename_db = filename + '.db'
        db_set_name.set_database_name(filename_db)
        db_set_name.create_table()
        db.save(self.person_list, filename_db)
    # Εισαγωγή Δέντρου απο αρχείο Database (Πλαρίνος Ερμάνος)
    def import_db_data(self):
        if(sys.argv[1] == False or sys.argv[1] == 'epitixia'):
            #  string_received = sys.argv[1]
             filename = sys.argv[2]
        else:
            filename = fd.askopenfilename()
        if filename == '':
            return
        db.database_name = filename
        db_set_name.set_database_name(filename)
        db_set_name.create_table()
        #database_name = filename
        #print(database_name)
        self.person_list, self.everyone, self.level_dict = db.load()
        self.draw_family_tree() # Σχεδιασμός δέντρου για την εμφάνιση δέμτρου που εισάγαμε απο αρχείο          

    def import_new_data_to_db(id,name, surname, gender, birth, live,level,spouse,children):
        sql = "INSERT INTO person (id,name, surname,gender,birth,live,level,position_x,position_y,spouse,children,comments) VALUES (?,?,?,?,?,?,?,?,?,?)"
        try:
            # Σύνδεση με τη Β.Δ. people
            with sqlite3.connect(db.database_name) as conn:
                cursor = conn.cursor()
                cursor.execute(sql, (id,name, surname, gender, birth,live,level,'','',spouse,children))
        except sqlite3.Error as err:
            print("Error: ", err)  # Προβολή μηνύματος σφάλματος
    
   
    # Διαγραφή ατόμου
        """Η λογική που ακολουθούμε για την διαγραφή του ατόμου έχει ώς εξής:
        Εκτός απο την διαγραφή του ίδιου του ατόμου διαγράφουμε και τους απογόνους του σε περίπτωση που το ιδιο το άτομο αποτελεί το μοναδικό σύνδεσμο μεταξύ προηγούμενης
        και επόμενης γενιάς γιατί αλλιώς θα έχουμε κενό μεταξύ των γενεών και θα δημιουργηθούν προβλήματα.Οι περιπτώσεις που εξετάζουμε είναι:
        1. Το άτομο να έχει γονείς και παιδιά αλλά όχι σύζυγο (διαγραφή απογόνων)
        2. Το άτομο να έχει γονείς και παιδιά και σύζυγο χωρίς γονείς (διαγραφή απογόνων και συζύγου)
        """
    def delete_node(self):
        if self.current_shape == None:
            messagebox.showwarning(title="Δέν έχει επιλεγεί κόμβος", message="Παρακαλώ επιλέξτε τον κόμβο που θέλετε να διαγράψετε")
            return
        # Προσθήκη παραθύρου διαλόγου πριν την διαγραφή με προειδοποίηση
        # https://www.geeksforgeeks.org/python-tkinter-askquestion-dialog/
        msg_box = messagebox.askquestion('Προειδοποίηση Διαγραφής!', 'Είστε σίγουροι οτι θέλετε να διαγράψετε τον επιλεγμένο κόμβο? \nΑυτή η ενέργεια μπορεί να διαγράψει και όλους τους απογόνους του κόμβου!',
                                        icon='warning') # Προειδοποίηση
        if msg_box != 'yes': # ακύρωση
            return
        # else:    
        selected_individual = None # Αρχικοποίηση επιλεγμένου ατόμου
        for individual in self.person_list: # iteration στη λίστα ατόμων για την εύρεση του επιλεγμένου ατόμου
            if individual.shape == self.current_shape: # αν είναι ο επιλεγμένος κόμβος
                selected_individual = individual #ορισμός επιλεγμένου ατόμου
                break
        # Ομαδοποίηση κόμβων ανα επίπεδο (γενιά) και έλεγχος για γονείς
        self.group_nodes_by_levels()
        nodes_above = [] # Αρχικοποίηση λίστας αποθήκευσης κόμβων προηγούμενης γενιάς
        if (selected_individual.level - 1) in self.level_dict: # Έλεγχος επιπέδου που είναι μία γενιά πάνω από το επίπεδο του επιλεγμένου ατόμου (γονείς) στο self.level_dict.
            nodes_above = self.level_dict[selected_individual.level - 1] # Αν υπάρχει, αποθηκεύση της λίστας των κόμβων που ανήκουν σε αυτό το επίπεδο στη μεταβλητή nodes_above.
        has_parent = False # Μεταβλητή παρακολούθησης αν ο επιλεγμένος κόμβος έχει γονείς
        # Έλεγχος αν ο σύζυγος του επλεγμένου ατόμου υπάρχει και αν υπάρχει έλεγχος αν εχει παιδιά
        spouse_has_parent = False # boolean μεταβλητή ελέγχου ύπαρξης γονέων του συζύγου
        for node in nodes_above: # για κάθε κόμβο στη γενιά γονέων
            if selected_individual in node.children: # αν ο επιλεγμένος κόμβος έχει γονείς
                has_parent= True # αλλαγή της μεταβλητής σε αληθή
            if selected_individual.spouse != None: # Αν υπάρχει σύζυγος
                if selected_individual.spouse in node.children: # αν ο σύζυγος έχει γονείς (αντιστρόφως αν στη λίστα γονέων υπάρχει κόμβος με δηλωμένο παιδί τον/την σύζυγο)
                    spouse_has_parent = True # Εχει ο σύζυγος γονείς και μετατροπή της μεταβλήτής σε αληθή
        # πρίν τη διαγραφή του κόμβου πρέπει να τον αφαιρέσουμε και ως σύζυγο απο τον/την σύζυγο!
        if selected_individual.spouse != None: # αν υπάρχει σύζυγος
            selected_individual.spouse.spouse = None # αφαίρεση του ατόμου απο τον σύζυγο ώς σύζυγο
        # Αφαίρεση ατόμου απο τη λίστα παιδιών του γονέα
        for person in self.person_list:
            print(person.name, person.id, person.children, selected_individual.id)
            if selected_individual in person.children:
                person.children.remove(selected_individual)
        if not spouse_has_parent and has_parent: # αν ο σύζυγος δεν έχει γονείς πρέπει να διαγραφεί και αυτός μαζί με τους απογόνους για να μη μείνει ξεκρέμαστος
            recursively_delete_children(selected_individual, self.person_list) # κλήση αναδρομικής συνάρτησης διαγραφής παιδιών
            if selected_individual.spouse != None: # αν πάρχει σύζυγος
                self.person_list.remove(selected_individual.spouse) # διέγραψέ τον
        for node in nodes_above: # για κάθες κόμβο στο επίπεδο γονέων
            if selected_individual in node.children: # Αν ο επιλεγμένος κόμβος ανήκει στα παιδιά του
                node.children.remove(selected_individual) # Διαγραφή απο παιδί
        self.person_list.remove(selected_individual) # Και εν τέλει διαγραφή και του ίδιου το ατόμου
        db.save(self.person_list, database_name)
        self.draw_family_tree() # Επανασχεδιασμός δέντρου
    # Ενεργοποίηση / απενεργοποίηση κουμπιών για αποφυγή διπλών καταχωρήσσεων
    # Αμυντικός Προγραμματισμός
    def reorganize_buttons(self,person):
        # πρώτα ενεργοποιούμε τα κουμπιά που μας ενδιαφέρουν
        self.add_spouse_button.configure(state="normal")
        self.add_parents_button.configure(state="normal")
        self.add_sibling_button.configure(state="normal")
        # Αν υπάρχει σύζυγος απενεργοποιούμε την επιλογή προσθήκης
        if person.spouse : 
            self.add_spouse_button.configure(state="disabled")
        # Ομοίως αν υπάρχει γονέας
        if person.father or person.mother : 
            self.add_parents_button.configure(state="disabled")
        # Αν δεν υπάρχουν γονείς
        if not person.father and not person.mother :
            self.add_sibling_button.configure(state="disabled")
    # Αποθήκευση σε αρχείο εικόνας (δεν έχει υλοποιηθεί ακόμα)
    def export_data(self):
        save_as_png(self.canvas, "trial")
    # Εμφάνιση παραθύρου βοήθειας (υπο υλοποίηση)
    def show_help(self):
        # https://www.geeksforgeeks.org/python-tkinter-toplevel-widget/
        help_window = Toplevel(root) # δημιουργία αναδυόμενου παραθύρου
        help_window.geometry("640x400") # διαστάσεις παραθύρου
        help_window.title("Βοήθεια") # τίτλος
        help_text = Label(help_window, text = "Εμφάνιση βοήθειας για την εφαρμογή") # δημιουργία ετικέτας label
        help_text.pack() # τοποθέτηση της ετικέτας με τη μέθοδο pack https://www.pythontutorial.net/tkinter/tkinter-pack/
        # Ακολουθεί κώδικας με οδηγίες χειρισμού της εφαρμογής 
    # Συνάρτηση για την εμφάνιση των πληροφοριών του ατόμου
    # Προαπαιτούμενο
    def show_person_info(self):
        # Εύρεση ατόμου Με τον κλασσικό τρόπο

        
        selected = None
        for person in self.person_list:
            if person.shape == self.current_shape:
                selected = person
                break
        if selected is None:
            return
        # Δημιουργία παραθύρου για τις πληροφορίες Ατόμου
        # for testing purpose ...Χρειάζεται επανασχεδιασμός!!
        subprocess.Popen(["python", "build\details.py", selected.id,selected.name, selected.surname,selected.live, selected.birth, selected.gender,selected.death]).wait()
        # info_window = Toplevel(self.canvas)
        # info_window.title("Πληροφορίες Ατόμου")
        # info_window.geometry("300x200")
        # # Προσθήκη ετικετών
        # Label(info_window, text="ID:").grid(row=0, column=0)
        # Label(info_window, text="Όνομα:").grid(row=1, column=0)
        # Label(info_window, text="Γένος:").grid(row=2, column=0)
        # Label(info_window, text="Ημν/νία Γέννησης:").grid(row=3, column=0)
        # Label(info_window, text="Ημνία Θανάτου:").grid(row=4, column=0)
        # # Εμφάνιση πληροφοριών
        # Label(info_window, text=selected.id).grid(row=0, column=1)
        # Label(info_window, text=selected.name).grid(row=1, column=1)
        # Label(info_window, text=selected.gender).grid(row=2, column=1)
        # Label(info_window, text=selected.birth).grid(row=3, column=1)
        # Label(info_window, text=selected.death).grid(row=4, column=1)
    # Δημιουργία και παραμετροποίηση γραφικού περιβάλλοντος GUI ή UI
    def initUI(self):
        # https://python-textbok.readthedocs.io/en/1.0/Introduction_to_GUI_Programming.html
        # https://zetcode.com/tkinter/introduction/
        # https://stackoverflow.com/questions/62536863/tkinter-help-difference-between-master-and-root-keywords-in-this-code
        self.master.title("Οικογενειακό Δέντρο") # Τίτλος του κυρίως παραθύρου
        # https://stackoverflow.com/questions/28089942/difference-between-fill-and-expand-options-for-tkinter-pack-method
        self.pack(fill=BOTH, expand=1) # https://www.youtube.com/watch?v=40nqqDD3Frk Δημιουργία επετασιμου παραθύρου που αξιοποιεί όλο το χώρο
        # δημιουργία ενός νέου αντικείμενο Style από τη βιβλιοθήκη ttk της Tkinter για την προσαρμογή της εμφάνισης των widgets.
        # έτσι μπορούμε να δημιουργήσουμε προκαθοριθσμένα στυλ για την διαχείριση των στοιχείων το GUI...κουμπιά λίστες πλαισια κειμένου κτλ
        # https://www.pythontutorial.net/tkinter/ttk-style/
        style = ttk.Style()
        """χρησιμοποιούμε το αντικείμενο Style που δημιουργήθηκε προηγουμένως για να προσαρμόσoυμε την εμφάνιση των κουμπιών (TButton)
            της εφαρμογής. Η μέθοδος configure ορίζει τις ιδιότητες του στυλ που θέλουμε να αλλάξουμε. το όνομα του στύλ είναι W.Tbutton"""
        style.configure('W.TButton', font = # Γραμματοσειρές
                    ('calibri', 10, 'bold', 'underline'), # χρώμα κτλ
                        foreground = 'red')
        # με τον ίδιο τρόπο ορίχουμε το στυλ των κουμπιών του μενού
        style.configure("TMenubutton", background="#cccccc") # φόντο σε γκριζάκι
        # Δημιουργία μπάρας μενού
        menu = Menu(self.master, bg="gray") # δημιουργία μπάρας με το όνομα menu για το περιβάλλον self.master (μαστερ παραθυρο) με φόντο γκρίζο
        self.master.config(menu=menu) # ορισμός του menu που φτιάξαμε πριν...ως menu ! σωστά μαντέψατε!!
        # Δημιουργία του αντικειμένου file ("Αρχείο") χωρίς δυνατότητα αποκόλλησης απο την εφαρμογή
        file = Menu(menu, tearoff = 0) # https://www.geeksforgeeks.org/what-does-the-tearoff-attribute-do-in-a-tkinter-menu/
        #Εισαγωγή εντολών και επιλογών https://www.tutorialspoint.com/python/tk_menu.htm
        file.add_command(label="Εισαγωγή απο αρχείο", command=self.import_data) # προσθηκη στο υπομενου file επιλογής εισαγωγη απο αρχείο(τρεχει την self.import_data κατά την επιλογή του χρήστη)
        file.add_separator()
        file.add_command(label="Εξαγωγή σε αρχείο JSON", command=self.save_JSON_data) # Αντίστοιχα επιλογη εξαγωγής σε αρχείο με την αντίστοιχη συναρτηση που θα κληθεί αν ο χρήστης την επιλέξει
        file.add_command(label="Εξαγωγή σε αρχείο XML", command=self.save_JSON_data) # Αντίστοιχα επιλογη εξαγωγής σε αρχείο με την αντίστοιχη συναρτηση που θα κληθεί αν ο χρήστης την επιλέξει
        file.add_separator()
        file.add_command(label="Εισαγωγή απο αρχείο DB", command=self.import_db_data) # προσθηκη στο υπομενου file επιλογής εισαγωγη απο αρχείο(τρεχει την self.import_data κατά την επιλογή του χρήστη)
        file.add_command(label="Εξαγωγή σε αρχείο DB", command=self.save_db_data) # Αντίστοιχα επιλογη εξαγωγής σε αρχείο με την αντίστοιχη συναρτηση που θα κληθεί αν ο χρήστης την επιλέξει
       # file.add_command(label="Εξαγωγή σε εικόνα .PNG", command=self.export_data) # ομοίως εξαγωγή σε εικόνα 
        #Προσθήκη του υπομενου "file" με τις επιλογές που φτιάξαμε παραπάνω στη μπαρα με ετικέτα "Aρχείο"
        # https://pythonbasics.org/tkinter-menu/
        menu.add_cascade(label="Αρχείο", menu=file) # προσθήκη στο υπομενού
        # με την ίδια ακριβώς λογική φτιάχνουμε το μενού βοήθειας
        help = Menu(menu, tearoff = 0)
        help.add_command(label="Εμφάνιση Βοήθειας", command=self.show_help) # συναρτηση show_help (υπο υλοποίηση)
        #Με τον ίδιο τρόπο όπως πιο πάνω προσθέτουμε και την επιλογή της βοήθειας για την εφαρμογή
        menu.add_cascade(label="Βοήθεια", menu=help)
        # Δημιουργία πλαισίων
        
        # Θα δημιουργήσουμε 4 frame
        # 1. Το main_frame που θα περιέχει όλα τα άλλα πλαίσια
        self.main_frame = customtkinter.CTkFrame(self) # δημιουργία του πλαισίου
        self.main_frame.pack(fill = BOTH, expand = True) # Επεκτάσιμο και γεμίζει κατακόρυφα και οριζόντια σε ολο το παράθυρο (fill =BOTH)
        # 2. Το buttons_frame που θα περιέχει τα κουμπιά ελέγχου των κόμβων ("προσθήκη γονέων" κτλ)
        # σημείωση:εδω αντί για pack χρησιμοποιούμε grid μέθοδο
        # https://www.pythontutorial.net/tkinter/tkinter-grid/
        self.buttons_frame = customtkinter.CTkFrame(self.main_frame) # δημιουργία του πλαισίου στο main_frame
        # γραμμη και στήλη 0 (πάνω αριστερά),sticky west east north south(πιάνει όλο το χώρο του κελιού του),και περιθώριο 10 απο αριστερά-δεξιά και 20 απο πάνω-κάτω
        self.buttons_frame.grid(row = 0, column = 0, sticky="ewns", padx = 10, pady = 10) 
        
        # 3. Το information_frame που περιέχει τα πεδία κειμένου πληροφοριών του επιλεγμένου ατόμου
        self.information_frame = customtkinter.CTkFrame(self.main_frame) # δημιουργία του πλαισίου στο main_frame
        self.information_frame.grid(row = 1, column = 0, sticky="ewns", padx = 10, pady = 20) # γραμμή 1 (κάτω απο το buttons_frame)
        # Το canvas_frame που περιέχει τον καμβά σχεδίασης του δέντρου
        self.canvas_frame = Frame(self.main_frame) # δημιουργία του πλαισίου στο main_frame
        # 2η στήλη (δεξιά των άλλων 2 πλαισίων) και rowspan 2 που σημάινει επεκτείνεται σε 2 γραμμές (καλύπτοντας ουσιαστικά όλο το υψος του main frame)
        self.canvas_frame.grid(row = 0, column = 1, rowspan=2, sticky="ewns", padx = 20, pady = 20) 
        # Δημιουργία κουμπιών ελεγχου
        # Εδω παλι θα χρησιμοποιήσουμε την customtkinter.Τα κουμπιά αποτελουν instances της κλασης CTkButton απο την customtkinter
        # εχουν εύρος πλήρες απο αριστερά προς τα δεξιά (sticky="ew"),πιανουν χώρο 2 στηλών και πάλι τοποθετούνται με τη μέθοδο grid
        # Αρχικά βάζουμε μια κενή ετικέττα για λόγους συμμετρίας και ομορφιάς
        self.current_person_label = customtkinter.CTkLabel(self.buttons_frame, text="", font=("Roboto", 16, "bold"))
        self.current_person_label.grid(columnspan=2, sticky="ew", padx = 30)

        #empty = customtkinter.CTkLabel(self.buttons_frame, text = "") # κενή ετικέττα
        #empty.grid(columnspan=2, sticky="ew", padx = 30) 
        # Κουμπί προσθήκης νέου κόμβου που καλεί την αντίστοιχη συνάρτηση
        self.add_node_button = customtkinter.CTkButton(self.buttons_frame, text = "Προσθήκη Κόμβου", command=self.add_new_node)
        self.add_node_button.grid(columnspan=2, sticky="ew", padx = 30)
        # Κουμπί προσθήκης παιδιού που καλεί την αντίστοιχη συνάρτηση
        self.add_child_button = customtkinter.CTkButton(self.buttons_frame, text = "Προσθήκη Παιδιού", command=self.add_child)
        self.add_child_button.grid(columnspan=2, pady = 8, sticky="ew", padx = 30)
        # Κουμπί προσθήκης συζύγου που καλεί την αντίστοιχη συνάρτηση
        self.add_spouse_button = customtkinter.CTkButton(self.buttons_frame, text = "Προσθήκη Συζύγου", command=self.add_spouse)
        self.add_spouse_button.grid(columnspan=2, sticky="ew", padx = 30)
        # Κουμπί προσθήκης γονέων που καλεί την αντίστοιχη συνάρτηση
        self.add_parents_button = customtkinter.CTkButton(self.buttons_frame, text = "Προσθήκη Γονέων", command=self.add_parents)
        self.add_parents_button.grid(columnspan=2, pady = 8, sticky="ew", padx = 30)
        # Κουμπί προσθήκης αδελφών που καλεί την αντίστοιχη συνάρτηση
        self.add_sibling_button = customtkinter.CTkButton(self.buttons_frame, text = "Προσθήκη Αδελφών", command=self.add_sibling)
        self.add_sibling_button.grid(columnspan=2, sticky="ew", padx = 30)
         # Κουμπί διαγραφής κόμβου
        self.delete_node_button = customtkinter.CTkButton(self.buttons_frame, text = "Διαγραφή Κόμβου", command=self.delete_node)
        self.delete_node_button.grid(columnspan=2 , pady = 8, sticky="ew", padx = 30)
        # Κουμπί προβολής Απογόνων
        self.view_descendants_button = customtkinter.CTkButton(self.buttons_frame, text="Προβολή Απογόνων", command=self.view_descendants)
        self.view_descendants_button.grid(columnspan=2, pady=8, sticky="ew", padx=30)
        # Κουμπί καθαρισμού όλου του καμβά
        self.clear_all_button = customtkinter.CTkButton(self.buttons_frame, text = "Διαγραφή Όλων", command=self.clear_all)
        self.clear_all_button.grid(columnspan = 2, pady=8,sticky="ew", padx = 30)
        # Κουμπίεμφανιση πληροφοριων
        self.clear_all_button = customtkinter.CTkButton(self.buttons_frame, text = "Εμφάνιση Πληροφοριών Ατόμου", command=self.show_person_info)
        self.clear_all_button.grid(columnspan = 2, sticky="ew", padx = 30)
        # Τέλος βάζουμε άλλη μια κενή ετικέττα για λόγους συμμετρίας όπως προαναφέραμε
        empty = customtkinter.CTkLabel(self.buttons_frame, text = "")
        empty.grid(columnspan=2, sticky="ew", padx = 30)
        # Προσθήκη πεδίων εισαγωγής πληροφοριών επιλεγμένου ατόμου
        # Εδω θα χρησιμοποιήσουμε το CTkLabel για ετικέττα περιγραφής αριστερα (column 0) και το CTkEntry πεδίο κειμένου δεξιά (column 1)
        # Το anchor = W στις ετικέττες στοιχίζει το κείμενο αριστερά (West)
        # Αρχικά βάζουμε μια κενή ετικέτα για λόγους συμμετρίας και ομορφιάς
        empty = customtkinter.CTkLabel(self.information_frame, text = "Πληροφορίες Επιλογής")
        empty.grid(columnspan=2, sticky="ew", padx = 30, pady = 25)
        # Ετικέτα και πλαίσιο κειμένου αναγνωριστικού (ID)
        self.id_label = customtkinter.CTkLabel(self.information_frame, text = "Αναγνωριστικό", anchor = W) # Δημιουργία ετικέτας
        self.id_label.grid(sticky="ew", pady = 5, padx = 30, row = 1, column = 0) # πλασάρισμα με grid
        self.id_entry = customtkinter.CTkEntry(self.information_frame) # δημιουργία πλαισίου κειμένου
        self.id_entry.grid(sticky="ew", padx = 30, row = 1, column = 1) # πλασάρισμα με grid
        # Ετικέτα και πλαίσιο κειμένου ονόματος
        self.name_label = customtkinter.CTkLabel(self.information_frame, text = "Όνομα", anchor = W)# Δημιουργία ετικέτας
        self.name_label.grid(sticky="ew", pady = 5, padx = 30, row = 2, column = 0) # πλασάρισμα με grid       
        self.name_entry = customtkinter.CTkEntry(self.information_frame) # δημιουργία πλαισίου κειμένου
        self.name_entry.grid(sticky="ew",  padx = 30, row = 2, column = 1) # πλασάρισμα με grid
        # Ετικέτα και πλαίσιο κειμένου επιθέτου
        self.surname_label = customtkinter.CTkLabel(self.information_frame, text = "Επίθετο", anchor = W)# Δημιουργία ετικέτας
        self.surname_label.grid(sticky="ew", pady = 5, padx = 30, row = 3, column = 0) # πλασάρισμα με grid       
        self.surname_entry = customtkinter.CTkEntry(self.information_frame) # δημιουργία πλαισίου κειμένου
        self.surname_entry.grid(sticky="ew", padx = 30, row = 3, column = 1) # πλασάρισμα με grid
        
        # Ετικέτα και μενού επιλογών για το γένος
        self.gender_label = customtkinter.CTkLabel(self.information_frame, text = "Γένος", anchor = W) # Δημιουργία ετικέτας
        self.gender_label.grid(sticky="ew", pady = 5, padx = 30, row = 4, column = 0) # πλασάρισμα με grid
        # για το γένος θα χρησιμοποιήσουμε μενού επιλογών αντι για πλαίσιο κειμένου το οποίο θα περιλαμνάνει τις 3 δυνατες επιλογες ανδρας γυναίκα και άλλο
        # https://www.geeksforgeeks.org/how-to-create-option-menu-in-tkinter/
        # Αρχικά δημιουργούμε μια μεταβλητή self.option_variable τύπου customtkinter.StringVar, που χρησιμοποιείται για να αποθηκεύσει και να ελέγξει την τιμή που επιλέγεται από το χρήστη στο OptionMenu
        self.option_variable = customtkinter.StringVar(self)
        # Δηλώνουμε την προεπιλεγμένη τιμή του self.option_variable ως "Άρρεν" με τη μέθοδο set
        self.option_variable.set("Άρρεν")
        # Θέτουμε τις επιλογές της λίστας
        option_list = ["Επιλογή", "Άρρεν", "Θήλυ", "Άλλο"]
        # δημιουργία μενού επιλογών σύμφωνα με τα παραπάνω
        self.gender_entry = customtkinter.CTkOptionMenu(self.information_frame, variable = self.option_variable, values = option_list)
        self.gender_entry.grid(sticky="ew", pady = 5, padx = 30, row = 4, column = 1)# πλασάρισμα με grid
        
        # Ετικέτα και πλαίσιο κειμένου ημερομηνίας γέννησης
        self.birth_label = customtkinter.CTkLabel(self.information_frame, text = "Ημ/νία Γέννησης", anchor = W)# Δημιουργία ετικέτας
        self.birth_label.grid(sticky="ew", pady = 5, padx = 30, row = 5, column = 0)# πλασάρισμα με grid
        self.birth_entry = customtkinter.CTkEntry(self.information_frame) # δημιουργία πλαισίου κειμένου
        self.birth_entry.grid(sticky="ew", padx = 30, row = 5, column = 1) # πλασάρισμα με grid
        
        #νεα ετικέτα για πλαίδιο εν ζωή αντι ημερομηνίας θανάτου
        self.live_label = customtkinter.CTkLabel(self.information_frame, text = "Εν ζωή", anchor = W) # Δημιουργία ετικέτας
        self.live_label.grid(sticky="ew", pady = 5, padx = 30, row = 6, column = 0) # πλασάρισμα με grid
        self.option2_variable = customtkinter.StringVar(self)
         # Δηλώνουμε την προεπιλεγμένη τιμή του self.option2_variable ως "NAI" με τη μέθοδο set
        self.option2_variable.set("NAI")
        # Θέτουμε τις επιλογές της λίστας
        option2_list = ["Επιλογή", "NAI", "OXI"]
        # δημιουργία μενού επιλογών σύμφωνα με τα παραπάνω
        self.live_entry = customtkinter.CTkOptionMenu(self.information_frame, variable = self.option2_variable, values = option2_list)
        self.live_entry.grid(sticky="ew", padx = 30, row = 6, column = 1)# πλασάρισμα με grid
        
        # # Ετικέτα και πλαίσιο κειμένου ημερομηνίας θανάτου
        self.death_label = customtkinter.CTkLabel(self.information_frame, text = "Ημ/νια Θανάτου", anchor = W)# Δημιουργία ετικέτας
        self.death_label.grid(sticky="ew", pady = 5, padx = 30, row = 7, column = 0) # πλασάρισμα με grid
        self.death_entry = customtkinter.CTkEntry(self.information_frame) # δημιουργία πλαισίου κειμένου
        self.death_entry.grid(sticky="ew", padx = 30, row = 7, column = 1) # πλασάρισμα με grid
        
        self.comments_label = customtkinter.CTkLabel(self.information_frame, text = "Σχόλια", anchor = W)
        self.comments_label.grid(sticky="ew", pady = 5, padx = 30, row = 8, column = 0)
        self.comments_entry = customtkinter.CTkTextbox(self.information_frame, height = 80)
        self.comments_entry.grid(sticky="ew", padx = 30, row = 9, column = 0, columnspan=2)
       
        # δημιουργία κουμπιού για την ενημέρωση των πληροφοριών του επιλεγμένου ατόμου
        self.save_info_button = customtkinter.CTkButton(self.information_frame, text = "Ενημέρωση Πληροφοριών", command = self.update_information)
        self.save_info_button.grid(sticky="ew", padx = 30, pady= 10, columnspan = 2)
        # Τέλος βάζουμε άλλη μια κενή ετικέττα για λόγους συμμετρίας όπως προαναφέραμε
        empty = customtkinter.CTkLabel(self.information_frame, text = "")
        empty.grid(columnspan=2, sticky="ew", padx = 30)
        # Δημιουργία καμβά σχεδιασμού δέντρου
        # Δημιουργία συνάρτησης για το zoom με τη ροδέλα του ποντικιού
        # https://stackoverflow.com/questions/25787523/move-and-zoom-a-tkinter-canvas-with-mouse
        def do_zoom(event):
            x = self.canvas.canvasx(event.x) # αντιστοίχιση συντεταγμένησ Χ του ποντικιού (event.x) με την συντεταγμενη Χ του καμβά
            y = self.canvas.canvasy(event.y) # αντίστοιχα και για την Υ
            # Η event.delta περιέχει την τιμή της μεταβολής (διαφορά) της ροδέλας του ποντικιού (mouse wheel).
            factor = 1.001 ** event.delta # παράγοντας αύξησης ή σμίκρυνσης (ζοομ) 
            #  χρησιμοποιείται τη μέθοδο scale για να εφαρμόσουμε το ζουμ (scaling) σε όλα τα στοιχεία του καμβά βάσει του παράγοντα μεταβολής που υπολογίστηκε προηγουμένως.
            self.canvas.scale(ALL, x, y, factor, factor)
        self.canvas = Canvas(self.canvas_frame, bg = "#eeeeee") # δημιουργία καμβά στο canvas_frame με φόντο γκριζάκι   
        self.canvas.bind("<MouseWheel>", do_zoom) #σύνδεση του συμβάντος <MouseWheel> με την συνάρτηση do_zoom.Κάθε φορά που μετακινείται η ροδέλα του ποντικιού καλείται η do_zoom 
        # Παρακάτω συνδέουμε το συμβάν <ButtonPress-1> με μια ανώνυμη (lambda) συνάρτηση που καλεί τη μέθοδο self.canvas.scan_mark(event.x, event.y)
        # για την παρακολούθηση της θέσης του ποντικιού πάνω στον καμβά
        # https://realpython.com/python-lambda/
        # https://anzeljg.github.io/rin2/book2/2405/docs/tkinter/canvas-methods.html
        self.canvas.bind('<ButtonPress-1>', lambda event: self.canvas.scan_mark(event.x, event.y))
        # εφόσον έχουμε τη θέση του ποντικιού πάνω στον καμβά μπορούμε ευκολα να κάνουμε scroll τον καμβά
        # https://stackoverflow.com/questions/74682813/tkinter-canvas-scrolling-scrollregion-explained-un-restricted-area
        self.canvas.bind("<B1-Motion>", lambda event: self.canvas.scan_dragto(event.x, event.y, gain=1))
        self.canvas.pack(fill=BOTH, expand=True) # τοποθέτηση με pack
        # Θέτουμε την βαρύτητα στα πλαίσια για να καθορίσουμε το πως επεκτείνονται κατά την αλλαγή μεγέθους του παραθύρου
        # https://www.plus2net.com/python/tkinter-rowconfigure.php
        # κυρίως πλαίσιο
        self.main_frame.grid_columnconfigure(1,weight=4) # Στήλη βαρύτητα της στήλης 1 στο 4, που σημαίνει ότι θα παίρνει περισσότερο χώρο σε σχέση με άλλες στήλες όταν αλλάζει το μέγεθος του παραθύρου. 
        self.main_frame.grid_rowconfigure(0,weight=1) # γραμμή 0 βαύτητα στο 1, που σημαίνει ότι θα τεντώνει μαζί με το παράθυρο.
        # πλαίσιο πληροφοριών
        self.information_frame.grid_columnconfigure(0, weight=1) # Στήλη 1 μεγαλύτερο βάρος απο την 2
        self.information_frame.grid_columnconfigure(1, weight=4)
        # πλαίσιο κουμπιών
        self.buttons_frame.grid_columnconfigure(0, weight=1) # ίδιο βάρος και οι 2 στήλες (τεντώνονται ισομερώς)
        self.buttons_frame.grid_columnconfigure(1, weight=1)
# Δημιουργία κυρίως παραθύρου και ξεκίνημα βρόχου γεγονότων
def main(): # ορίζουμε την συνάρτηση Main
    global root # ορισμός της root (παράθυρο της customtkinter) ως global για προσπέλαση απο παντού στον κώδικα
    root = customtkinter.CTk() # δημιουργία του κυρίως παραθύρου
    ex = Window() # δημιουργεί ένα αντικείμενοu Window  
    root.geometry("1600x950+150+30") # Ορίσμός αρχικού μεγεθους και της θέσης του παραθύρου στην οθόνη.
    root.mainloop() # ξεκίνημα του βρόχου γεγονότων της εφαρμογής
if __name__ == '__main__': # https://www.tutorialspoint.com/What-does-the-if-name-main-do-in-Python#:~:text=A%20Python%20programme%20uses%20the,is%20imported%20as%20a%20module.
    main() # εκτέλεση της main()
