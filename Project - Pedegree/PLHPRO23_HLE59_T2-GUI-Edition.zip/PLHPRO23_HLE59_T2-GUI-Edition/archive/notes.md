# Σημειώσεις

**Λογισμικά για γενεαλογικά δένδρα**

* https://www.familyecho.com/
* https://gramps-project.org/blog/
* https://www.myheritage.com/ $$$