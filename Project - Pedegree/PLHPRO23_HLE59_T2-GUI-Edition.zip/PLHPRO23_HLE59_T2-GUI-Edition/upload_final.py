
from pathlib import Path
from tkinter import filedialog 
# from tkinter import *
# Explicit imports to satisfy Flake8
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage
from tkinter import *
from tkinter import ttk
import subprocess
import sys
sys.path.append("../FamilyTree")   # Add the parent directory to the module search path

OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r".//assets//frame6")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)

def getFolderPath():
    file_selected = filedialog.askopenfilename()
    filePath.set(file_selected)
    #print(filePath.get())
    entry_1.insert(0, filePath.get())
# def doStuff():
#     folder = folderPath.get()
#     print("Doing stuff with folder", folder)
def open_FamilyTree():
    if (filePath.get()):
        string_to_pass = "epitixia"
        string_to_pass2 = filePath.get()
    else:
        string_to_pass = "error-chosen file"
        string_to_pass2 = "" 
    # import FamilyTree
    # FamilyTree.process_file(filePath.get())
    window.destroy() 
    subprocess.Popen(["python", "FamilyTree.py",string_to_pass, string_to_pass2]).wait()

window = Tk()

window.geometry("592x322")
window.configure(bg = "#D9D9D9")

filePath = StringVar()

canvas = Canvas(
    window,
    bg = "#D9D9D9",
    height = 322,
    width = 592,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge"
)

canvas.place(x = 0, y = 0)
entry_image_1 = PhotoImage(
    file=relative_to_assets("entry_1.png"))
entry_bg_1 = canvas.create_image(
    217.5,
    148.5,
    image=entry_image_1
)
entry_1 = Entry(
    bd=0,
    bg="#EEF5E6",
    fg="#000716",
    highlightthickness=0
)
entry_1.place(
    x=41.0,
    y=126.0,
    width=353.0,
    height=43.0
)
# a = Label(window ,text="Enter name")
# a.grid(row=0,column = 0)
# E = Entry(window,textvariable=folderPath)
# E.grid(row=0,column=1)



button_image_1 = PhotoImage(
    file=relative_to_assets("button_1.png"))
button_1 = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=lambda: print("button_1 clicked"),
    relief="flat"
)
button_1.place(
    x=743.0,
    y=7.0,
    width=30.0,
    height=31.0
)

canvas.create_text(
    37.0,
    83.0,
    anchor="nw",
    text="Ανέβασμα από αρχείο",
    fill="#000000",
    font=("Inter Regular", 26 * -1)
)

button_image_2 = PhotoImage(
    file=relative_to_assets("button_2.png"))
button_2 = Button(
    image=button_image_2,
    borderwidth=0,
    highlightthickness=0,
    command=open_FamilyTree,#lambda: print("button_2 clicked"),
    relief="flat"
)
button_2.place(
    x=25.0,
    y=212.0,
    width=200.0,
    height=79.0
)

button_image_3 = PhotoImage(
    file=relative_to_assets("button_3.png"))
button_3 = Button(
    image=button_image_3,
    borderwidth=0,
    highlightthickness=0,
    command=getFolderPath,#lambda: print("button_3 clicked"),
    relief="flat"
)
button_3.place(
    x=411.0,
    y=131.0,
    width=39.0,
    height=35.0
)

# button_image_4 = PhotoImage(
#     file=relative_to_assets("button_4.png"))
# button_4 = Button(
#     image=button_image_4,
#     borderwidth=0,
#     highlightthickness=0,
#     command=lambda: print("button_4 clicked"),
#     relief="flat"
# )
# button_4.place(
#     x=542.0,
#     y=4.0,
#     width=30.0,
#     height=34.0
# )
window.resizable(False, False)
window.mainloop()
